# Packs d’assets — La Plaine 0.2.7.0

Un pack peut remplacer des textures, fournir des GIF animés et remplacer les sons du jeu. Placez `manifest.json` à la racine du dossier ou du ZIP. Les chemins d’assets sont relatifs au pack.

## Remplacer une texture par un GIF

```json
{
  "id": "mon-pack",
  "name": "Mon pack d’assets",
  "version": "1.0.0",
  "texture_overrides": {
    "desert/cactus_side.png": "textures/cactus/cactus_animated.gif"
  }
}
```

## Plusieurs textures vers un seul GIF

```json
{
  "texture_groups": [
    {
      "sources": [
        "desert/cactus_side.png",
        "desert/cactus_top.png"
      ],
      "file": "textures/cactus/cactus_all_faces.gif"
    }
  ]
}
```

Chaque source listée sera remplacée par le même GIF. Cela ne fusionne pas les images sources : le créateur du pack fournit le GIF final. Les chemins peuvent aussi commencer par `textures/` ou `assets/textures/`. Les sons personnalisés se placent sous `sounds/`; utilisez `sound_overrides` dans le manifeste pour remplacer un son du jeu, par exemple `"sound_overrides": {"ambiance.ogg": "sounds/ambiance-remix.ogg"}`.

Formats image acceptés par les navigateurs : PNG, JPG/JPEG, WEBP, GIF et ICO (selon le navigateur et le contexte). Les GIF sont actualisés pour conserver leur animation dans les textures Three.js.
