(function () {
    'use strict';

    window.LaPlaineAPI.on("game:ready", ({ world, player, camera }) => {
        const THREE = window.THREE;
        if (!THREE || !player || !camera) {
            console.error("[FirstPersonHandPro] Contexte 3D manquant.");
            return;
        }

        // 1. Désactiver le bras vanilla simple du jeu pour éviter la superposition
        const disableVanillaArm = () => {
            if (player.firstPersonArm) {
                player.firstPersonArm.visible = false;
                camera.remove(player.firstPersonArm);
                player.firstPersonArm = null;
            }
        };
        disableVanillaArm();

        // Conteneur principal attaché à la caméra (pivot d'animation)
        const handPivot = new THREE.Group();
        handPivot.position.set(0.38, -0.34, -0.58);
        handPivot.rotation.set(-0.15, -0.18, 0.08);
        camera.add(handPivot);

        // Sous-groupes pour la main nue et l'objet tenu
        const handMeshGroup = new THREE.Group();
        const heldItemGroup = new THREE.Group();
        handPivot.add(handMeshGroup);
        handPivot.add(heldItemGroup);

        // 2. Extraction UV de l'atlas du skin sélectionné
        function extractFaceTexture(image, x, y, w, h) {
            const canvas = document.createElement('canvas');
            canvas.width = w;
            canvas.height = h;
            const ctx = canvas.getContext('2d');
            ctx.imageSmoothingEnabled = false;
            ctx.drawImage(image, x, y, w, h, 0, 0, w, h);

            const tex = new THREE.CanvasTexture(canvas);
            tex.magFilter = THREE.NearestFilter;
            tex.minFilter = THREE.NearestFilter;
            tex.colorSpace = THREE.SRGBColorSpace || tex.colorSpace;
            tex.needsUpdate = true;
            return tex;
        }

        function createSkinBoxMaterials(img, u, v, w, h, d) {
            // Ordre Three.js BoxGeometry : Right (+X), Left (-X), Top (+Y), Bottom (-Y), Front (+Z), Back (-Z)
            const texRight = extractFaceTexture(img, u, v + d, d, h);
            const texLeft  = extractFaceTexture(img, u + d + w, v + d, d, h);
            const texTop   = extractFaceTexture(img, u + d, v, w, d);
            const texBot   = extractFaceTexture(img, u + d + w, v, w, d);
            const texFront = extractFaceTexture(img, u + d, v + d, w, h);
            const texBack  = extractFaceTexture(img, u + d + w + d, v + d, w, h);

            const makeMat = (tex) => new THREE.MeshLambertMaterial({
                map: tex,
                transparent: true,
                alphaTest: 0.1
            });

            return [
                makeMat(texRight),
                makeMat(texLeft),
                makeMat(texTop),
                makeMat(texBot),
                makeMat(texFront),
                makeMat(texBack)
            ];
        }

        let currentLoadedSkin = null;

        function buildHandFromSkin(skinFileName) {
            const safeSkin = /^Paul(?:[1-9]|10)\.png$/.test(skinFileName) ? skinFileName : 'Paul1.png';
            if (currentLoadedSkin === safeSkin && handMeshGroup.children.length > 0) return;

            const img = new Image();
            img.crossOrigin = 'anonymous';
            img.onload = () => {
                // Nettoyer l'ancien mesh
                while (handMeshGroup.children.length > 0) {
                    const child = handMeshGroup.children[0];
                    handMeshGroup.remove(child);
                    child.geometry?.dispose();
                    if (Array.isArray(child.material)) child.material.forEach(m => { m.map?.dispose(); m.dispose(); });
                }

                // Bras droit standard sur l'atlas 64x64 : u=40, v=16, w=4, h=12, d=4
                const armGeo = new THREE.BoxGeometry(0.20, 0.62, 0.20);
                const armMats = createSkinBoxMaterials(img, 40, 16, 4, 12, 4);
                const armMesh = new THREE.Mesh(armGeo, armMats);

                // Inclinaison naturelle vers l'avant comme dans Minecraft
                armMesh.rotation.set(0.65, 0.15, -0.15);
                armMesh.position.set(0.02, -0.05, 0.05);
                armMesh.frustumCulled = false;

                handMeshGroup.add(armMesh);
                currentLoadedSkin = safeSkin;
            };
            img.src = `/static/textures/skins/${encodeURIComponent(safeSkin)}`;
        }

        // Charger le skin initial
        const getSelectedSkin = () => localStorage.getItem('laPlaine.selectedSkin') || player.selectedSkin || 'Paul1.png';
        buildHandFromSkin(getSelectedSkin());

        // 3. Rendu 3D du bloc ou de l'item tenu en main
        const textureLoader = new THREE.TextureLoader();
        const textureCache = new Map();

        function getPixelTexture(url) {
            if (!url) return null;
            if (textureCache.has(url)) return textureCache.get(url);
            const tex = textureLoader.load(url);
            tex.magFilter = THREE.NearestFilter;
            tex.minFilter = THREE.NearestFilter;
            tex.colorSpace = THREE.SRGBColorSpace || tex.colorSpace;
            textureCache.set(url, tex);
            return tex;
        }

        let lastHeldType = -1;
        let switchAnimProgress = 0; // Animation de changement de slot

        function updateHeldItemVisual() {
            const slot = player.inventory?.getSelectedSlot?.();
            const itemId = (slot && slot.count > 0 && slot.type > 0) ? slot.type : 0;

            if (itemId === lastHeldType) return;
            lastHeldType = itemId;
            switchAnimProgress = 1.0; // Déclenche l'animation de changement d'objet

            // Nettoyer l'objet tenu précédent
            while (heldItemGroup.children.length > 0) {
                const obj = heldItemGroup.children[0];
                heldItemGroup.remove(obj);
                obj.geometry?.dispose();
                if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
                else obj.material?.dispose();
            }

            if (itemId === 0) {
                // Main vide : afficher le bras du skin
                handMeshGroup.visible = true;
                heldItemGroup.visible = false;
                return;
            }

            const itemDef = window.itemsRegistry?.get(itemId);
            const blockDef = window.blockRegistry?.get(itemId);

            // Cas A : C'est un bloc (soit item de type 'block', soit défini dans blockRegistry)
            const isBlock = (itemDef?.type === 'block' || (blockDef && !itemDef?.tool && itemDef?.type !== 'item'));
            if (isBlock && blockDef) {
                handMeshGroup.visible = false;
                heldItemGroup.visible = true;

                const t = blockDef.textures || {};
                const urlRight  = t.right  || t.sides || t.all || '';
                const urlLeft   = t.left   || t.sides || t.all || '';
                const urlTop    = t.top    || t.all   || '';
                const urlBottom = t.bottom || t.all   || '';
                const urlFront  = t.front  || t.sides || t.all || '';
                const urlBack   = t.back   || t.sides || t.all || '';

                const makeFaceMat = (url) => {
                    const tex = getPixelTexture(url);
                    return new THREE.MeshLambertMaterial({
                        map: tex,
                        transparent: Boolean(blockDef.transparent || blockDef.alphaTest),
                        alphaTest: blockDef.alphaTest || (blockDef.transparent ? 0.1 : 0)
                    });
                };

                const blockGeo = new THREE.BoxGeometry(0.28, 0.28, 0.28);
                const blockMats = [
                    makeFaceMat(urlRight),
                    makeFaceMat(urlLeft),
                    makeFaceMat(urlTop),
                    makeFaceMat(urlBottom),
                    makeFaceMat(urlFront),
                    makeFaceMat(urlBack)
                ];

                const blockMesh = new THREE.Mesh(blockGeo, blockMats);
                // Orientation isométrique classique d'un bloc tenu en main
                blockMesh.rotation.set(0.25, Math.PI / 4, 0.12);
                blockMesh.position.set(0.04, -0.02, -0.05);
                blockMesh.frustumCulled = false;

                heldItemGroup.add(blockMesh);
                return;
            }

            // Cas B : C'est un outil ou un item (épée, pioche, nourriture, lingot, etc.)
            const itemTexUrl = itemDef?.texture || itemDef?.textures?.all || blockDef?.textures?.all || '';
            if (itemTexUrl) {
                handMeshGroup.visible = false;
                heldItemGroup.visible = true;

                const tex = getPixelTexture(itemTexUrl);
                // On utilise une boîte très fine (0.02) pour donner une épaisseur 3D à l'item
                const itemGeo = new THREE.BoxGeometry(0.32, 0.32, 0.02);
                const sideMat = new THREE.MeshLambertMaterial({ color: 0x3a3a3a });
                const faceMat = new THREE.MeshLambertMaterial({
                    map: tex,
                    transparent: true,
                    alphaTest: 0.15
                });

                const itemMesh = new THREE.Mesh(itemGeo, [
                    sideMat, sideMat, sideMat, sideMat, faceMat, faceMat
                ]);

                // Orientation ergonomique d'outil/item tenu en main
                itemMesh.rotation.set(0.1, -0.45, 0.35);
                itemMesh.position.set(0.05, 0.02, -0.05);
                itemMesh.frustumCulled = false;

                heldItemGroup.add(itemMesh);
            } else {
                // Repli : afficher la main si aucune texture n'est trouvée
                handMeshGroup.visible = true;
                heldItemGroup.visible = false;
            }
        }

        // 4. Gestion des animations (Marche, Frappe, Minage continu, Pose de bloc)
        let swingProgress = 0;      // 0 = repos, > 0 = animation de coup en cours
        let isMiningHeld = false;   // Maintien du clic gauche

        window.addEventListener('mousedown', (e) => {
            if (!player.controls?.isLocked || player.inventory?.isOpen) return;
            if (e.button === 0) {
                isMiningHeld = true;
                if (swingProgress <= 0.15) swingProgress = 1.0;
            } else if (e.button === 2) {
                // Animation de pose de bloc / interaction
                swingProgress = 0.85;
            }
        });

        window.addEventListener('mouseup', (e) => {
            if (e.button === 0) {
                isMiningHeld = false;
            }
        });

        // Écouter les changements d'inventaire pour mettre à jour l'objet tenu immédiatement
        window.addEventListener('inventory-changed', updateHeldItemVisual);

        // 5. Boucle de mise à jour image par image (`game:tick`)
        let bobTimer = 0;
        let idleTimer = 0;

        window.LaPlaineAPI.on("game:tick", ({ delta }) => {
            disableVanillaArm();

            // Masquer en vue 3ème personne ou quand l'inventaire est ouvert
            const isFirstPerson = player.cameraMode === 0 && !player.inventory?.isOpen && !player.dead;
            handPivot.visible = isFirstPerson;
            if (!isFirstPerson) return;

            // Vérifier si le skin a été modifié ou si le slot actif a changé
            buildHandFromSkin(getSelectedSkin());
            updateHeldItemVisual();

            const dt = Math.min(delta, 0.05);
            idleTimer += dt;

            // Vitesse horizontale du joueur
            const horizSpeed = Math.hypot(player.velocity?.x || 0, player.velocity?.z || 0);
            const isMoving = player.canJump && horizSpeed > 0.15;

            if (isMoving) {
                bobTimer += dt * (player.isSprinting ? 14.0 : 9.5);
            }

            // Maintien du minage : relancer la boucle de coup en continu
            if (isMiningHeld && swingProgress <= 0.05) {
                swingProgress = 1.0;
            }

            // Progression des animations
            if (swingProgress > 0) {
                swingProgress = Math.max(0, swingProgress - dt * 4.2);
            }
            if (switchAnimProgress > 0) {
                switchAnimProgress = Math.max(0, switchAnimProgress - dt * 5.5);
            }

            // Calcul des offsets de position
            const baseX = 0.38;
            const baseY = -0.34;
            const baseZ = -0.58;

            const bobX = isMoving ? Math.cos(bobTimer) * 0.022 : 0;
            const bobY = isMoving ? Math.abs(Math.sin(bobTimer)) * 0.025 : Math.sin(idleTimer * 2.0) * 0.006;

            // Courbe sinusoïdale pour le coup de poing / outil
            const swingSin = Math.sin((1 - swingProgress) * Math.PI);
            const swingX = -swingSin * 0.18;
            const swingY = -swingSin * 0.12;
            const swingZ = -swingSin * 0.16;

            // Animation de sortie d'objet (descend puis remonte)
            const equipOffsetY = -Math.sin(switchAnimProgress * Math.PI) * 0.25;

            handPivot.position.set(
                baseX + bobX + swingX,
                baseY + bobY + swingY + equipOffsetY,
                baseZ + swingZ
            );

            // Calcul des rotations (inclinaison vers l'avant + twist lors du swing)
            const baseRotX = -0.15;
            const baseRotY = -0.18;
            const baseRotZ = 0.08;

            const swingRotX = -swingSin * 0.85;
            const swingRotY = swingSin * 0.45;
            const swingRotZ = swingSin * 0.35;

            handPivot.rotation.set(
                baseRotX + swingRotX + (isMoving ? Math.sin(bobTimer) * 0.04 : 0),
                baseRotY + swingRotY,
                baseRotZ + swingRotZ
            );
        });

        console.info("[FirstPersonHandPro] Mod chargé avec succès !");
    });
})();