(function installModLoader() {
    'use strict';
    const STORAGE_KEY = 'laPlaine.enabledMods';
    const loaded = new Set();
    const errors = [];
    const eventBus = window.LaPlaineEvents;
    function currentOwner() { return window.LaPlaineCurrentModId || 'base'; }
    function withOwner(owner, callback) {
        const previous = window.LaPlaineCurrentModId;
        window.LaPlaineCurrentModId = owner === 'base' ? null : owner;
        try { return callback(); }
        finally { window.LaPlaineCurrentModId = previous || null; }
    }
    function on(eventName, handler) {
        if (!eventBus) throw new Error('Event Bus indisponible.');
        if (typeof handler !== 'function') throw new TypeError('Un gestionnaire d’événement est requis.');
        const owner = currentOwner();
        return eventBus.on(eventName, payload => withOwner(owner, () => handler(payload)));
    }
    function emit(eventName, payload) {
        eventBus?.emit(eventName, payload);
    }

    function readEnabled() {
        try {
            const value = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
            return Array.isArray(value) ? value.filter(id => typeof id === 'string') : null;
        } catch (_) { return null; }
    }

    function enabledIds(mods) {
        const saved = readEnabled();
        return new Set(saved === null ? mods.map(mod => mod.id) : saved);
    }

    function loadScript(url) {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = url;
            script.async = false;
            script.onload = () => resolve();
            script.onerror = () => reject(new Error(`Impossible de charger ${url}`));
            document.head.appendChild(script);
        });
    }

    async function loadEnabledMods(options = {}) {
        errors.length = 0;
        const response = await fetch('/api/mods', { cache: 'no-store' });
        if (!response.ok) throw new Error('Impossible de lire la liste des mods.');
        const payload = await response.json();
        const allMods = Array.isArray(payload.mods) ? payload.mods : [];
        const mods = options.settingsOnly ? allMods.filter(mod => mod.menu_settings === true) : allMods;
        const enabled = enabledIds(allMods);
        const available = new Map(allMods.map(mod => [mod.id, mod]));
        const ordered = [];
        const state = new Map(); // 1 = visite en cours, 2 = terminé
        const failed = new Set();
        const reported = new Set();

        function report(id, error) {
            const key = `${id}:${error}`;
            if (reported.has(key)) return;
            reported.add(key);
            errors.push({ id, error });
        }

        function visit(mod, stack = []) {
            if (loaded.has(mod.id) || state.get(mod.id) === 2) return !failed.has(mod.id);
            if (state.get(mod.id) === 1) {
                const cycle = [...stack, mod.id].join(' -> ');
                report(mod.id, `Cycle de dépendances détecté : ${cycle}`);
                failed.add(mod.id);
                return false;
            }
            state.set(mod.id, 1);
            for (const dependencyId of (Array.isArray(mod.dependencies) ? mod.dependencies : [])) {
                const dependency = available.get(dependencyId);
                if (!dependency) {
                    report(mod.id, `Dépendance introuvable : ${dependencyId}`);
                    failed.add(mod.id);
                    break;
                }
                if (!enabled.has(dependencyId)) {
                    report(mod.id, `Dépendance désactivée : ${dependencyId}`);
                    failed.add(mod.id);
                    break;
                }
                if (!visit(dependency, [...stack, mod.id])) {
                    report(mod.id, `Dépendance impossible à charger : ${dependencyId}`);
                    failed.add(mod.id);
                    break;
                }
            }
            state.set(mod.id, 2);
            if (!failed.has(mod.id) && !ordered.some(item => item.id === mod.id)) ordered.push(mod);
            return !failed.has(mod.id);
        }

        for (const mod of mods) if (enabled.has(mod.id)) visit(mod);
        for (const mod of ordered) {
            if (loaded.has(mod.id)) continue;
            const compatibility = String(mod.compatibility || '*').trim();
            if (compatibility !== '*' && compatibility !== '0.2.7.0') {
                report(mod.id, `Version du jeu incompatible : ${compatibility} (jeu 0.2.7.0).`);
                continue;
            }
            const entry = typeof mod.entry === 'string' ? mod.entry : 'main.js';
            const parts = entry.split('/');
            if (!entry || entry.startsWith('/') || parts.some(part => !part || part === '.' || part === '..')) {
                errors.push({ id: mod.id, error: 'Chemin d’entrée invalide dans manifest.json.' });
                continue;
            }
            const encodedEntry = parts.map(encodeURIComponent).join('/');
            const previousModId = window.LaPlaineCurrentModId;
            try {
                window.LaPlaineCurrentModId = mod.id;
                await loadScript(`/api/mods/${encodeURIComponent(mod.id)}/${encodedEntry}`);
                loaded.add(mod.id);
                console.info(`[La Plaine] Mod chargé : ${mod.name} (${mod.version})`);
            } catch (error) {
                errors.push({ id: mod.id, error: error.message });
                console.error(`[La Plaine] Échec du mod ${mod.id}`, error);
            } finally {
                window.LaPlaineCurrentModId = previousModId || null;
            }
        }
        emit('mods:loaded', { loaded: [...loaded], errors: [...errors] });
        window.dispatchEvent(new CustomEvent('laplaine:mods-loaded', { detail: { loaded: [...loaded], errors: [...errors] } }));
        return { loaded: [...loaded], errors: [...errors] };
    }

    const settingHandles = new Map();
    const textureHandles = new Map();
    const soundHandles = new Map();
    const inventoryHandles = new Map();
    const menuCategories = new Map();
    const menuButtons = new Map();
    const worldOptions = new Map();

    function getModSettingsRoot() {
        const settingsContainer = document.getElementById('lp-mod-settings-container');
        if (settingsContainer) return settingsContainer;

        const pause = document.getElementById('pause-overlay');
        if (!pause) return null;
        let root = document.getElementById('lp-mod-settings');
        if (root) return root;
        root = document.createElement('section');
        root.id = 'lp-mod-settings';
        root.style.cssText = 'display:block;max-height:30vh;overflow:auto;text-align:left;margin:14px auto;padding:12px;width:min(420px,90vw);box-sizing:border-box;background:rgba(15,18,22,.88);border:1px solid rgba(255,255,255,.22);border-radius:9px;color:white;';
        const title = document.createElement('h3');
        title.textContent = 'Paramètres des mods';
        title.style.cssText = 'margin:0 0 8px;font-size:1rem;';
        root.appendChild(title);
        const resume = document.getElementById('btn-resume');
        pause.insertBefore(root, resume || null);
        return root;
    }

    function safeAssetUrl(modId, relativePath) {
        if (typeof modId !== 'string' || !/^[a-zA-Z0-9_-]{1,80}$/.test(modId)) {
            throw new TypeError('Identifiant de mod invalide.');
        }
        if (typeof relativePath !== 'string' || !relativePath.trim()) throw new TypeError('Chemin de ressource requis.');
        const normalized = relativePath.replace(/\\/g, '/');
        const parts = normalized.split('/');
        if (normalized.startsWith('/') || parts.some(p => !p || p === '.' || p === '..')) throw new TypeError('Chemin de ressource invalide.');
        return `/api/mods/${encodeURIComponent(modId)}/${parts.map(encodeURIComponent).join('/')}`;
    }

    function registerSetting(config) {
        if (!config || typeof config.id !== 'string' || !/^[a-zA-Z0-9_.-]{1,100}$/.test(config.id)) throw new TypeError('Un paramètre doit avoir un id unique et valide.');
        const owner = currentOwner();
        const handleId = `${owner}:${config.id}`;
        if (settingHandles.has(handleId)) throw new Error(`Paramètre déjà enregistré : ${config.id}`);
        const root = getModSettingsRoot();
        if (!root) throw new Error('Le menu des paramètres du jeu est introuvable.');
        root.querySelector('#lp-mod-settings-empty')?.remove();
        const type = config.type || 'slider';
        if (!['slider', 'checkbox', 'select'].includes(type)) throw new TypeError(`Type de paramètre non pris en charge : ${type}`);
        const storageKey = `laPlaine.modSetting.${owner}.${config.id}`;
        let saved = null;
        try { saved = localStorage.getItem(storageKey); } catch (_) {}
        if (saved === null) {
            try {
                const previousValue = localStorage.getItem(`laPlaine.modSetting.${config.id}`);
                if (previousValue !== null) { saved = previousValue; localStorage.setItem(storageKey, previousValue); }
            } catch (_) {}
        }
        const row = document.createElement('div');
        row.style.cssText = 'padding:9px 4px;border-bottom:1px solid rgba(255,255,255,.12);';
        const label = document.createElement('label');
        label.style.cssText = 'display:flex;align-items:center;justify-content:space-between;gap:12px;font-size:14px;';
        const name = document.createElement('span');
        name.textContent = String(config.label || config.id);
        label.appendChild(name);
        let input;
        let output = null;
        const defaultValue = config.defaultValue ?? config.default ?? (type === 'checkbox' ? false : 0);
        if (type === 'slider') {
            input = document.createElement('input'); input.type = 'range';
            const min = Number(config.min ?? 0), max = Number(config.max ?? 100), step = Number(config.step ?? 1);
            if (!Number.isFinite(min) || !Number.isFinite(max) || !Number.isFinite(step) || max <= min || step <= 0) throw new TypeError(`Plage de curseur invalide : ${config.id}`);
            input.min = String(min); input.max = String(max); input.step = String(step);
            input.style.cssText = 'width:100%;accent-color:#7bc96f;';
            output = document.createElement('output'); output.style.cssText = 'min-width:58px;text-align:right;font-weight:700;';
            label.appendChild(output);
            const initial = Number(saved ?? defaultValue);
            input.value = String(Number.isFinite(initial) ? Math.max(Number(input.min), Math.min(Number(input.max), initial)) : Number(defaultValue) || Number(input.min));
        } else if (type === 'checkbox') {
            input = document.createElement('input'); input.type = 'checkbox'; input.checked = saved === null ? Boolean(defaultValue) : saved === 'true';
            input.style.cssText = 'width:18px;height:18px;accent-color:#7bc96f;'; label.appendChild(input);
        } else {
            input = document.createElement('select'); input.style.cssText = 'max-width:55%;padding:5px;border-radius:5px;';
            const options = Array.isArray(config.options) ? config.options : [];
            if (!options.length) throw new TypeError(`Le paramètre select ${config.id} nécessite des options.`);
            for (const item of options) {
                const option = document.createElement('option'); option.value = String(item.value); option.textContent = String(item.label ?? item.value); input.appendChild(option);
            }
            const requested = String(saved ?? defaultValue);
            input.value = [...input.options].some(option => option.value === requested) ? requested : String(defaultValue);
            if (input.value === '') input.selectedIndex = 0;
            label.appendChild(input);
        }
        row.appendChild(label);
        if (type === 'slider') row.appendChild(input);
        if (config.description) {
            const description = document.createElement('small'); description.textContent = String(config.description);
            description.style.cssText = 'display:block;color:#cbd1d6;margin-top:5px;font-size:12px;'; row.appendChild(description);
        }
        root.appendChild(row);
        const getValue = () => type === 'checkbox' ? input.checked : type === 'slider' ? Number(input.value) : input.value;
        const apply = (persist=true) => {
            const value = getValue();
            if (output) { output.value = `${value}${config.unit || ''}`; output.textContent = output.value; }
            if (persist) { try { localStorage.setItem(storageKey, String(value)); } catch (_) {} }
            try { withOwner(owner, () => config.onChange?.(value)); } catch (error) { console.error(`[La Plaine] Paramètre ${config.id}`, error); }
        };
        input.addEventListener(type === 'slider' ? 'input' : 'change', () => apply(true));
        const handle = {
            id: config.id, element: row, input,
            getValue,
            setValue(value) {
                if (type === 'checkbox') input.checked = Boolean(value);
                else if (type === 'slider') {
                    const number = Number(value);
                    if (!Number.isFinite(number)) throw new RangeError(`Valeur invalide pour le paramètre ${config.id}.`);
                    input.value = String(Math.max(Number(input.min), Math.min(Number(input.max), number)));
                }
                else if ([...input.options].some(option => option.value === String(value))) input.value = String(value);
                else throw new RangeError(`Valeur invalide pour le paramètre ${config.id}.`);
                apply(true);
            },
            remove() { row.remove(); settingHandles.delete(handleId); }
        };
        settingHandles.set(handleId, handle);
        apply(false);
        return handle;
    }

    function registerTask(id, callback, intervalMs = 0, options = {}) {
        if (typeof id !== 'string' || !/^[a-zA-Z0-9_.-]{1,100}$/.test(id) || typeof callback !== 'function') throw new TypeError('Une tâche doit avoir un id valide et une fonction.');
        if (!window.LaPlaineUpdateManager) throw new Error('Le planificateur du jeu est indisponible.');
        const owner = currentOwner();
        return window.LaPlaineUpdateManager.register(`${owner}:${id}`, context => withOwner(owner, () => callback(context)), intervalMs, options);
    }

    function registerMenuCategory(config) {
        if (!config || !/^[a-z0-9_-]{1,48}$/i.test(config.id || '') || !config.title) throw new TypeError('Une catégorie de menu nécessite id et title.');
        if (menuCategories.has(config.id)) throw new Error(`Catégorie déjà enregistrée : ${config.id}`);
        menuCategories.set(config.id, config);
        const attach = () => {
            const detail = document.getElementById('settings-category-content'); const nav = document.querySelector('.settings-category-nav');
            if (!detail || !nav || document.getElementById(`lp-mod-category-${config.id}`)) return;
            const button = document.createElement('button'); button.type = 'button'; button.className = 'btn-menu settings-category-button'; button.textContent = config.title;
            const pane = document.createElement('section'); pane.id = `lp-mod-category-${config.id}`; pane.className = 'settings-pane'; pane.hidden = true;
            const heading = document.createElement('h4'); heading.className = 'settings-subtitle'; heading.textContent = config.description || config.title; pane.appendChild(heading);
            if (typeof config.render === 'function') { try { config.render(pane); } catch (error) { console.error('[La Plaine] Erreur de catégorie mod', error); } }
            button.addEventListener('click', () => { const home = document.getElementById('settings-home'); const view = document.getElementById('settings-category-view'); if (home) home.hidden = true; if (view) view.hidden = false; document.getElementById('settings-category-title').textContent = config.title; detail.querySelectorAll('.settings-pane').forEach(p => p.hidden = p !== pane); });
            nav.appendChild(button); detail.appendChild(pane);
        };
        window.addEventListener('laplaine:menu-ready', attach, { once: true }); if (document.getElementById('settings-category-content')) attach();
        return { remove() { menuCategories.delete(config.id); document.getElementById(`lp-mod-category-${config.id}`)?.remove(); } };
    }

    function registerWorldCreationOption(config) {
        if (!config || !/^[a-z0-9_-]{1,48}$/i.test(config.id || '') || !config.label) throw new TypeError('Une option de monde nécessite id et label.');
        if (worldOptions.has(config.id)) throw new Error(`Option de monde déjà enregistrée : ${config.id}`);
        worldOptions.set(config.id, config);
        const attach = () => {
            const root = document.getElementById('lp-world-creation-options'); if (!root || root.querySelector(`[data-mod-world-option="${config.id}"]`)) return;
            const row = document.createElement('div'); row.className = 'setting-item'; row.dataset.modWorldOption = config.id;
            const label = document.createElement('label'); label.textContent = config.label; let input;
            if (config.type === 'select') { input = document.createElement('select'); for (const item of (Array.isArray(config.options) ? config.options : [])) { const option = document.createElement('option'); option.value = String(item.value); option.textContent = String(item.label); input.appendChild(option); } }
            else if (config.type === 'text') { input = document.createElement('input'); input.type = 'text'; input.maxLength = 128; input.value = String(config.defaultValue || ''); }
            else if (config.type === 'checkbox') { input = document.createElement('input'); input.type = 'checkbox'; input.checked = Boolean(config.defaultValue); }
            else { input = document.createElement('input'); input.type = 'number'; input.min = String(config.min ?? 0); input.max = String(config.max ?? 100); input.value = String(config.defaultValue ?? 0); }
            input.dataset.modOptionId = config.id; label.appendChild(input); row.appendChild(label); root.appendChild(row);
        };
        window.addEventListener('laplaine:menu-ready', attach, { once: true }); attach();
        return { getValue() { const input = document.querySelector(`[data-mod-option-id="${config.id}"]`); return input ? (input.type === 'checkbox' ? input.checked : input.value) : config.defaultValue; }, remove() { worldOptions.delete(config.id); document.querySelector(`[data-mod-world-option="${config.id}"]`)?.remove(); } };
    }

    function registerMenuButton(config) {
        if (!config || !/^[a-z0-9_-]{1,48}$/i.test(config.id || '') || !config.label || typeof config.onClick !== 'function') throw new TypeError('Un bouton de menu nécessite id, label et onClick().');
        if (menuButtons.has(config.id)) throw new Error(`Bouton déjà enregistré : ${config.id}`);
        const attach = () => { const root = document.querySelector('.menu-container'); if (!root || root.querySelector(`[data-mod-menu-button="${config.id}"]`)) return; const button = document.createElement('button'); button.type = 'button'; button.className = 'btn-menu'; button.dataset.modMenuButton = config.id; button.textContent = config.label; button.addEventListener('click', () => config.onClick()); root.appendChild(button); menuButtons.set(config.id, button); };
        if (document.querySelector('.menu-container')) attach(); else window.addEventListener('DOMContentLoaded', attach, { once: true });
        return { remove() { menuButtons.get(config.id)?.remove(); menuButtons.delete(config.id); } };
    }

    window.LaPlaineAPI = Object.freeze({
        apiVersion: 5,
        on, emit,
        registerMenuCategory, registerMenuButton, registerWorldCreationOption,
        getWorldCreationOptions() { return [...worldOptions.entries()].map(([id, config]) => { const input = document.querySelector(`[data-mod-option-id="${id}"]`); return { id, value: input ? (input.type === 'checkbox' ? input.checked : input.value) : config.defaultValue }; }); },
        registerSetting,
        registerTask,
        openSettings() {
            const root = getModSettingsRoot();
            if (!root) return false;
            root.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            return true;
        },
        registerContent(category, definition) {
            const registry = window.LaPlaineContentRegistries?.[category];
            if (!registry) throw new Error(`Registre de contenu inconnu : ${category}`);
            return registry.register({ ...definition, source: window.LaPlaineCurrentModId || definition?.source || 'laplaine' });
        },
        getDiagnostics() { return window.LaPlaineEngine?.getDiagnostics?.() || {}; },
        registerBlock(data) {
            if (!window.blockRegistry) throw new Error('Le registre de blocs n’est pas prêt.');
            if (!data || !Number.isSafeInteger(Number(data.id)) || Number(data.id) <= 0 || !data.name) throw new TypeError('Un bloc doit avoir un id numérique positif et un nom.');
            if (window.blockRegistry.get(Number(data.id))) throw new Error(`Identifiant de bloc déjà utilisé : ${data.id}`);
            const block = { ...data, id: Number(data.id), textures: { ...(data.textures || {}) } };
            for (const [face, path] of Object.entries(block.textures)) if (typeof path === 'string' && path && !/^(https?:|data:|blob:|\/)/.test(path)) block.textures[face] = safeAssetUrl(data.modId || window.LaPlaineCurrentModId, path);
            window.blockRegistry.register(block);
            const result = window.blockRegistry.get(Number(data.id));
            emit('registry:block-registered', { block: result });
            return result;
        },
        updateBlock(id, patch) {
            const block = window.blockRegistry?.get(Number(id));
            if (!block) throw new Error(`Bloc introuvable : ${id}`);
            Object.assign(block, patch || {});
            emit('registry:block-updated', { block }); return block;
        },
        removeBlock(id) {
            const registry = window.blockRegistry;
            const removed = registry?.blocks?.delete(Number(id)) || false;
            if (removed) emit('registry:block-removed', { id: Number(id) });
            return removed;
        },
        registerItem(data) {
            if (!window.itemsRegistry) throw new Error('Le registre d’objets n’est pas prêt.');
            if (window.itemsRegistry.get(data?.id)) throw new Error(`Identifiant d’objet déjà utilisé : ${data.id}`);
            const item = { ...data };
            if (typeof item.texture === 'string' && item.texture && !/^(https?:|data:|blob:|\/)/.test(item.texture)) item.texture = safeAssetUrl(data.modId || window.LaPlaineCurrentModId, item.texture);
            if (item.textures && typeof item.textures === 'object') {
                item.textures = { ...item.textures };
                for (const [face, path] of Object.entries(item.textures)) {
                    if (typeof path === 'string' && path && !/^(https?:|data:|blob:|\/)/.test(path)) item.textures[face] = safeAssetUrl(data.modId || window.LaPlaineCurrentModId, path);
                }
            }
            if (!window.itemsRegistry.register(item)) throw new Error('Impossible d’enregistrer cet objet.');
            return window.itemsRegistry.get(data.id);
        },
        updateItem(id, patch) {
            const item = window.itemsRegistry?.get(id); if (!item) throw new Error(`Objet introuvable : ${id}`);
            Object.assign(item, patch || {}); emit('registry:item-updated', { item }); return item;
        },
        removeItem(id) { const removed = window.itemsRegistry?.items?.delete(Number(id)) || false; if (removed) emit('registry:item-removed', { id: Number(id) }); return removed; },
        registerMob(data) {
            if (!window.mobRegistry) throw new Error('Le registre de créatures n’est pas prêt.');
            if (!data || typeof data !== 'object') throw new TypeError('Définition de créature invalide.');
            if (data.id && window.mobRegistry.getAll().some(m => m.id === data.id)) throw new Error(`Identifiant de créature déjà utilisé : ${data.id}`);
            return window.mobRegistry.register(data);
        },
        updateMob(id, patch) {
            const mob = window.mobRegistry?.getAll?.().find(m => m.id === id); if (!mob) throw new Error(`Créature introuvable : ${id}`);
            Object.assign(mob, patch || {}); emit('registry:mob-updated', { mob }); return mob;
        },
        removeMob(id) {
            const list = window.mobRegistry?.definitions; if (!Array.isArray(list)) return false;
            const index = list.findIndex(m => m.id === id); if (index < 0) return false;
            list.splice(index, 1); emit('registry:mob-removed', { id }); return true;
        },
        registerRecipe(data) {
            const recipes = window.craftRegistry?.recipes;
            if (!Array.isArray(recipes)) throw new Error('Le registre de recettes n’est pas prêt.');
            if (!data?.id || !Array.isArray(data.pattern) || !data.output) throw new TypeError('Une recette doit avoir id, pattern et output.');
            if (recipes.some(r => r.id === data.id)) throw new Error(`Identifiant de recette déjà utilisé : ${data.id}`);
            recipes.push(data); emit('registry:recipe-registered', { recipe: data }); return data;
        },
        registerDimension(data) {
            if (!window.dimensionRegistry) throw new Error('Le registre de dimensions n’est pas prêt.');
            return window.dimensionRegistry.register(data);
        },
        registerFeature(id, definition) {
            if (!window.LaPlaineFeatureRegistry) throw new Error('Le registre de fonctionnalités n’est pas prêt.');
            return window.LaPlaineFeatureRegistry.register(id, definition);
        },
        registerTexture(id, relativePath, modId) {
            if (typeof id !== 'string' || !id.trim()) throw new TypeError('Identifiant de texture requis.');
            const url = safeAssetUrl(modId || window.LaPlaineCurrentModId, relativePath); textureHandles.set(id, url); return url;
        },
        getTexture(id) { return textureHandles.get(id) || null; },
        registerSound(id, relativePath, modId) {
            if (typeof id !== 'string' || !id.trim()) throw new TypeError('Identifiant de son requis.');
            const url = safeAssetUrl(modId || window.LaPlaineCurrentModId, relativePath); soundHandles.set(id, url); return url;
        },
        playSound(id, options={}) {
            const url = soundHandles.get(id); if (!url) throw new Error(`Son de mod introuvable : ${id}`);
            const audio = new Audio(url); audio.volume = Math.max(0, Math.min(1, Number(options.volume ?? 1))); audio.loop = Boolean(options.loop); return audio.play();
        },
        registerInventoryExtension(config) {
            if (!config?.id || typeof config.render !== 'function') throw new TypeError('Une extension doit avoir un id et render(container).');
            if (inventoryHandles.has(config.id)) throw new Error(`Extension déjà enregistrée : ${config.id}`);
            inventoryHandles.set(config.id, config);
            const panel = document.getElementById('inventory-panel');
            if (panel) {
                let root = panel.querySelector('#lp-mod-inventory-extensions');
                if (!root) { root = document.createElement('div'); root.id = 'lp-mod-inventory-extensions'; root.style.cssText = 'margin-top:12px;padding-top:12px;border-top:1px solid #777;'; (panel.querySelector('.inv-box') || panel).appendChild(root); }
                const section = document.createElement('section'); section.dataset.modInventoryId = config.id;
                const title = document.createElement('h3'); title.textContent = config.title || config.id; section.appendChild(title);
                config.render(section); root.appendChild(section);
            }
            return config;
        },
        getBlock(id) { return window.blockRegistry?.get(Number(id)) || null; },
        getItem(id) { return window.itemsRegistry?.get(Number(id)) || null; },
        getMobs() { return window.mobRegistry?.getAll?.() || []; },
        getSetting(id, modId = null) { return settingHandles.get(`${modId || currentOwner()}:${id}`) || null; },
        getSettings(modId = null) {
            const owner = modId || currentOwner();
            return Object.fromEntries([...settingHandles.entries()].filter(([key]) => key.startsWith(`${owner}:`)).map(([key, handle]) => [key.slice(owner.length + 1), handle.getValue()]));
        }
    });
    window.LaPlaineModLoader = Object.freeze({ loadEnabledMods, getLoaded: () => [...loaded], getErrors: () => [...errors] });
})();
