/* La Plaine 0.2.7.0 — item registry and extension API. */
(function () {
    'use strict';
    const warnings = window.LaPlaineWarnings = window.LaPlaineWarnings || [];
    const warn = (message, detail) => { warnings.push({scope:'items', message, detail:detail||null}); console.warn('[La Plaine][Item]',message,detail||''); };
    const pick=(data,camel,kebab,fallback)=>data[camel]!==undefined?data[camel]:(data[kebab]!==undefined?data[kebab]:fallback);
    class ItemBehaviorRegistry {
        constructor(){this.behaviors=new Map();}
        register(name,behavior){if(typeof name!=='string'||!name||!behavior||typeof behavior!=='object'){warn('Comportement d’item invalide.',name);return false;}if(this.behaviors.has(name)){warn(`Comportement d’item déjà enregistré : ${name}`);return false;}this.behaviors.set(name,Object.freeze({...behavior,id:name}));return true;}
        get(name){return this.behaviors.get(name)||null;}
        getAll(){return [...this.behaviors.values()];}
        async dispatch(itemId,eventName,context={}){const item=window.itemsRegistry?.get(itemId);if(!item)return[];const out=[];for(const name of item.behaviors||[]){const behavior=this.get(name);if(!behavior){warn(`Comportement inconnu « ${name} » pour l’item ${itemId}.`);continue;}try{if(typeof behavior[eventName]==='function')out.push(await behavior[eventName]({...context,item,behavior:name}));}catch(error){warn(`Erreur ${name}.${eventName}: ${error.message}`);}}return out;}
    }
    class ItemsRegistry {
        constructor(){this.items=new Map();}
        register(data){
            if(!data||!Number.isSafeInteger(Number(data.id))||Number(data.id)<=0||typeof data.name!=='string'||!data.name.trim()){warn('Item ignoré : identifiant ou nom invalide.',data);return false;}
            const id=Number(data.id);if(this.items.has(id)){warn(`Identifiant d’item déjà utilisé : ${id}. Le premier item est conservé.`,data);return false;}
            const textures=data.textures&&typeof data.textures==='object'?{...data.textures}:{};
            const texture=data.texture||textures.all||textures.front||textures.top||'';
            const stack=pick(data,'stackNumber','stack-number',data.stack??100);
            const dynamicLight=Boolean(pick(data,'dynamicLight','dynamic-light',false));
            const behaviors=Array.isArray(data.behaviors)?data.behaviors.map(String):(data.behaviors?[String(data.behaviors)]:[]);
            if(dynamicLight&&!behaviors.includes('dynamic-light'))behaviors.push('dynamic-light');
            if(['armure','armor'].includes(String(data.type||'').toLowerCase())&&!behaviors.includes('armor'))behaviors.push('armor');
            const maxDurability=Math.max(0,Math.floor(Number(data.maxDurability)||0));
            if(maxDurability>0&&!behaviors.includes('durability'))behaviors.push('durability');
            const item={...data,id,name:data.name.trim(),texture,textures,place:data.place==null?null:Number(data.place),tool:Boolean(data.tool||['pickaxe','axe','shovel','sword'].includes(data.type)),type:data.type||null,level:Math.max(1,Number(data.level)||1),stack:Math.max(1,Math.floor(Number(stack)||100)),stackNumber:Math.max(1,Math.floor(Number(stack)||100)),maxDurability,customFile:pick(data,'customFile','custom-file',null),dynamicLight,atlas:Boolean(data.atlas),behaviors};
            this.items.set(id,item);return true;
        }
        get(id){return this.items.get(Number(id))||null;}
        getAll(){return [...this.items.values()];}
        registerBlocks(){if(!window.blockRegistry)return;for(const block of window.blockRegistry.getAll()){if(!this.get(block.id)){const textures=block.itemTexture?{all:block.itemTexture}:{...block.textures};const texture=textures.all||textures.front||textures.top||textures.sides||'';this.register({id:block.id,name:block.name,type:'block',textures,texture,place:block.isFluid?null:block.id,stackNumber:100});}}}
        async loadCustomFiles(loader){const loaded=new Set();for(const item of this.items.values()){if(!item.customFile)continue;let path=String(item.customFile).replace(/\\/g,'/');if(!path.startsWith('/'))path='/'+path;if(!path.startsWith('/static/js/')||path.slice(1).split('/').some(part=>!part||part==='.'||part==='..')){warn(`Chemin custom-file refusé pour l’item ${item.id}.`,item.customFile);continue;}if(loaded.has(path))continue;try{await loader(path);loaded.add(path);}catch(error){warn(`Fichier personnalisé de l’item ${item.id} indisponible : ${error.message}`);}}}
    }
    window.itemBehaviorRegistry=window.itemBehaviorRegistry||new ItemBehaviorRegistry();
    window.ItemBehaviorRegistry=ItemBehaviorRegistry;
    window.itemsRegistry=window.itemsRegistry||new ItemsRegistry();
    window.LaPlaineItemAPI=Object.freeze({registry:window.itemsRegistry,behaviors:window.itemBehaviorRegistry,warn});
})();
