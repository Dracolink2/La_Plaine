/* Armor item type: extension point for future slots and statistics. */
window.itemBehaviorRegistry?.register('armor', { description: 'Item de type armure; les emplacements et bonus seront définis ultérieurement.' });
