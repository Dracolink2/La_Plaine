# Installer un mod — La Plaine 0.2.8.0

Créez un dossier par mod dans `mods/` à côté de l'application (ou dans `static/mods/` en mode développement). Chaque mod doit contenir un `manifest.json` et un fichier d'entrée JavaScript.

Exemple de `manifest.json` :

```json
{
  "id": "exemple",
  "name": "Mon premier mod",
  "description": "Ajoute un bloc de démonstration.",
  "version": "1.0.0",
  "api_version": "3",
  "entry": "main.js",
  "author": "Votre nom",
  "category": "Gameplay",
  "menu_settings": true,
  "dependencies": []
}
```

Exemple de `main.js` :

```js
window.LaPlaineAPI.on("game:ready", ({ world, player }) => {
  console.log("Mon mod est prêt", world, player);
});

window.LaPlaineAPI.registerBlock({
  id: 9001,
  name: "Bloc de démonstration",
  textures: { all: "/static/textures/pierres/stone/stone.png" }
});
```

## Extensions du menu (API v3)

```js
// Ajoute une catégorie dans Paramètres.
LaPlaineAPI.registerMenuCategory({
  id: "mon-menu", title: "Mon mod", description: "Options du mod",
  render(container) {
    const label = document.createElement("label");
    label.textContent = "Activer mon option ";
    const toggle = document.createElement("input"); toggle.type = "checkbox";
    label.appendChild(toggle); container.appendChild(label);
  }
});

// Ajoute une option au formulaire de création de monde.
LaPlaineAPI.registerWorldCreationOption({
  id: "generation-speciale", label: "Génération spéciale",
  type: "checkbox", defaultValue: false
});

// Ajoute un bouton au menu principal.
LaPlaineAPI.registerMenuButton({ id: "mon-ecran", label: "Mon écran", onClick() { alert("Bonjour !"); } });
```

Les valeurs des options de création sont transmises à l'API lors de la création du monde et conservées dans ses métadonnées (`world.options`). Les mods restent du JavaScript de confiance exécuté dans le contexte du jeu.

## À savoir

- Les mods sont chargés au démarrage d'une partie ; changer leur activation demande de revenir au menu puis de relancer le jeu.
- Les identifiants de blocs doivent être uniques et ne doivent pas entrer en conflit avec le jeu ou d'autres mods.
- Les scripts de mods s'exécutent dans le contexte JavaScript du jeu et ne sont **pas isolés**. N'installez que du code de confiance.
- Les points d'extension pour les comportements avancés (entités, recettes, événements et interfaces) restent à compléter avant de considérer l'API comme stable.
