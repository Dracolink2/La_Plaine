
(function installResourceManager() {
    'use strict';

    const STORAGE_KEY = 'laPlaine.assetPack';
    const LEGACY_STORAGE_KEY = 'laPlaine.texturePack';
    const originalLoad = THREE.TextureLoader.prototype.load;
    const manifestCache = new Map();
    THREE.Cache.enabled = true;

    function selectedPack() {
        return localStorage.getItem(STORAGE_KEY) || localStorage.getItem(LEGACY_STORAGE_KEY) || 'default';
    }

    function textureRelativePath(url) {
        if (typeof url !== 'string') return null;
        const markers = ['/static/assets/textures/', '/static/textures/'];
        const marker = markers.find(candidate => url.includes(candidate));
        if (!marker) return null;
        const relative = url.slice(url.indexOf(marker) + marker.length).split(/[?#]/, 1)[0];
        if (!relative || relative.split('/').some(part => !part || part === '..' || part === '.')) return null;
        return relative;
    }

    function packTextureUrl(pack, relative) {
        return `/api/asset-packs/${encodeURIComponent(pack)}/assets/textures/${relative.split('/').map(encodeURIComponent).join('/')}`;
    }

    function getManifest(pack) {
        if (!manifestCache.has(pack)) {
            const promise = fetch(`/api/asset-packs/${encodeURIComponent(pack)}/manifest`, { cache: 'no-store' })
                .then(response => response.ok ? response.json() : null)
                .catch(() => null);
            manifestCache.set(pack, promise);
        }
        return manifestCache.get(pack);
    }

    function safePackPath(value) {
        if (typeof value !== 'string') return null;
        const clean = value.replace(/^\/?(?:static\/)?(?:assets\/)?textures\//, '').replace(/^\//, '');
        const parts = clean.replace(/\\/g, '/').split('/');
        return clean && parts.every(part => part && part !== '.' && part !== '..') ? clean : null;
    }

    function mappedTexture(manifest, relative) {
        if (!manifest || typeof manifest !== 'object') return relative;
        const overrides = manifest.texture_overrides || manifest.textureOverrides || {};
        const direct = safePackPath(overrides[relative]);
        if (direct) return direct;
        const groups = manifest.texture_groups || manifest.textureGroups || [];
        for (const group of groups) {
            const sources = Array.isArray(group.sources) ? group.sources : [];
            if (sources.some(source => safePackPath(source) === relative)) {
                const target = safePackPath(group.file || group.gif || group.texture);
                if (target) return target;
            }
        }
        return relative;
    }

    const animatedTextures = new Set();
    let gifFrameScheduled = false;
    function trackGif(texture, url) {
        if (!/\.gif(?:[?#]|$)/i.test(String(url || ''))) return;
        animatedTextures.add(texture);
        if (texture.addEventListener) texture.addEventListener('dispose', () => animatedTextures.delete(texture));
        if (gifFrameScheduled) return;
        gifFrameScheduled = true;
        let lastRefresh = 0;
        const refresh = timestamp => {
            if (!animatedTextures.size) { gifFrameScheduled = false; return; }
            if (timestamp - lastRefresh >= 100) {
                for (const item of animatedTextures) item.needsUpdate = true;
                lastRefresh = timestamp;
            }
            requestAnimationFrame(refresh);
        };
        requestAnimationFrame(refresh);
    }

    function warnTexture(url, error) {
        const warnings = window.LaPlaineWarnings = window.LaPlaineWarnings || [];
        const message = `Texture inaccessible : ${url}`;
        warnings.push({scope:'assets', message, detail:error?.message || null});
        console.warn('[La Plaine][Assets]', message, error || '');
        window.LaPlaineDiagnostics?.display?.();
    }

    function validRect(rect) {
        return rect && Number.isFinite(Number(rect.x)) && Number.isFinite(Number(rect.y)) &&
            Number.isFinite(Number(rect.width)) && Number.isFinite(Number(rect.height)) &&
            Number(rect.x) >= 0 && Number(rect.y) >= 0 && Number(rect.width) > 0 && Number(rect.height) > 0;
    }

    THREE.TextureLoader.prototype.load = function (url, onLoad, onProgress, onError) {
        const relative = textureRelativePath(url);
        const pack = selectedPack();
        if (!relative || pack === 'default') {
            return originalLoad.call(this, url, loaded => { trackGif(loaded, url); if (onLoad) onLoad(loaded); }, onProgress, error => { warnTexture(url, error); if (onError) onError(error); });
        }

        const texture = new THREE.Texture();
        texture.name = relative;
        getManifest(pack).then(manifest => {
            const atlasMap = manifest && manifest.textures && manifest.textures[relative];
            const atlasName = manifest && (manifest.atlas || manifest.atlas_file);
            const mapped = mappedTexture(manifest, relative);
            const individualUrl = `/api/asset-packs/${encodeURIComponent(pack)}/assets/${mapped.split('/').map(encodeURIComponent).join('/')}`;
            const loadIndividual = () => originalLoad.call(this, individualUrl, loaded => {
                texture.image = loaded.image;
                texture.mapping = loaded.mapping;
                texture.wrapS = loaded.wrapS;
                texture.wrapT = loaded.wrapT;
                texture.magFilter = loaded.magFilter;
                texture.minFilter = loaded.minFilter;
                texture.anisotropy = loaded.anisotropy;
                texture.colorSpace = loaded.colorSpace;
                texture.flipY = loaded.flipY;
                texture.needsUpdate = true;
                trackGif(texture, individualUrl);
                if (onLoad) onLoad(texture);
            }, onProgress, error => {
                warnTexture(individualUrl, error);
                if (onError) onError(error);
            });

            if (!atlasName || !validRect(atlasMap)) {
                loadIndividual();
                return;
            }

            const cleanAtlasName = String(atlasName).replace(/^\/?(?:static\/)?textures\//, '');
            if (!cleanAtlasName || cleanAtlasName.split('/').some(part => part === '..' || part === '.')) {
                loadIndividual();
                return;
            }
            const atlasUrl = `/api/asset-packs/${encodeURIComponent(pack)}/assets/${cleanAtlasName.split('/').map(encodeURIComponent).join('/')}`;
            originalLoad.call(this, atlasUrl, atlasTexture => {
                const image = atlasTexture.image;
                const x = Math.floor(Number(atlasMap.x));
                const y = Math.floor(Number(atlasMap.y));
                const width = Math.floor(Number(atlasMap.width));
                const height = Math.floor(Number(atlasMap.height));
                if (!image || x + width > image.width || y + height > image.height) {
                    loadIndividual();
                    return;
                }
                const canvas = document.createElement('canvas');
                canvas.width = width;
                canvas.height = height;
                const context = canvas.getContext('2d');
                context.imageSmoothingEnabled = false;
                context.drawImage(image, x, y, width, height, 0, 0, width, height);
                texture.image = canvas;
                texture.mapping = atlasTexture.mapping;
                texture.wrapS = THREE.ClampToEdgeWrapping;
                texture.wrapT = THREE.ClampToEdgeWrapping;
                texture.magFilter = atlasTexture.magFilter;
                texture.minFilter = atlasTexture.minFilter;
                texture.anisotropy = atlasTexture.anisotropy;
                texture.flipY = atlasTexture.flipY;
                texture.needsUpdate = true;
                trackGif(texture, individualUrl);
                if (onLoad) onLoad(texture);
            }, onProgress, error => {
                loadIndividual();
            });
        });
        return texture;
    };

    async function resolveSoundUrl(url) {
        const pack = selectedPack();
        if (pack === 'default' || typeof url !== 'string') return url;
        const marker = '/static/sounds/';
        const index = url.indexOf(marker);
        if (index < 0) return url;
        const relative = url.slice(index + marker.length).split(/[?#]/, 1)[0];
        if (!relative || relative.split('/').some(part => !part || part === '.' || part === '..')) return url;
        const manifest = await getManifest(pack);
        const overrides = manifest?.sound_overrides || manifest?.soundOverrides || {};
        const mapped = overrides[relative] || relative;
        const clean = String(mapped).replace(/^\/?(?:static\/)?(?:assets\/)?sounds\//, '').replace(/^\//, '');
        if (!clean || clean.split('/').some(part => !part || part === '.' || part === '..')) return url;
        return `/api/asset-packs/${encodeURIComponent(pack)}/assets/sounds/${clean.split('/').map(encodeURIComponent).join('/')}`;
    }

    window.LaPlaineResources = Object.freeze({
        getSelectedTexturePack: selectedPack,
        resolveTextureUrl: (url) => {
            const relative = textureRelativePath(url);
            const pack = selectedPack();
            return relative && pack !== 'default' ? packTextureUrl(pack, relative) : url;
        },
        resolveSoundUrl,
        version: 3
    });
})();
