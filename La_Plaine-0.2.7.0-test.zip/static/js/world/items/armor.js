/* Type d'item armure : point d'extension pour les futurs emplacements et statistiques. */
window.itemBehaviorRegistry?.register('armor', { description: 'Item de type armure; les emplacements et bonus seront définis ultérieurement.' });
