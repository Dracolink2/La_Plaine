/* Lumière dynamique associée aux items tenus en main. */
window.itemBehaviorRegistry?.register('dynamic-light', { description: 'Indique qu’un item peut produire une lumière dynamique.' });
