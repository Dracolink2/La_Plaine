/* Gestion extensible de la durabilité des items. */
window.itemBehaviorRegistry?.register('durability', { description: 'Comportement de durabilité pour les outils et équipements.' });
