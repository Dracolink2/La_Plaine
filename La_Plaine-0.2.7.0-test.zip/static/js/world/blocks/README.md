# Registre des blocs et comportements

`register.js` crée `window.blockRegistry` et `window.blockBehaviorRegistry`. Les définitions de blocs se trouvent dans `static/js/game/blocks/`. Les fichiers JavaScript placés directement dans ce dossier sont détectés par `/api/modules` et chargés automatiquement.

Un fichier de comportement peut enregistrer un comportement ainsi :

```js
window.blockBehaviorRegistry.register('mon-comportement', {
    onPlace(context) { /* context.world, context.player, context.position, context.block */ },
    onBreak(context) { /* appelé lors de la destruction */ },
    onInteract(context) { /* appelé lors d'une interaction */ },
    onContact(context) { /* appelé lors d'un contact configuré */ }
});
```

Dans une définition, ajoutez `behaviors: ['mon-comportement']`. Les clés avec tirets doivent être entre guillemets en JavaScript, par exemple `'damage-per-sec': 0.5`. `custom-file` charge un script sous `/static/js/`.
