/* Interaction avec une interface dédiée au bloc. */
window.blockBehaviorRegistry?.register('interactive', { description: "Interaction avec une interface dédiée au bloc.", onInteract(context) { if (context.block?.ui && window.BlockUIManager) return window.BlockUIManager.open(context.block, context); } });
