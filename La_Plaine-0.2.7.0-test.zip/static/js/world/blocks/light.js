/* Émission de lumière déclarative. */
window.blockBehaviorRegistry?.register('light', { description: "Émission de lumière déclarative.", onPlace(context) { return Number(context.block?.lightLevel) > 0; } });
