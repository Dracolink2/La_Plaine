/* Textures animées, dont GIF. */
window.blockBehaviorRegistry?.register('animated', { description: "Textures animées, dont GIF.", onLoad(context) { return true; /* Les GIF sont actualisés par le gestionnaire de ressources. */ } });
