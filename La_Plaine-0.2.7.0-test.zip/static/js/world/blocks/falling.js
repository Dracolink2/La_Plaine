/* Bloc soumis à la gravité. */
window.blockBehaviorRegistry?.register('falling', { description: "Bloc soumis à la gravité.", onPlace(context) { if (context && context.world && typeof context.world.scheduleFallingBlock === 'function') return context.world.scheduleFallingBlock(context.position, context.block.id); } });
