(function(){
  'use strict';
  if(!window.THREE) return;
  const canvas=document.getElementById('skin-preview-canvas');
  if(!canvas) return;
  let renderer;
  try { renderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:true}); }
  catch(error){ console.warn('[La Plaine] Aperçu 3D indisponible :',error); return; }
  renderer.setPixelRatio(Math.min(1.5,window.devicePixelRatio||1));
  const scene=new THREE.Scene();
  scene.background=new THREE.Color(0xb7b7b7);
  const camera=new THREE.PerspectiveCamera(34,300/340,.1,50);
  camera.position.set(2.7,1.8,4.5); camera.lookAt(0,.95,0);
  scene.add(new THREE.HemisphereLight(0xffffff,0x777788,1.5));
  const sun=new THREE.DirectionalLight(0xffffff,1.1); sun.position.set(-3,5,4); scene.add(sun);
  const group=new THREE.Group(); scene.add(group);
  let dragging=false,lastX=0,loadToken=0;
  const texLoader=new THREE.TextureLoader();

  function crop(source,x,y,w,h){
    if(!source || !source.complete || !source.naturalWidth || !source.naturalHeight)
      throw new Error('Atlas de skin non chargé ou invalide');
    const c=document.createElement('canvas'); c.width=w; c.height=h;
    const ctx=c.getContext('2d');
    if(!ctx) throw new Error('Canvas 2D indisponible');
    ctx.imageSmoothingEnabled=false;
    ctx.drawImage(source,x,y,w,h,0,0,w,h);
    const t=new THREE.CanvasTexture(c); t.magFilter=THREE.NearestFilter; t.minFilter=THREE.NearestFilter;
    return t;
  }
  function mats(source,u,v,w,h,d){
    const make=t=>new THREE.MeshLambertMaterial({map:t,transparent:true,alphaTest:.1});
    return [make(crop(source,u,v+d,d,h)),make(crop(source,u+d+w,v+d,d,h)),
      make(crop(source,u+d,v,w,d)),make(crop(source,u+d+w,v,w,d)),
      make(crop(source,u+d,v+d,w,h)),make(crop(source,u+d+w+d,v+d,w,h))];
  }
  function addPart(source,size,pos,uv){
    const mesh=new THREE.Mesh(new THREE.BoxGeometry(...size),mats(source,...uv));
    mesh.position.set(...pos); group.add(mesh);
  }
  function clearModel(){
    while(group.children.length){
      const obj=group.children[0]; group.remove(obj);
      obj.geometry?.dispose();
      if(Array.isArray(obj.material)) obj.material.forEach(m=>{m.map?.dispose();m.dispose();});
      else if(obj.material){obj.material.map?.dispose();obj.material.dispose();}
    }
  }
  function setSkin(name){
    const token=++loadToken;
    const safeName=/^Paul(?:[1-9]|10)\.png$/.test(name)?name:'Paul1.png';
    texLoader.load(`/static/textures/skins/${encodeURIComponent(safeName)}`,loadedTexture=>{
      if(token!==loadToken){loadedTexture.dispose();return;}
      const source=loadedTexture.image;
      if(!source || !source.complete || !source.naturalWidth){
        console.warn('[La Plaine] Atlas de skin invalide :',safeName); loadedTexture.dispose(); return;
      }
      try {
        clearModel();
        addPart(source,[.48,.75,.24],[0,1.125,0],[16,16,8,12,4]);
        addPart(source,[.24,.75,.24],[.36,1.125,0],[40,16,4,12,4]);
        addPart(source,[.24,.75,.24],[-.36,1.125,0],[32,48,4,12,4]);
        addPart(source,[.24,.75,.24],[.12,.375,0],[0,16,4,12,4]);
        addPart(source,[.24,.75,.24],[-.12,.375,0],[16,48,4,12,4]);
        addPart(source,[.4,.4,.4],[0,1.7,0],[0,0,8,8,8]);
      } catch(error){ clearModel(); console.error('[La Plaine] Impossible de construire l’aperçu du skin :',error); }
      finally { loadedTexture.dispose(); }
    },undefined,error=>{
      if(token===loadToken) console.warn('[La Plaine] Impossible de charger le skin',safeName,error);
    });
  }
  canvas.addEventListener('pointerdown',e=>{dragging=true;lastX=e.clientX;canvas.setPointerCapture(e.pointerId);});
  canvas.addEventListener('pointermove',e=>{if(!dragging)return;group.rotation.y+=(e.clientX-lastX)*.012;lastX=e.clientX;});
  canvas.addEventListener('pointerup',()=>dragging=false);
  canvas.addEventListener('pointercancel',()=>dragging=false);
  function resize(){const w=Math.max(1,canvas.clientWidth),h=Math.max(1,canvas.clientHeight);renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();}
  if(window.ResizeObserver) new ResizeObserver(resize).observe(canvas); else window.addEventListener('resize',resize);
  resize();
  function animate(){requestAnimationFrame(animate);const modal=canvas.closest('#skins-modal');if(modal&&modal.style.display!=='none'){if(!dragging)group.rotation.y+=.002;renderer.render(scene,camera);}}
  animate();
  setSkin('Paul1.png');
  window.LaPlaineSkinPreview={setSkin};
})();
