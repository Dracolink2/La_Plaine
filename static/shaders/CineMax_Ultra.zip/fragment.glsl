uniform sampler2D tDiffuse;
uniform float uTime;
uniform vec2 uResolution;
varying vec2 vUv;

float hash21(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

vec3 sampleScene(vec2 uv) {
    return texture2D(tDiffuse, clamp(uv, vec2(0.001), vec2(0.999))).rgb;
}

void main() {
    vec2 uv = vUv;
    vec2 px = 1.0 / max(uResolution, vec2(2.0));
    vec2 centered = uv - 0.5;

    // Distorsion de lentille quasi imperceptible, plus visible sur les bords.
    vec2 lensUV = uv + centered * dot(centered, centered) * 0.045;
    float edge = smoothstep(0.15, 0.72, length(centered));
    float ca = (0.0007 + edge * 0.0018);
    float r = sampleScene(lensUV + vec2(ca, 0.0)).r;
    float g = sampleScene(lensUV).g;
    float b = sampleScene(lensUV - vec2(ca, 0.0)).b;
    vec3 color = vec3(r, g, b);

    // Bloom léger en 8 directions, concentré sur les zones lumineuses.
    vec3 bloom = vec3(0.0);
    bloom += sampleScene(lensUV + px * vec2( 2.0, 0.0));
    bloom += sampleScene(lensUV + px * vec2(-2.0, 0.0));
    bloom += sampleScene(lensUV + px * vec2(0.0,  2.0));
    bloom += sampleScene(lensUV + px * vec2(0.0, -2.0));
    bloom += sampleScene(lensUV + px * vec2( 1.5, 1.5));
    bloom += sampleScene(lensUV + px * vec2(-1.5, 1.5));
    bloom += sampleScene(lensUV + px * vec2( 1.5,-1.5));
    bloom += sampleScene(lensUV + px * vec2(-1.5,-1.5));
    bloom *= 0.125;
    float bright = max(max(bloom.r, bloom.g), bloom.b);
    float highlightMask = smoothstep(0.48, 0.94, bright);
    color += bloom * highlightMask * 0.19;

    // Color grading : ombres légèrement teal, hautes lumières chaudes.
    float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
    color = mix(vec3(luma), color, 1.20);
    color = (color - 0.5) * 1.12 + 0.5;
    color *= vec3(1.045, 1.015, 0.985);
    color += vec3(0.008, 0.018, 0.030) * (1.0 - smoothstep(0.15, 0.75, luma));
    color += vec3(0.035, 0.020, 0.004) * smoothstep(0.55, 0.98, luma);

    // Petit voile lumineux doré, façon objectif au soleil.
    float flare = exp(-length((uv - vec2(0.12, 0.88)) * vec2(1.0, 1.25)) * 7.0);
    float flareRay = exp(-abs((uv.y - 0.84) - (uv.x - 0.12) * 0.12) * 75.0);
    color += vec3(0.085, 0.050, 0.018) * flare * 0.30;
    color += vec3(0.035, 0.023, 0.008) * flareRay * flare * 0.20;

    // Grain fin animé : donne de la texture sans cacher le décor.
    float grain = hash21(floor(uv * uResolution * 0.72) + floor(uTime * 24.0)) - 0.5;
    color += grain * 0.026;

    // Vignettage cinématographique avec centre doux.
    float vignette = smoothstep(0.82, 0.22, length(centered * vec2(1.0, 1.04)));
    color *= mix(0.72, 1.0, vignette);

    // Courbe de contraste douce et roll-off des hautes lumières.
    color = max(color, vec3(0.0));
    color = color / (vec3(1.0) + color * 0.10);
    color = pow(clamp(color, 0.0, 1.0), vec3(0.96));

    gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
