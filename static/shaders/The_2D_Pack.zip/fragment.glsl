uniform sampler2D tDiffuse;
uniform float uTime;
uniform vec2 uResolution;
varying vec2 vUv;
void main() {
    vec2 grid = max(vec2(240.0, 135.0), vec2(2.0));
    vec2 uv = (floor(vUv * grid) + 0.5) / grid;
    vec3 c = texture2D(tDiffuse, uv).rgb;
    // Palette courte façon jeu rétro, en conservant une image lisible.
    c = floor(clamp(c, 0.0, 1.0) * 5.0 + 0.5) / 5.0;
    float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(vec3(l), c, 1.12);
    c = (c - 0.5) * 1.08 + 0.5;
    // Trame discrète pour donner une petite esthétique de console rétro.
    float scan = 0.97 + 0.03 * sin(floor(vUv.y * grid.y) * 3.14159);
    c *= scan;
    gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
