uniform sampler2D tDiffuse;
uniform float uTime;
uniform vec2 uResolution;
varying vec2 vUv;
void main() {
    vec4 color = texture2D(tDiffuse, vUv);
    vec3 c = max(color.rgb, vec3(0.0));
    float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(vec3(luma), c, 1.22);
    c = (c - 0.5) * 1.06 + 0.5;
    gl_FragColor = vec4(clamp(c, 0.0, 1.0), color.a);
}
