uniform sampler2D tDiffuse;
uniform float uTime;
uniform vec2 uResolution;
varying vec2 vUv;

float hash(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

void main() {
    vec2 uv = vUv;
    float time = uTime;

    // Micro-tremblement horizontal et grosses perturbations de bande.
    float row = floor(uv.y * 42.0);
    float rowNoise = hash(vec2(row, floor(time * 13.0)));
    float glitch = step(0.965, hash(vec2(floor(time * 7.0), row)))
                 * (hash(vec2(row, time)) - 0.5) * 0.075;
    float wobble = sin(uv.y * 78.0 + time * 9.0) * 0.0018;
    uv.x += wobble + (rowNoise - 0.5) * 0.0025 + glitch;

    // Léger bombement des bords, typique d'une image analogique.
    vec2 centered = uv - 0.5;
    uv += centered * dot(centered, centered) * 0.10;

    // Aberration chromatique marquée : rouge à gauche, bleu à droite.
    float chroma = 0.0045 + 0.0015 * sin(time * 2.2);
    float r = texture2D(tDiffuse, uv + vec2(chroma, 0.0)).r;
    float g = texture2D(tDiffuse, uv).g;
    float b = texture2D(tDiffuse, uv - vec2(chroma * 1.35, 0.0)).b;
    vec3 color = vec3(r, g, b);

    // Contraste légèrement délavé et dominante magenta/bleutée.
    color = (color - 0.5) * 1.18 + 0.48;
    color *= vec3(1.08, 0.96, 1.10);

    // Lignes horizontales visibles.
    float scan = 0.78 + 0.22 * sin(uv.y * uResolution.y * 1.05);
    color *= scan;

    // Bande de tracking qui défile avec un bord lumineux.
    float bandY = fract(time * 0.19 + 0.15);
    float distBand = abs(uv.y - bandY);
    float band = exp(-distBand * 95.0);
    float bandEdge = exp(-abs(distBand - 0.012) * 320.0);
    color += vec3(0.08, 0.10, 0.15) * band;
    color += vec3(0.16, 0.12, 0.20) * bandEdge;

    // Bruit vidéo animé, renforcé dans les ombres.
    float noise = hash(floor(uv * uResolution * 0.65) + vec2(floor(time * 24.0), floor(time * 17.0))) - 0.5;
    color += noise * 0.105;

    // Vignettage analogique.
    float vignette = 1.0 - smoothstep(0.30, 0.78, length(centered));
    color *= mix(0.68, 1.0, vignette);

    // Fine barre de synchronisation instable en bas de l'image.
    float bottomNoise = step(0.88, hash(vec2(floor(uv.x * 90.0), floor(time * 18.0))));
    float bottomLine = 1.0 - smoothstep(0.0, 0.025, uv.y);
    color += vec3(0.10, 0.13, 0.18) * bottomNoise * bottomLine;

    gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
