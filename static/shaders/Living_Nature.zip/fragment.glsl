uniform sampler2D tDiffuse;
uniform float uTime;
uniform vec2 uResolution;
varying vec2 vUv;
void main() {
    vec3 c = texture2D(tDiffuse, vUv).rgb;
    float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
    // Verts plus riches, hautes lumières légèrement chaudes, sans faux photoréalisme.
    c.g *= 1.035;
    c = mix(vec3(luma), c, 1.08);
    c += vec3(0.012, 0.018, 0.004) * smoothstep(0.18, 0.75, luma);
    float vignette = smoothstep(0.95, 0.25, length((vUv - 0.5) * vec2(0.9, 1.0)));
    c *= mix(0.94, 1.0, vignette);
    gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
