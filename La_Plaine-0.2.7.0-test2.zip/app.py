import os
import sqlite3
import secrets
from datetime import datetime, timezone
import math
import json
import sys
import shutil
import io
import zipfile
import re
import hashlib
import socket
import unicodedata

from flask import Flask, render_template, jsonify, request, send_file, send_from_directory, abort

RESOURCE_DIR = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
if getattr(sys, "frozen", False):
    DATA_DIR = os.path.dirname(os.path.abspath(sys.executable))
else:
    DATA_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(
    __name__,
    template_folder=os.path.join(RESOURCE_DIR, "templates"),
    static_folder=os.path.join(RESOURCE_DIR, "static"),
)

                                                                              
                                
                                                                              

@app.route("/favicon.ico")
@app.route("/static/favicon.ico")
def favicon():
    return send_from_directory(os.path.join(app.static_folder, 'assets', 'favicons'), "favicon.ico", mimetype="image/vnd.microsoft.icon")


BASE_DIR = DATA_DIR
DATABASE = os.path.join(DATA_DIR, "worlds.db")
_legacy_database = os.path.join(RESOURCE_DIR, "worlds.db")
if not os.path.exists(DATABASE) and os.path.isfile(_legacy_database) and os.path.abspath(_legacy_database) != os.path.abspath(DATABASE):
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        shutil.copy2(_legacy_database, DATABASE)
    except OSError:
        pass




ASSET_PACK_DIRS = [
    os.path.join(DATA_DIR, "asset_packs"),
    os.path.join(RESOURCE_DIR, "extras", "asset_packs"),
    os.path.join(DATA_DIR, "texture_packs"),  # compatibilité avec les anciens packs
    os.path.join(RESOURCE_DIR, "static", "texture_packs"),
]
TEXTURE_PACK_DIRS = ASSET_PACK_DIRS
os.makedirs(os.path.join(DATA_DIR, "asset_packs"), exist_ok=True)
MOD_DIRS = [
    os.path.join(DATA_DIR, "mods"),
    os.path.join(RESOURCE_DIR, "static", "mods"),
]
SHADER_DIRS = [
    os.path.join(DATA_DIR, "shaders"),
    os.path.join(RESOURCE_DIR, "static", "shaders"),
]

def _safe_id(value):
    """Valide un identifiant de pack/mod avant tout accès au système de fichiers."""
    return bool(value and re.fullmatch(r"[A-Za-z0-9_-]{1,80}", value))

def _manifest_from_folder(folder, fallback_id):
    manifest_path = os.path.join(folder, "manifest.json")
    try:
        with open(manifest_path, "r", encoding="utf-8") as stream:
            data = json.load(stream)
        if not isinstance(data, dict):
            return None
        data.setdefault("id", fallback_id)
        data.setdefault("name", fallback_id)
        data.setdefault("description", "")
        data.setdefault("version", "1.0.0")
        return data
    except (OSError, ValueError, TypeError):
        return None


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def get_db():
    db = sqlite3.connect(DATABASE)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    return db


def init_db():
    db = get_db()
    db.executescript("""
        CREATE TABLE IF NOT EXISTS worlds (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            seed TEXT NOT NULL,
            created_at TEXT NOT NULL,
            last_played_at TEXT NOT NULL,
            options_json TEXT NOT NULL DEFAULT '{}'
        );

        CREATE TABLE IF NOT EXISTS block_changes (
            world_id INTEGER NOT NULL,
            dimension TEXT NOT NULL,
            x INTEGER NOT NULL,
            y INTEGER NOT NULL,
            z INTEGER NOT NULL,
            block_id INTEGER NOT NULL,
            PRIMARY KEY (world_id, dimension, x, y, z),
            FOREIGN KEY (world_id) REFERENCES worlds(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS player_state (
            world_id INTEGER NOT NULL,
            dimension TEXT NOT NULL,
            x REAL NOT NULL,
            y REAL NOT NULL,
            z REAL NOT NULL,
            rot_x REAL NOT NULL DEFAULT 0,
            rot_y REAL NOT NULL DEFAULT 0,
            health REAL NOT NULL DEFAULT 9,
            selected_slot INTEGER NOT NULL DEFAULT 0,
            camera_mode INTEGER NOT NULL DEFAULT 0,
            velocity_x REAL NOT NULL DEFAULT 0,
            velocity_y REAL NOT NULL DEFAULT 0,
            velocity_z REAL NOT NULL DEFAULT 0,
            inventory_json TEXT NOT NULL DEFAULT '[]',
            PRIMARY KEY (world_id, dimension),
            FOREIGN KEY (world_id) REFERENCES worlds(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS world_state (
            world_id INTEGER PRIMARY KEY,
            current_dimension TEXT NOT NULL DEFAULT 'overworld',
            day_time REAL NOT NULL DEFAULT 48,
            generation_version INTEGER NOT NULL DEFAULT 1,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (world_id) REFERENCES worlds(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS block_data (
            world_id INTEGER NOT NULL,
            dimension TEXT NOT NULL,
            x INTEGER NOT NULL,
            y INTEGER NOT NULL,
            z INTEGER NOT NULL,
            data_json TEXT NOT NULL DEFAULT '{}',
            updated_at TEXT NOT NULL,
            PRIMARY KEY (world_id, dimension, x, y, z),
            FOREIGN KEY (world_id) REFERENCES worlds(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS generated_chunks (
            world_id INTEGER NOT NULL,
            dimension TEXT NOT NULL,
            chunk_x INTEGER NOT NULL,
            chunk_z INTEGER NOT NULL,
            generation_version INTEGER NOT NULL DEFAULT 1,
            generated_at TEXT NOT NULL,
            PRIMARY KEY (world_id, dimension, chunk_x, chunk_z),
            FOREIGN KEY (world_id) REFERENCES worlds(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS multiplayer_accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            world_id INTEGER NOT NULL,
            username TEXT NOT NULL,
            username_key TEXT NOT NULL,
            token_hash TEXT NOT NULL,
            skin TEXT NOT NULL DEFAULT 'Paul1.png',
            state_json TEXT NOT NULL DEFAULT '{}',
            last_seen TEXT,
            created_at TEXT NOT NULL,
            UNIQUE(world_id, username_key),
            FOREIGN KEY (world_id) REFERENCES worlds(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS multiplayer_chat (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            world_id INTEGER NOT NULL,
            account_id INTEGER NOT NULL,
            username TEXT NOT NULL,
            message TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY (world_id) REFERENCES worlds(id) ON DELETE CASCADE,
            FOREIGN KEY (account_id) REFERENCES multiplayer_accounts(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_block_changes_world_dimension
            ON block_changes(world_id, dimension);

        CREATE INDEX IF NOT EXISTS idx_player_state_world
            ON player_state(world_id);

        CREATE INDEX IF NOT EXISTS idx_generated_chunks_world_dimension
            ON generated_chunks(world_id, dimension);
    """)
                                                                          
                                                
    world_columns = {row[1] for row in db.execute("PRAGMA table_info(worlds)").fetchall()}
    if "options_json" not in world_columns:
        db.execute("ALTER TABLE worlds ADD COLUMN options_json TEXT NOT NULL DEFAULT '{}'")

    existing = {row[1] for row in db.execute("PRAGMA table_info(player_state)").fetchall()}
    migrations = {
        "health": "REAL NOT NULL DEFAULT 9",
        "selected_slot": "INTEGER NOT NULL DEFAULT 0",
        "camera_mode": "INTEGER NOT NULL DEFAULT 0",
        "velocity_x": "REAL NOT NULL DEFAULT 0",
        "velocity_y": "REAL NOT NULL DEFAULT 0",
        "velocity_z": "REAL NOT NULL DEFAULT 0",
        "inventory_json": "TEXT NOT NULL DEFAULT '[]'",
    }
    for column, definition in migrations.items():
        if column not in existing:
            db.execute(f"ALTER TABLE player_state ADD COLUMN {column} {definition}")

    db.commit()
    db.close()


                                                          
init_db()


def world_to_dict(row):
    return {
        "id": row["id"],
        "name": row["name"],
        "seed": row["seed"],
        "created_at": row["created_at"],
        "last_played_at": row["last_played_at"],
        "options": json.loads(row["options_json"] or "{}") if "options_json" in row.keys() else {},
    }


def get_world_or_404(db, world_id):
    row = db.execute(
        "SELECT * FROM worlds WHERE id = ?",
        (world_id,)
    ).fetchone()

    if row is None:
        return None

    return row


                                                                              
       
                                                                              

@app.route('/')
def menu():
    return render_template('menu.html')


@app.route('/game')
def game():
    return render_template('index.html')


                                                                              
              
                                                                              

@app.route('/api/worlds', methods=['GET'])
def list_worlds():
    db = get_db()

    rows = db.execute("""
        SELECT *
        FROM worlds
        ORDER BY last_played_at DESC, id DESC
    """).fetchall()

    db.close()

    return jsonify({
        "worlds": [world_to_dict(row) for row in rows]
    })


@app.route('/api/worlds', methods=['POST'])
def create_world():
    data = request.get_json(silent=True) or {}

    name = str(data.get("name", "")).strip()
    raw_seed = data.get("seed", "")
    seed = "" if raw_seed is None else str(raw_seed).strip()

    if not name:
        return jsonify({
            "error": "Le nom du monde est obligatoire."
        }), 400

    if len(name) > 64:
        return jsonify({
            "error": "Le nom du monde est trop long (64 caractères maximum)."
        }), 400

                                                    
    if not seed:
        seed = str(secrets.randbits(32))

    if len(seed) > 128:
        return jsonify({
            "error": "La seed est trop longue (128 caractères maximum)."
        }), 400

    options = data.get("options", {})
    if not isinstance(options, dict) or len(options) > 100:
        return jsonify({"error": "Options de monde invalides."}), 400
    try:
        options_json = json.dumps(options, ensure_ascii=False)
        if len(options_json.encode("utf-8")) > 32768:
            return jsonify({"error": "Les options de monde dépassent la taille autorisée."}), 400
    except (TypeError, ValueError):
        return jsonify({"error": "Options de monde invalides."}), 400

    now = utc_now()

    db = get_db()
    cursor = db.execute("""
        INSERT INTO worlds (name, seed, created_at, last_played_at, options_json)
        VALUES (?, ?, ?, ?, ?)
    """, (name, seed, now, now, options_json))

    world_id = cursor.lastrowid
    db.execute("""
        INSERT INTO world_state (world_id, current_dimension, day_time, generation_version, updated_at)
        VALUES (?, 'overworld', 48, 3, ?)
    """, (world_id, now))
    db.commit()

    row = db.execute(
        "SELECT * FROM worlds WHERE id = ?",
        (world_id,)
    ).fetchone()

    db.close()

    return jsonify({
        "world": world_to_dict(row)
    }), 201


@app.route('/api/worlds/<int:world_id>', methods=['GET'])
def get_world(world_id):
    db = get_db()
    row = get_world_or_404(db, world_id)

    if row is None:
        db.close()
        return jsonify({"error": "Monde introuvable."}), 404

                                                                
    now = utc_now()
    db.execute(
        "UPDATE worlds SET last_played_at = ? WHERE id = ?",
        (now, world_id)
    )
    db.commit()

    row = db.execute(
        "SELECT * FROM worlds WHERE id = ?",
        (world_id,)
    ).fetchone()

    db.close()

    return jsonify({
        "world": world_to_dict(row)
    })


@app.route('/api/worlds/<int:world_id>', methods=['DELETE'])
def delete_world(world_id):
    db = get_db()

    row = get_world_or_404(db, world_id)
    if row is None:
        db.close()
        return jsonify({"error": "Monde introuvable."}), 404

    db.execute(
        "DELETE FROM worlds WHERE id = ?",
        (world_id,)
    )
    db.commit()
    db.close()

    return jsonify({
        "ok": True,
        "deleted": world_id
    })


                                                                              
                      
 
             
                                       
                                                                    
                                            
                                                                              

@app.route('/api/worlds/<int:world_id>/changes', methods=['GET'])
def get_block_changes(world_id):
    dimension = str(request.args.get("dimension", "")).strip()

    db = get_db()

    if get_world_or_404(db, world_id) is None:
        db.close()
        return jsonify({"error": "Monde introuvable."}), 404

    if dimension:
        rows = db.execute("""
            SELECT dimension, x, y, z, block_id
            FROM block_changes
            WHERE world_id = ? AND dimension = ?
        """, (world_id, dimension)).fetchall()
    else:
        rows = db.execute("""
            SELECT dimension, x, y, z, block_id
            FROM block_changes
            WHERE world_id = ?
        """, (world_id,)).fetchall()

    db.close()

    return jsonify({
        "changes": [
            {
                "dimension": row["dimension"],
                "x": row["x"],
                "y": row["y"],
                "z": row["z"],
                "block_id": row["block_id"],
            }
            for row in rows
        ]
    })


@app.route('/api/worlds/<int:world_id>/changes', methods=['POST'])
def save_block_changes(world_id):
    data = request.get_json(silent=True) or {}
    changes = data.get("changes")

    if not isinstance(changes, list):
        return jsonify({
            "error": "Le champ 'changes' doit être une liste."
        }), 400

    if len(changes) > 5000:
        return jsonify({
            "error": "Trop de modifications dans une seule requête (5000 maximum)."
        }), 400

    db = get_db()

    if get_world_or_404(db, world_id) is None:
        db.close()
        return jsonify({"error": "Monde introuvable."}), 404

    try:
        for change in changes:
            if not isinstance(change, dict):
                raise ValueError("Modification invalide.")

            dimension = str(change.get("dimension", "")).strip()
            x = int(change["x"])
            y = int(change["y"])
            z = int(change["z"])
            block_id = int(change["block_id"])

            if not dimension:
                raise ValueError("Dimension manquante.")

            if len(dimension) > 64:
                raise ValueError("Nom de dimension trop long.")

            if y < 0 or y >= 128:
                raise ValueError("Coordonnée Y hors limites.")

            if block_id < 0 or block_id > 255:
                raise ValueError("ID de bloc invalide.")

            db.execute("""
                INSERT INTO block_changes (
                    world_id, dimension, x, y, z, block_id
                )
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(world_id, dimension, x, y, z)
                DO UPDATE SET block_id = excluded.block_id
            """, (
                world_id,
                dimension,
                x,
                y,
                z,
                block_id
            ))

        db.commit()

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        db.rollback()
        db.close()
        return jsonify({
            "error": str(exc)
        }), 400

    db.close()

    return jsonify({
        "ok": True,
        "saved": len(changes)
    })


                                                                              
                                       
                                                                              

@app.route('/api/worlds/<int:world_id>/state', methods=['GET'])
def get_world_state(world_id):
    db = get_db()
    if get_world_or_404(db, world_id) is None:
        db.close()
        return jsonify({"error": "Monde introuvable."}), 404

    row = db.execute("SELECT * FROM world_state WHERE world_id = ?", (world_id,)).fetchone()
    if row is None:
        now = utc_now()
        db.execute("""
            INSERT INTO world_state (world_id, current_dimension, day_time, generation_version, updated_at)
            VALUES (?, 'overworld', 48, 3, ?)
        """, (world_id, now))
        db.commit()
        row = db.execute("SELECT * FROM world_state WHERE world_id = ?", (world_id,)).fetchone()

    db.close()
    return jsonify({
        "state": {
            "current_dimension": row["current_dimension"],
            "day_time": row["day_time"],
            "generation_version": row["generation_version"],
            "updated_at": row["updated_at"],
        }
    })


@app.route('/api/worlds/<int:world_id>/state', methods=['PUT'])
def save_world_state(world_id):
    data = request.get_json(silent=True) or {}
    dimension = str(data.get("current_dimension", "overworld")).strip()
    try:
        day_time = float(data.get("day_time", 48))
        generation_version = int(data.get("generation_version", 1))
    except (TypeError, ValueError):
        return jsonify({"error": "État du monde invalide."}), 400

    if not dimension or len(dimension) > 64 or not math.isfinite(day_time) or generation_version < 1:
        return jsonify({"error": "État du monde invalide."}), 400

    db = get_db()
    if get_world_or_404(db, world_id) is None:
        db.close()
        return jsonify({"error": "Monde introuvable."}), 404

    now = utc_now()
    db.execute("""
        INSERT INTO world_state (world_id, current_dimension, day_time, generation_version, updated_at)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(world_id) DO UPDATE SET
            current_dimension = excluded.current_dimension,
            day_time = excluded.day_time,
            generation_version = excluded.generation_version,
            updated_at = excluded.updated_at
    """, (world_id, dimension, day_time, generation_version, now))
    db.execute("UPDATE worlds SET last_played_at = ? WHERE id = ?", (now, world_id))
    db.commit()
    db.close()
    return jsonify({"ok": True})


@app.route('/api/worlds/<int:world_id>/generated-chunks', methods=['GET'])
def get_generated_chunks(world_id):
    dimension = str(request.args.get("dimension", "")).strip()
    db = get_db()
    if get_world_or_404(db, world_id) is None:
        db.close()
        return jsonify({"error": "Monde introuvable."}), 404

    if dimension:
        rows = db.execute("""
            SELECT dimension, chunk_x, chunk_z, generation_version
            FROM generated_chunks
            WHERE world_id = ? AND dimension = ?
        """, (world_id, dimension)).fetchall()
    else:
        rows = db.execute("""
            SELECT dimension, chunk_x, chunk_z, generation_version
            FROM generated_chunks
            WHERE world_id = ?
        """, (world_id,)).fetchall()
    db.close()

    return jsonify({"chunks": [{
        "dimension": row["dimension"],
        "chunk_x": row["chunk_x"],
        "chunk_z": row["chunk_z"],
        "generation_version": row["generation_version"],
    } for row in rows]})


@app.route('/api/worlds/<int:world_id>/generated-chunks', methods=['POST'])
def save_generated_chunks(world_id):
    data = request.get_json(silent=True) or {}
    chunks = data.get("chunks")
    if not isinstance(chunks, list):
        return jsonify({"error": "Le champ 'chunks' doit être une liste."}), 400
    if len(chunks) > 5000:
        return jsonify({"error": "Trop de chunks dans une seule requête (5000 maximum)."}), 400

    db = get_db()
    if get_world_or_404(db, world_id) is None:
        db.close()
        return jsonify({"error": "Monde introuvable."}), 404

    try:
        now = utc_now()
        for chunk in chunks:
            if not isinstance(chunk, dict):
                raise ValueError("Chunk invalide.")
            dimension = str(chunk.get("dimension", "")).strip()
            cx = int(chunk["chunk_x"])
            cz = int(chunk["chunk_z"])
            generation_version = int(chunk.get("generation_version", 1))
            if not dimension or len(dimension) > 64 or generation_version < 1:
                raise ValueError("Métadonnées de chunk invalides.")
            db.execute("""
                INSERT INTO generated_chunks (world_id, dimension, chunk_x, chunk_z, generation_version, generated_at)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(world_id, dimension, chunk_x, chunk_z)
                DO UPDATE SET generation_version = excluded.generation_version
            """, (world_id, dimension, cx, cz, generation_version, now))
        db.commit()
    except (KeyError, TypeError, ValueError, OverflowError):
        db.rollback()
        db.close()
        return jsonify({"error": "Métadonnées de chunk invalides."}), 400

    db.close()
    return jsonify({"ok": True, "saved": len(chunks)})


                                                                              
                          
                                                                              

@app.route('/api/worlds/<int:world_id>/player', methods=['GET'])
def get_player_state(world_id):
    dimension = str(request.args.get("dimension", "")).strip()
    db = get_db()
    if get_world_or_404(db, world_id) is None:
        db.close()
        return jsonify({"error": "Monde introuvable."}), 404

    query = """
        SELECT dimension, x, y, z, rot_x, rot_y, health, selected_slot, camera_mode,
               velocity_x, velocity_y, velocity_z, inventory_json
        FROM player_state
        WHERE world_id = ?
    """
    params = [world_id]
    if dimension:
        query += " AND dimension = ?"
        params.append(dimension)
    rows = db.execute(query, params).fetchall()
    db.close()

    def row_to_state(row):
        try:
            inventory = json.loads(row["inventory_json"] or "[]")
        except (TypeError, ValueError):
            inventory = []
        return {
            "dimension": row["dimension"],
            "x": row["x"], "y": row["y"], "z": row["z"],
            "rot_x": row["rot_x"], "rot_y": row["rot_y"],
            "health": row["health"],
            "selected_slot": row["selected_slot"],
            "camera_mode": row["camera_mode"],
            "velocity_x": row["velocity_x"], "velocity_y": row["velocity_y"], "velocity_z": row["velocity_z"],
            "inventory": inventory,
        }

    if dimension:
        return jsonify({"state": row_to_state(rows[0]) if rows else None})
    return jsonify({"states": [row_to_state(row) for row in rows]})


@app.route('/api/worlds/<int:world_id>/player', methods=['PUT'])
def save_player_state(world_id):
    data = request.get_json(silent=True) or {}
    dimension = str(data.get("dimension", "")).strip()
    if not dimension or len(dimension) > 64:
        return jsonify({"error": "Dimension manquante ou invalide."}), 400

    try:
        values = {
            "x": float(data["x"]), "y": float(data["y"]), "z": float(data["z"]),
            "rot_x": float(data.get("rot_x", 0)), "rot_y": float(data.get("rot_y", 0)),
            "health": float(data.get("health", 9)),
            "selected_slot": int(data.get("selected_slot", 0)),
            "camera_mode": int(data.get("camera_mode", 0)),
            "velocity_x": float(data.get("velocity_x", 0)),
            "velocity_y": float(data.get("velocity_y", 0)),
            "velocity_z": float(data.get("velocity_z", 0)),
        }
        inventory = data.get("inventory", [])
        if not isinstance(inventory, list) or len(inventory) != 36:
            raise ValueError("Inventaire invalide.")
        if not all(math.isfinite(values[key]) for key in ("x", "y", "z", "rot_x", "rot_y", "health", "velocity_x", "velocity_y", "velocity_z")):
            raise ValueError("Valeurs numériques non finies.")
        if values["health"] < 0 or values["health"] > 10 or values["selected_slot"] < 0 or values["selected_slot"] > 8:
            raise ValueError("Vie ou emplacement sélectionné invalide.")
        for slot in inventory:
            if not isinstance(slot, dict): raise ValueError("Objet d’inventaire invalide.")
            item_id, count = int(slot.get("type", 0)), int(slot.get("count", 0))
            if item_id < 0 or item_id > 9007199254740991 or count < 0 or count > 100:
                raise ValueError("Pile d’inventaire invalide.")
        inventory_json = json.dumps(inventory, separators=(",", ":"))
    except (KeyError, TypeError, ValueError, OverflowError):
        return jsonify({"error": "État du joueur invalide."}), 400

    db = get_db()
    if get_world_or_404(db, world_id) is None:
        db.close()
        return jsonify({"error": "Monde introuvable."}), 404

    db.execute("""
        INSERT INTO player_state (
            world_id, dimension, x, y, z, rot_x, rot_y, health, selected_slot,
            camera_mode, velocity_x, velocity_y, velocity_z, inventory_json
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(world_id, dimension) DO UPDATE SET
            x = excluded.x, y = excluded.y, z = excluded.z,
            rot_x = excluded.rot_x, rot_y = excluded.rot_y,
            health = excluded.health, selected_slot = excluded.selected_slot,
            camera_mode = excluded.camera_mode,
            velocity_x = excluded.velocity_x, velocity_y = excluded.velocity_y, velocity_z = excluded.velocity_z,
            inventory_json = excluded.inventory_json
    """, (world_id, dimension, values["x"], values["y"], values["z"], values["rot_x"], values["rot_y"],
          values["health"], values["selected_slot"], values["camera_mode"], values["velocity_x"],
          values["velocity_y"], values["velocity_z"], inventory_json))
    db.execute("UPDATE worlds SET last_played_at = ? WHERE id = ?", (utc_now(), world_id))
    db.commit()
    db.close()
    return jsonify({"ok": True})


                                                                              
                                        
                                                                              




def _merge_account_snapshot(previous_json, incoming):
    try: snapshot = json.loads(previous_json or '{}')
    except (ValueError, TypeError): snapshot = {}
    if not isinstance(snapshot, dict): snapshot = {}
    dimension = str(incoming.get('dimension', 'overworld')) if isinstance(incoming, dict) else 'overworld'
    states = snapshot.get('dimension_states', {})
    if not isinstance(states, dict): states = {}
    if isinstance(incoming, dict): states[dimension] = incoming
    snapshot['dimension_states'] = states
    snapshot['current_state'] = incoming if isinstance(incoming, dict) else snapshot.get('current_state', {})
    return json.dumps(snapshot, ensure_ascii=False, separators=(',', ':'))

def _account_from_request(db, world_id):
    account_id = request.headers.get('X-LaPlaine-Account', '')
    token = request.headers.get('X-LaPlaine-Token', '')
    if not account_id.isdigit() or not token:
        return None
    row = db.execute('SELECT * FROM multiplayer_accounts WHERE id=? AND world_id=?', (int(account_id), world_id)).fetchone()
    if not row:
        return None
    digest = hashlib.sha256(token.encode('utf-8')).hexdigest()
    return row if secrets.compare_digest(digest, row['token_hash']) else None

@app.route('/api/lan/info')
def lan_info():
    addresses = []
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith('127.') and ip not in addresses:
                addresses.append(ip)
    except OSError:
        pass
    return jsonify({'addresses': addresses, 'port': int(os.environ.get('LA_PLAINE_PORT', '5000')), 'host': request.host})

@app.route('/api/worlds/<int:world_id>/multiplayer/register', methods=['POST'])
def multiplayer_register(world_id):
    data = request.get_json(silent=True) or {}
    username = str(data.get('username', '')).strip()
    if not re.fullmatch(r'[A-Za-z0-9_ -]{3,16}', username):
        return jsonify({'error': 'Le pseudo doit contenir 3 à 16 caractères (lettres, chiffres, espaces, _ ou -).'}), 400
    username_key = username.casefold()
    db = get_db()
    if not get_world_or_404(db, world_id):
        db.close(); return jsonify({'error': 'Monde introuvable.'}), 404
    existing = db.execute('SELECT id FROM multiplayer_accounts WHERE world_id=? AND username_key=?', (world_id, username_key)).fetchone()
    if existing:
        db.close(); return jsonify({'error': 'Ce pseudo est déjà utilisé dans ce monde. Choisis-en un autre.'}), 409
    token = secrets.token_urlsafe(32)
    now = utc_now()
    cur = db.execute('INSERT INTO multiplayer_accounts(world_id,username,username_key,token_hash,created_at,last_seen) VALUES(?,?,?,?,?,?)',
                      (world_id, username, username_key, hashlib.sha256(token.encode()).hexdigest(), now, now))
    account_id = cur.lastrowid
    db.commit(); db.close()
    return jsonify({'account_id': account_id, 'username': username, 'token': token}), 201

@app.route('/api/worlds/<int:world_id>/multiplayer/state', methods=['GET', 'PUT'])
def multiplayer_state(world_id):
    db = get_db()
    account = _account_from_request(db, world_id)
    if not account:
        db.close(); return jsonify({'error': 'Compte invalide ou session expirée.'}), 401
    if request.method == 'GET':
        try: snapshot = json.loads(account['state_json'] or '{}')
        except (ValueError, TypeError): snapshot = {}
        if not isinstance(snapshot, dict): snapshot = {}
        state = snapshot.get('current_state', snapshot)
        states = list((snapshot.get('dimension_states') or {}).values()) if isinstance(snapshot.get('dimension_states', {}), dict) else []
        db.close(); return jsonify({'state': state, 'states': states})
    data = request.get_json(silent=True) or {}
    if not isinstance(data, dict) or len(json.dumps(data, ensure_ascii=False).encode('utf-8')) > 256000:
        db.close(); return jsonify({'error': 'Sauvegarde invalide ou trop volumineuse.'}), 400
    # Full player snapshot: position, rotation, health, inventory, equipment, dimension, and future extensions.
    merged_state = _merge_account_snapshot(account['state_json'], data)
    db.execute('UPDATE multiplayer_accounts SET state_json=?, last_seen=? WHERE id=?',
               (merged_state, utc_now(), account['id']))
    db.commit(); db.close(); return jsonify({'ok': True})

@app.route('/api/worlds/<int:world_id>/multiplayer/heartbeat', methods=['POST'])
def multiplayer_heartbeat(world_id):
    data = request.get_json(silent=True) or {}
    db = get_db(); account = _account_from_request(db, world_id)
    if not account:
        db.close(); return jsonify({'error': 'Compte invalide ou session expirée.'}), 401
    state = data.get('state', {})
    if not isinstance(state, dict): state = {}
    merged_state = _merge_account_snapshot(account['state_json'], state)
    db.execute('UPDATE multiplayer_accounts SET state_json=?, last_seen=? WHERE id=?',
               (merged_state, utc_now(), account['id']))
    # Keep players active for 15 seconds; clients send a heartbeat every 2 seconds.
    rows = db.execute('SELECT id,username,skin,state_json,last_seen FROM multiplayer_accounts WHERE world_id=? AND id<>? AND last_seen>=?',
                      (world_id, account['id'], (datetime.now(timezone.utc)-__import__('datetime').timedelta(seconds=15)).isoformat(timespec='seconds'))).fetchall()
    players=[]
    for row in rows:
        try: snapshot=json.loads(row['state_json'] or '{}')
        except (ValueError,TypeError): snapshot={}
        players.append({'id':row['id'],'username':row['username'],'skin':row['skin'],'state':snapshot})
    db.commit(); db.close(); return jsonify({'players':players,'username':account['username']})

@app.route('/api/worlds/<int:world_id>/multiplayer/chat', methods=['GET','POST'])
def multiplayer_chat(world_id):
    db=get_db(); account=_account_from_request(db,world_id)
    if not account:
        db.close(); return jsonify({'error':'Compte invalide ou session expirée.'}),401
    if request.method=='POST':
        data=request.get_json(silent=True) or {}; message=str(data.get('message','')).strip()
        if not message or len(message)>240:
            db.close(); return jsonify({'error':'Message vide ou trop long (240 caractères maximum).'}),400
        db.execute('INSERT INTO multiplayer_chat(world_id,account_id,username,message,created_at) VALUES(?,?,?,?,?)',
                   (world_id,account['id'],account['username'],message,utc_now())); db.commit()
    after=max(0,int(request.args.get('after',0) or 0))
    rows=db.execute('SELECT id,username,message,created_at FROM multiplayer_chat WHERE world_id=? AND id>? ORDER BY id LIMIT 100',(world_id,after)).fetchall()
    db.close(); return jsonify({'messages':[dict(r) for r in rows]})


_LEGACY_TEXTURE_INDEX = None
def _texture_key(value):
    value = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore').decode('ascii').lower()
    return value

def _get_legacy_texture_index():
    global _LEGACY_TEXTURE_INDEX
    if _LEGACY_TEXTURE_INDEX is None:
        index = {}
        texture_root = os.path.join(app.static_folder, 'assets', 'textures')
        for current, _dirs, files in os.walk(texture_root):
            for name in files:
                index.setdefault(_texture_key(name), []).append(os.path.join(current, name))
        _LEGACY_TEXTURE_INDEX = index
    return _LEGACY_TEXTURE_INDEX

@app.route('/static/textures/<path:filename>')
def legacy_texture_path(filename):
    """Résout les anciens chemins vers la nouvelle arborescence d’assets."""
    root = os.path.join(app.static_folder, 'assets', 'textures')
    direct = os.path.realpath(os.path.join(root, filename))
    if direct.startswith(os.path.realpath(root) + os.sep) and os.path.isfile(direct):
        return send_file(direct, mimetype=__import__('mimetypes').guess_type(direct)[0], max_age=0)
    aliases = {
        'wooden_axe.png': 'items/tools/stone/stone_axe.png',
        'wooden_pick.png': 'items/tools/stone/stone_pick.png',
        'wooden_shovel.png': 'items/tools/stone/stone_shovel.png',
        'wooden_sword.png': 'items/tools/stone/stone_sword.png',
        'cooper_block.png': 'blocks/undergrounds/ore-blocks/raw_cooper_block.png',
        'hign_grass_up.png': 'blocks/naturals/grass/high_grass_up.png',
        'portal.png': 'blocks/undergrounds/others/obsidian.png',
        'portal_cadre.png': 'blocks/undergrounds/others/obsidian.png',
    }
    alias = aliases.get(os.path.basename(filename).lower())
    if alias:
        alias_path = os.path.realpath(os.path.join(root, alias))
        if alias_path.startswith(os.path.realpath(root) + os.sep) and os.path.isfile(alias_path):
            return send_file(alias_path, mimetype=__import__('mimetypes').guess_type(alias_path)[0], max_age=0)
    candidates = _get_legacy_texture_index().get(_texture_key(os.path.basename(filename)), [])
    if not candidates:
        abort(404)
    requested_parts = set(_texture_key(filename).replace('\\', '/').split('/'))
    def score(path):
        parts = set(_texture_key(os.path.relpath(path, root)).split(os.sep))
        return len(requested_parts & parts)
    chosen = max(candidates, key=score)
    return send_file(chosen, mimetype=__import__('mimetypes').guess_type(chosen)[0], max_age=0)

_LEGACY_SOUND_INDEX = None
@app.route('/static/sounds/<path:filename>')
def legacy_sound_path(filename):
    """Résout les anciens chemins sonores vers la nouvelle arborescence."""
    global _LEGACY_SOUND_INDEX
    sound_root = os.path.join(app.static_folder, 'assets', 'sounds')
    direct = os.path.realpath(os.path.join(sound_root, filename))
    if direct.startswith(os.path.realpath(sound_root) + os.sep) and os.path.isfile(direct):
        return send_file(direct, mimetype=__import__('mimetypes').guess_type(direct)[0], max_age=0)
    if _LEGACY_SOUND_INDEX is None:
        _LEGACY_SOUND_INDEX = {}
        for current, _dirs, files in os.walk(sound_root):
            for name in files: _LEGACY_SOUND_INDEX.setdefault(name.lower(), []).append(os.path.join(current, name))
    candidates = _LEGACY_SOUND_INDEX.get(os.path.basename(filename).lower(), [])
    if not candidates: abort(404)
    return send_file(candidates[0], mimetype=__import__('mimetypes').guess_type(candidates[0])[0], max_age=0)

@app.route('/api/block-ui/<path:ui_path>')
def get_block_ui(ui_path):
    if not isinstance(ui_path, str) or ui_path.startswith('/') or '\\' in ui_path or any(part in ('.', '..', '') for part in ui_path.split('/')):
        abort(400)
    if not ui_path.lower().endswith('.html'):
        abort(400)
    base = os.path.realpath(os.path.join(RESOURCE_DIR, 'templates', 'in-game-UI'))
    target = os.path.realpath(os.path.join(base, ui_path))
    if not target.startswith(base + os.sep) or not os.path.isfile(target):
        abort(404)
    return send_file(target, mimetype='text/html', max_age=0)

@app.route('/api/texture-packs')
@app.route('/api/asset-packs')
def list_texture_packs():
    """Expose les packs installés sans extraire leurs archives ZIP."""
    packs = [{"id": "default", "name": "Assets de La Plaine", "description": "Ressources originales du jeu", "version": "base", "built_in": True}]
    seen = {"default"}
    for root in TEXTURE_PACK_DIRS:
        if not os.path.isdir(root):
            continue
        for entry in sorted(os.listdir(root)):
            path = os.path.join(root, entry)
            if os.path.isfile(path) and not entry.lower().endswith('.zip'):
                continue
            pack_id = os.path.splitext(entry)[0] if entry.lower().endswith('.zip') else entry
            if not _safe_id(pack_id) or pack_id in seen:
                continue
            manifest = None
            if os.path.isfile(path) and entry.lower().endswith('.zip'):
                try:
                    with zipfile.ZipFile(path) as archive:
                        names = set(archive.namelist())
                        manifest_name = next((n for n in ('manifest.json', 'asset_pack/manifest.json', 'texture_pack/manifest.json') if n in names), None)
                        if manifest_name:
                            manifest_info = archive.getinfo(manifest_name)
                            if manifest_info.file_size > 1024 * 1024:
                                continue
                            manifest = json.loads(archive.read(manifest_name).decode('utf-8'))
                except (OSError, zipfile.BadZipFile, ValueError, KeyError):
                    continue
            elif os.path.isdir(path):
                manifest = _manifest_from_folder(path, pack_id)
            if not isinstance(manifest, dict):
                manifest = {"id": pack_id, "name": pack_id, "description": "Pack sans manifeste", "version": "?"}
            if not _safe_id(str(manifest.get('id', pack_id))):
                continue
            manifest.update({"id": pack_id, "built_in": False})
            packs.append({k: manifest.get(k) for k in ("id", "name", "description", "version", "built_in")})
            seen.add(pack_id)
    return jsonify({"packs": packs})


@app.route('/api/texture-packs/<pack_id>/manifest')
@app.route('/api/asset-packs/<pack_id>/manifest')
def get_texture_pack_manifest(pack_id):
    """Renvoie le manifeste d'un pack, utilisé pour résoudre les textures en atlas."""
    if not _safe_id(pack_id) or pack_id == 'default':
        abort(404)
    for root in TEXTURE_PACK_DIRS:
        zip_path = os.path.join(root, pack_id + '.zip')
        folder_path = os.path.join(root, pack_id)
        if os.path.isfile(zip_path):
            try:
                with zipfile.ZipFile(zip_path) as archive:
                    names = set(archive.namelist())
                    manifest_name = next((n for n in ('manifest.json', 'asset_pack/manifest.json', 'texture_pack/manifest.json') if n in names), None)
                    if manifest_name:
                        info = archive.getinfo(manifest_name)
                        if info.file_size > 1024 * 1024:
                            abort(413)
                        data = json.loads(archive.read(manifest_name).decode('utf-8'))
                        if isinstance(data, dict):
                            return jsonify(data)
            except (OSError, zipfile.BadZipFile, ValueError, KeyError):
                continue
        elif os.path.isdir(folder_path):
            data = _manifest_from_folder(folder_path, pack_id)
            if isinstance(data, dict):
                return jsonify(data)
    abort(404)

@app.route('/api/texture-packs/<pack_id>/textures/<path:asset_path>')
@app.route('/api/asset-packs/<pack_id>/assets/<path:asset_path>')
def get_texture_pack_asset(pack_id, asset_path):
    """Renvoie la texture du pack, puis retombe sur celle du jeu si absente."""
    if not _safe_id(pack_id) or asset_path.startswith('/') or '\\' in asset_path or any(part in ('.', '..') for part in asset_path.split('/')):
        abort(400)
    if pack_id != 'default':
        for root in TEXTURE_PACK_DIRS:
            zip_path = os.path.join(root, pack_id + '.zip')
            folder_path = os.path.join(root, pack_id)
            if os.path.isfile(zip_path):
                try:
                    with zipfile.ZipFile(zip_path) as archive:
                        candidates = (f"static/assets/{asset_path}", f"assets/{asset_path}", f"static/assets/textures/{asset_path}", f"assets/textures/{asset_path}", f"static/textures/{asset_path}", f"textures/{asset_path}", asset_path)
                        name = next((n for n in candidates if n in archive.namelist() and not n.startswith('/') and '..' not in n.split('/')), None)
                        if name:
                            info = archive.getinfo(name)
                            if info.file_size > 16 * 1024 * 1024:
                                abort(413)
                            data = archive.read(name)
                            mimetype = __import__('mimetypes').guess_type(asset_path)[0] or 'application/octet-stream'
                            return send_file(io.BytesIO(data), mimetype=mimetype, max_age=0)
                except zipfile.BadZipFile:
                    pass
            if os.path.isdir(folder_path):
                for relative in (os.path.join('static', 'assets', asset_path), os.path.join('assets', asset_path), os.path.join('static', 'assets', 'textures', asset_path), os.path.join('assets', 'textures', asset_path), os.path.join('static', 'textures', asset_path), os.path.join('textures', asset_path), asset_path):
                    candidate = os.path.realpath(os.path.join(folder_path, relative))
                    if candidate.startswith(os.path.realpath(folder_path) + os.sep) and os.path.isfile(candidate):
                        return send_file(candidate, max_age=0)
    asset_root = os.path.realpath(os.path.join(app.static_folder, 'assets'))
    candidates = [
        os.path.realpath(os.path.join(asset_root, asset_path)),
        os.path.realpath(os.path.join(asset_root, 'textures', asset_path)),
        os.path.realpath(os.path.join(asset_root, 'sounds', asset_path)),
    ]
    base = next((candidate for candidate in candidates if candidate.startswith(asset_root + os.sep) and os.path.isfile(candidate)), None)
    if not base: abort(404)
    return send_file(base, mimetype=__import__('mimetypes').guess_type(base)[0], max_age=0)

def _read_shader_pack(zip_path, pack_id, include_source=False):
    """Lit un pack shader ZIP avec des limites strictes et des chemins internes sûrs."""
    try:
        if os.path.getsize(zip_path) > 32 * 1024 * 1024:
            return None
        with zipfile.ZipFile(zip_path) as archive:
            files = {info.filename: info for info in archive.infolist() if not info.is_dir()}
            manifest_info = files.get('manifest.json')
            if not manifest_info or manifest_info.file_size > 128 * 1024:
                return None
            manifest = json.loads(archive.read('manifest.json').decode('utf-8'))
            if not isinstance(manifest, dict):
                return None
            frag_name = manifest.get('fragment_shader', manifest.get('fragmentShader', 'fragment.glsl'))
            vert_name = manifest.get('vertex_shader', manifest.get('vertexShader'))
            def safe_shader_file(name):
                return (isinstance(name, str) and name in files and not name.startswith('/')
                        and '\\' not in name and all(part not in ('.', '..', '') for part in name.split('/'))
                        and name.lower().endswith(('.glsl', '.frag', '.vert'))
                        and files[name].file_size <= 512 * 1024)
            if not safe_shader_file(frag_name):
                return None
            if vert_name is not None and not safe_shader_file(vert_name):
                return None
            item = {
                'id': pack_id,
                'name': str(manifest.get('name', pack_id))[:120],
                'description': str(manifest.get('description', 'Shader personnalisé'))[:500],
                'version': str(manifest.get('version', '1.0.0'))[:40],
                'type': 'screen'
            }
            if include_source:
                item['fragment_shader'] = archive.read(frag_name).decode('utf-8')
                item['vertex_shader'] = archive.read(vert_name).decode('utf-8') if vert_name else None
            return item
    except (OSError, zipfile.BadZipFile, ValueError, KeyError, UnicodeDecodeError, json.JSONDecodeError):
        return None


@app.route('/api/shaders')
def list_shader_packs():
    packs, seen = [], set()
    for folder in SHADER_DIRS:
        if not os.path.isdir(folder):
            continue
        for entry in sorted(os.listdir(folder)):
            if not entry.lower().endswith('.zip'):
                continue
            pack_id = os.path.splitext(entry)[0]
            if not _safe_id(pack_id) or pack_id in seen:
                continue
            item = _read_shader_pack(os.path.join(folder, entry), pack_id)
            if item:
                packs.append(item)
                seen.add(pack_id)
    return jsonify({'shaders': packs})


@app.route('/api/shaders/<shader_id>')
def get_shader_pack(shader_id):
    if not _safe_id(shader_id):
        abort(400)
    for folder in SHADER_DIRS:
        candidate = os.path.realpath(os.path.join(folder, shader_id + '.zip'))
        if candidate.startswith(os.path.realpath(folder) + os.sep) and os.path.isfile(candidate):
            item = _read_shader_pack(candidate, shader_id, include_source=True)
            if item:
                return jsonify(item)
    abort(404)


@app.route('/api/mods')
def list_mods():
    mods, seen = [], set()
    for root in MOD_DIRS:
        if not os.path.isdir(root):
            continue
        for folder in sorted(os.listdir(root)):
            if not _safe_id(folder) or folder in seen:
                continue
            mod_path = os.path.join(root, folder)
            if not os.path.isdir(mod_path):
                continue
            manifest = _manifest_from_folder(mod_path, folder)
            if not manifest:
                continue
            if not _safe_id(str(manifest.get('id', folder))):
                continue
            mods.append({
                "id": folder, "name": str(manifest.get("name", folder))[:120],
                "description": str(manifest.get("description", ""))[:500],
                "version": str(manifest.get("version", "1.0.0"))[:40],
                "entry": manifest.get("entry", "main.js"),
                "api_version": str(manifest.get("api_version", "1")),
                "author": str(manifest.get("author", "Inconnu"))[:120],
                "category": str(manifest.get("category", "Divers"))[:80],
                "compatibility": str(manifest.get("compatibility", "*"))[:40],
                "dependencies": [str(value) for value in manifest.get("dependencies", []) if isinstance(value, str)][:64] if isinstance(manifest.get("dependencies", []), list) else [],
                "menu_settings": manifest.get("menu_settings", False) is True,
            })
            seen.add(folder)
    return jsonify({"mods": mods})

@app.route('/api/mods/<mod_id>/<path:asset_path>')
def get_mod_asset(mod_id, asset_path):
    if not _safe_id(mod_id) or asset_path.startswith('/') or '\\' in asset_path or any(part in ('.', '..') for part in asset_path.split('/')):
        abort(400)
    for root in MOD_DIRS:
        folder = os.path.realpath(os.path.join(root, mod_id))
        candidate = os.path.realpath(os.path.join(folder, asset_path))
        if candidate.startswith(folder + os.sep) and os.path.isfile(candidate):
            return send_file(candidate, max_age=0)
    abort(404)



@app.route('/api/worlds/<int:world_id>/block-data', methods=['GET', 'POST', 'DELETE'])
def world_block_data(world_id):
    db = get_db()
    if not get_world_or_404(db, world_id):
        db.close(); return jsonify({'error': 'Monde introuvable.'}), 404
    dimension = str(request.values.get('dimension', 'overworld'))[:80]
    try:
        x, y, z = (int(request.values.get(key)) for key in ('x', 'y', 'z'))
    except (TypeError, ValueError):
        db.close(); return jsonify({'error': 'Coordonnées x, y et z obligatoires.'}), 400
    if any(abs(value) > 2_000_000 for value in (x, y, z)):
        db.close(); return jsonify({'error': 'Coordonnées hors limites.'}), 400
    if request.method == 'GET':
        row = db.execute('SELECT data_json FROM block_data WHERE world_id=? AND dimension=? AND x=? AND y=? AND z=?', (world_id, dimension, x, y, z)).fetchone()
        db.close()
        return jsonify({'data': json.loads(row['data_json']) if row else {}})
    if request.method == 'DELETE':
        db.execute('DELETE FROM block_data WHERE world_id=? AND dimension=? AND x=? AND y=? AND z=?', (world_id, dimension, x, y, z))
        db.commit(); db.close(); return jsonify({'ok': True})
    payload = request.get_json(silent=True) or {}
    data = payload.get('data')
    if not isinstance(data, dict):
        db.close(); return jsonify({'error': 'data doit être un objet JSON.'}), 400
    try:
        encoded = json.dumps(data, ensure_ascii=False, separators=(',', ':'))
    except (TypeError, ValueError):
        db.close(); return jsonify({'error': 'Données JSON invalides.'}), 400
    if len(encoded.encode('utf-8')) > 65536:
        db.close(); return jsonify({'error': 'Données trop volumineuses (64 Ko maximum).'}), 413
    db.execute('''INSERT INTO block_data(world_id,dimension,x,y,z,data_json,updated_at) VALUES(?,?,?,?,?,?,?)
        ON CONFLICT(world_id,dimension,x,y,z) DO UPDATE SET data_json=excluded.data_json, updated_at=excluded.updated_at''',
        (world_id, dimension, x, y, z, encoded, utc_now()))
    db.commit(); db.close(); return jsonify({'ok': True})

@app.route('/api/modules')
def get_modules():
    js_root = os.path.join(app.static_folder, 'js')
    def js_files(relative, exclude=()):
        folder = os.path.join(js_root, relative)
        if not os.path.isdir(folder): return []
        return sorted(name for name in os.listdir(folder)
                      if name.lower().endswith('.js') and name.lower() not in exclude)
    dims_dir = os.path.join(js_root, 'game', 'dimensions')
    dimensions = []
    if os.path.isdir(dims_dir):
        for dim_name in sorted(os.listdir(dims_dir)):
            dim_path = os.path.join(dims_dir, dim_name)
            if not os.path.isdir(dim_path): continue
            biomes_dir = os.path.join(dim_path, 'biomes')
            biome_files = sorted(f for f in os.listdir(biomes_dir) if f.lower().endswith('.js') and f.lower() != 'register.js') if os.path.isdir(biomes_dir) else []
            structures_dir = os.path.join(biomes_dir, 'structures')
            structure_files = sorted(f for f in os.listdir(structures_dir) if f.lower().endswith('.js')) if os.path.isdir(structures_dir) else []
            dimensions.append({'id': dim_name, 'biomes': biome_files, 'structures': structure_files})
    recipes_dir = os.path.join(js_root, 'game', 'crafts', 'recipes')
    recipes = sorted(f for f in os.listdir(recipes_dir) if f.lower().endswith('.json')) if os.path.isdir(recipes_dir) else []
    return jsonify({
        'blocks': js_files('game/blocks', ('register.js',)),
        'blockBehaviors': js_files('world/blocks', ('register.js',)),
        'itemBehaviors': js_files('world/items', ('register.js',)),
        'mobs': js_files('game/mobs', ('register.js',)),
        'dimensions': dimensions,
        'recipes': recipes,
    })


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('LA_PLAINE_PORT', '5000')), debug=False, use_reloader=False)
