/* Contact damage configured through damage-per-sec. */
window.blockBehaviorRegistry?.register('damage', { description: "Dégâts de contact configurés par damage-per-sec.", onContact(context) { const rate = Number(context.block?.damagePerSec) || 0; if (rate > 0 && context.player?.takeDamage) context.player.damage(rate * (Number(context.delta) || 0)); } });
