/* La Plaine 0.2.8.0 — block registry and extension API. */
(function () {
    'use strict';
    const warnings = window.LaPlaineWarnings = window.LaPlaineWarnings || [];
    const warn = (message, detail) => { warnings.push({scope:'blocks', message, detail:detail || null}); console.warn('[La Plaine][Bloc]', message, detail || ''); };
    const pick = (data, camel, kebab, fallback) => data[camel] !== undefined ? data[camel] : (data[kebab] !== undefined ? data[kebab] : fallback);

    class BlockBehaviorRegistry {
        constructor() { this.behaviors = new Map(); this.customFiles = new Set(); }
        register(name, behavior) {
            if (typeof name !== 'string' || !/^[a-z0-9_-]{1,64}$/i.test(name) || !behavior || typeof behavior !== 'object') { warn('Déclaration de comportement invalide.', name); return false; }
            if (this.behaviors.has(name)) { warn(`Comportement déjà enregistré : ${name}`); return false; }
            this.behaviors.set(name, Object.freeze({...behavior, id:name})); return true;
        }
        get(name) { return this.behaviors.get(name) || null; }
        getAll() { return [...this.behaviors.values()]; }
        async dispatch(blockId, eventName, context = {}) {
            const block = window.blockRegistry?.get(blockId); if (!block) return [];
            const results = [];
            for (const name of block.behaviors || []) {
                const behavior = this.get(name); if (!behavior) { warn(`Comportement inconnu « ${name} » pour le bloc ${blockId}.`); continue; }
                const handler = behavior[eventName];
                if (typeof handler === 'function') { try { results.push(await handler({...context, block, behavior:name})); } catch (error) { warn(`Erreur dans ${name}.${eventName} : ${error.message}`); } }
            }
            return results;
        }
    }

    class BlockRegistry {
        constructor() { this.blocks = new Map(); }
        register(data) {
            if (!data || !Number.isSafeInteger(Number(data.id)) || Number(data.id) < 0 || typeof data.name !== 'string' || !data.name.trim()) { warn('Bloc ignoré : identifiant ou nom invalide.', data); return false; }
            const id = Number(data.id);
            if (this.blocks.has(id)) { warn(`Identifiant de bloc déjà utilisé : ${id}. Le premier bloc est conservé.`, data); return false; }
            const textures = data.textures && typeof data.textures === 'object' ? {...data.textures} : {};
            const behaviorList = Array.isArray(data.behaviors) ? data.behaviors : (data.behaviors ? [data.behaviors] : []);
            const breakTimeValue = pick(data, 'breakTime', 'break-time', 0);
            const rawDropRate = pick(data, 'dropRate', 'drop-rate', 100);
            const dropRate = typeof rawDropRate === 'string' ? Number.parseFloat(rawDropRate.replace('%','')) : Number(rawDropRate);
            const biomeTransforms = Array.isArray(data.biomeTransforms) ? [...data.biomeTransforms] : [];
            const dropRates = {...(pick(data,'dropRates','drop-rates',{}) || {})};
            for (const [key, value] of Object.entries(data)) {
                const biomeMatch = key.match(/^biome-transform(\d+)$/);
                if (biomeMatch) { const index = biomeMatch[1]; const target = data[`biome-transform${index}-trans`]; biomeTransforms.push({biome:value, transform:Number(target)}); }
                const dropMatch = key.match(/^drop-rate-(\d+)$/);
                if (dropMatch) dropRates[dropMatch[1]] = Number.parseFloat(String(value).replace('%',''));
            }
            const formatted = {
                ...data, id, name:data.name.trim(), textures,
                transparent:Boolean(data.transparent), alphaTest:Number(data.alphaTest)||0,
                isPlant:Boolean(data.isPlant), isFluid:Boolean(data.isFluid), viscosity:Number(data.viscosity)||1,
                lightLevel:Number(data.lightLevel)||0, emitColor:data.emitColor||0xffffff,
                luminous:Boolean(data.luminous || Number(data.lightLevel)>0), lightColor:data.lightColor||data.emitColor||0xffffff,
                lightRadius:Math.max(0,Number(data.lightRadius)||(Number(data.lightLevel)>0?Number(data.lightLevel)*1.5:0)),
                lightFlicker:Boolean(data.lightFlicker), lightFlickerSpeed:Math.max(0,Number(data.lightFlickerSpeed)||1),
                lightIntensity:Math.max(0,Number(data.lightIntensity)||(Number(data.lightLevel)>0?Number(data.lightLevel)/15:0)),
                replaceable:Boolean(data.replaceable), hardness:Math.max(0,Number(data.hardness)||Number(breakTimeValue)||0),
                blastResistance:Math.max(0,Number(data.blastResistance)||0), sound:data.sound||null,
                tool:data.tool||data.type||null, tags:Array.isArray(data.tags)?[...data.tags]:[],
                drop:data.drop===undefined?(data.isFluid?null:id):data.drop,
                type:data.type||null, level:Math.max(1,Number(data.level)||1), breakTime:breakTimeValue === 'none' ? 0 : Math.max(0,Number(breakTimeValue)||0),
                damagePerSec:Number(pick(data,'damagePerSec','damage-per-sec',0))||0,
                growSpeed:Number(pick(data,'growSpeed','grow-speed',0))||0,
                infectDirtSpeed:Number(pick(data,'infectDirtSpeed','infect-dirt-speed',0))||0,
                biomeTransform:Boolean(pick(data,'biomeTransform','biome-transform',false)),
                biomeTransforms,
                bucket:Boolean(data.bucket), bucketTrans:pick(data,'bucketTrans','bucket-trans',null),
                ambientSound:pick(data,'ambientSound','ambient-sound',null),
                miningSpeed:Number(pick(data,'miningSpeed','mining-speed',1))||1,
                miningToolType:pick(data,'miningToolType','mining-tool-type',null),
                miningToolLevel:Number(pick(data,'miningToolLevel','mining-tool-level',data.level||1))||1,
                dropRate:Number(dropRate), dropNumber:Math.max(0,Number(pick(data,'dropNumber','drop-number',1))||0),
                dropRates, xpDrop:Number(pick(data,'xpDrop','XP-drop',0))||0,
                ui:pick(data,'UI','ui',null), customFile:pick(data,'customFile','custom-file',null),
                behaviors:behaviorList.map(String), itemTexture:data.itemTexture||data.item_texture||null
            };
            if (!Number.isFinite(formatted.dropRate) || formatted.dropRate < 0 || formatted.dropRate > 100) warn(`drop-rate invalide sur le bloc ${id}; 100 % sera utilisé.`);
            if (formatted.dropRate < 0 || formatted.dropRate > 100 || !Number.isFinite(formatted.dropRate)) formatted.dropRate = 100;
            if (formatted.customFile && typeof formatted.customFile !== 'string') { warn(`custom-file invalide sur le bloc ${id}.`); formatted.customFile = null; }
            this.blocks.set(id, formatted);
            return true;
        }
        get(id) { return this.blocks.get(Number(id)) || null; }
        getAll() { return [...this.blocks.values()]; }
        async loadCustomFiles(loader) {
            for (const block of this.blocks.values()) {
                if (!block.customFile) continue;
                const path = normalizeCustomPath(block.customFile);
                if (!path) { warn(`Chemin custom-file refusé pour le bloc ${block.id}.`, block.customFile); continue; }
                if (this._loadedCustom?.has(path)) continue;
                this._loadedCustom = this._loadedCustom || new Set();
                try { await loader(path); this._loadedCustom.add(path); }
                catch (error) { warn(`Fichier personnalisé du bloc ${block.id} indisponible : ${error.message}`); }
            }
        }
    }
    function normalizeCustomPath(value) {
        if (typeof value !== 'string' || !value.trim()) return null;
        let path=value.trim().replace(/\\/g,'/'); if (!path.startsWith('/')) path='/'+path;
        if (!path.startsWith('/static/js/') || path.slice(1).split('/').some(part=>part==='..'||part==='.'||part==='')) return null;
        return path;
    }
    window.blockBehaviorRegistry = window.blockBehaviorRegistry || new BlockBehaviorRegistry();
    window.BlockBehaviorRegistry = BlockBehaviorRegistry;
    window.blockRegistry = window.blockRegistry || new BlockRegistry();
    window.LaPlaineBlockAPI = Object.freeze({registry:window.blockRegistry, behaviors:window.blockBehaviorRegistry, warn});
})();
