/* Base game item declarations — La Plaine 0.2.8.0.
   Les blocs sont automatiquement copiés dans le registre d'items avant les items autonomes. */
(function () {
    const registry = window.itemsRegistry;
    if (!registry) {
        console.error('[La Plaine] Le registre des items est introuvable.');
        return;
    }

    // Each block has its own item, with a separate inventory texture when itemTexture is defined.
    registry.registerBlocks();

    // Tools
    registry.register({ id: 1001, name: 'Pioche en bois', type: 'pickaxe', level: 1, textures: { all: '/static/textures/bois/tools/wooden_pick.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1002, name: 'Pioche en pierre', type: 'pickaxe', level: 2, textures: { all: '/static/textures/pierres/tools/stone_pick.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1003, name: 'Pioche en fer', type: 'pickaxe', level: 3, textures: { all: '/static/textures/iron/iron_pick.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1004, name: 'Pioche en diamant', type: 'pickaxe', level: 4, textures: { all: '/static/textures/tools/diamond_pick.png' }, place: null, 'stack-number': 1 });

    registry.register({ id: 1011, name: 'Hache en bois', type: 'axe', level: 1, textures: { all: '/static/textures/bois/tools/wooden_axe.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1012, name: 'Hache en pierre', type: 'axe', level: 2, textures: { all: '/static/textures/pierres/tools/stone_axe.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1013, name: 'Hache en fer', type: 'axe', level: 3, textures: { all: '/static/textures/iron/iron_axe.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1014, name: 'Hache en diamant', type: 'axe', level: 4, textures: { all: '/static/textures/tools/diamond_axe.png' }, place: null, 'stack-number': 1 });

    registry.register({ id: 1021, name: 'Pelle en bois', type: 'shovel', level: 1, textures: { all: '/static/textures/bois/tools/wooden_shovel.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1022, name: 'Pelle en pierre', type: 'shovel', level: 2, textures: { all: '/static/textures/pierres/tools/stone_shovel.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1023, name: 'Pelle en fer', type: 'shovel', level: 3, textures: { all: '/static/textures/iron/iron_shovel.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1024, name: 'Pelle en diamant', type: 'shovel', level: 4, textures: { all: '/static/textures/tools/diamond_shovel.png' }, place: null, 'stack-number': 1 });

    registry.register({ id: 1031, name: 'Épée en bois', type: 'sword', level: 1, textures: { all: '/static/textures/bois/tools/wooden_sword.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1032, name: 'Épée en pierre', type: 'sword', level: 2, textures: { all: '/static/textures/pierres/tools/stone_sword.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1033, name: 'Épée en fer', type: 'sword', level: 3, textures: { all: '/static/textures/iron/iron_sword.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1034, name: 'Épée en diamant', type: 'sword', level: 4, textures: { all: '/static/textures/tools/diamond_sword.png' }, place: null, 'stack-number': 1 });

    // Materials and resources
    registry.register({ id: 1101, name: 'Bâton', type: 'material', textures: { all: '/static/textures/materials/stick.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1102, name: 'Charbon', type: 'material', textures: { all: '/static/textures/materials/coal.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1103, name: 'Minerai de fer', type: 'material', textures: { all: '/static/textures/ores/iron_ore.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1104, name: 'Lingot de fer', type: 'material', textures: { all: '/static/textures/iron/iron_ingot.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1105, name: 'Mouton cuit', type: 'food', textures: { all: '/static/textures/food/cooked_sheep.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1106, name: 'Laine', type: 'material', textures: { all: '/static/textures/others/laine.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1107, name: 'Mouton cru', type: 'food', textures: { all: '/static/textures/food/raw_sheep.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1108, name: 'Plume', type: 'material', textures: { all: '/static/textures/materials/feather.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1109, name: 'Œuf', type: 'material', textures: { all: '/static/textures/others/egg.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1111, name: 'Cuir', type: 'material', textures: { all: '/static/textures/materials/leather.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1112, name: 'Charbon de bois', type: 'material', textures: { all: '/static/textures/others/wood_coal.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1113, name: 'Pierre brute', type: 'material', textures: { all: '/static/textures/pierres/stone/stone.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1114, name: 'Minerai de cuivre', type: 'material', textures: { all: '/static/textures/ores/cooper_ore.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1115, name: 'Diamant', type: 'material', textures: { all: '/static/textures/ores/diamond_ore.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1116, name: 'Lingot de cuivre', type: 'material', textures: { all: '/static/textures/ores/cooper_block.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1117, name: 'Charbon', type: 'material', textures: { all: '/static/textures/materials/coal.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1118, name: 'Poulet cru', type: 'food', textures: { all: '/static/textures/food/raw_chicken.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1119, name: 'Poulet cuit', type: 'food', textures: { all: '/static/textures/food/cooked_chicken.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1120, name: 'Porc cru', type: 'food', textures: { all: '/static/textures/food/raw_pig.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1121, name: 'Porc cuit', type: 'food', textures: { all: '/static/textures/food/cooked_pig.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1122, name: 'Bœuf cru', type: 'food', textures: { all: '/static/textures/food/raw_cow.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1123, name: 'Bœuf cuit', type: 'food', textures: { all: '/static/textures/food/cooked_cow.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1124, name: 'Fil', type: 'material', textures: { all: '/static/textures/materials/string.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1125, name: 'Os', type: 'material', textures: { all: '/static/textures/materials/bone.png' }, place: null, 'stack-number': 100 });
})();
