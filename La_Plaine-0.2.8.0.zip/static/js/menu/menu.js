const btnPlay = document.getElementById('btn-play');
const btnSettings = document.getElementById('btn-settings');
const skinsModal = document.getElementById('skins-modal');
const btnSkins = document.getElementById('btn-skins');
const btnControls = document.getElementById('btn-controls');
const btnTexturePacks = document.getElementById('btn-texture-packs');
const btnMods = document.getElementById('btn-mods');
const texturePacksModal = document.getElementById('texture-packs-modal');
const modsModal = document.getElementById('mods-modal');
const texturePackList = document.getElementById('texture-pack-list');
const modList = document.getElementById('mod-list');

const worldsModal = document.getElementById('worlds-modal');
const createWorldModal = document.getElementById('create-world-modal');
const settingsModal = document.getElementById('settings-modal');
const controlsModal = document.getElementById('controls-modal');

const worldList = document.getElementById('world-list');
const worldName = document.getElementById('world-name');
const worldSeed = document.getElementById('world-seed');
const createWorldError = document.getElementById('create-world-error');

// Organize existing settings into categories without recreating
// controls: their IDs and event handlers remain unchanged.
function buildSettingsCategories() {
    const modal = settingsModal;
    const get = id => document.getElementById(id);
    const settingRow = id => get(id)?.closest('.setting-item');
    const rows = {
        render: settingRow('render-distance'), fps: settingRow('fps-limit-select'),
        quality: settingRow('graphics-quality-select'), resolution: settingRow('resolution-select'), resolutionScale: settingRow('resolution-scale-select'),
        clouds: settingRow('cloud-toggle-menu'),
        vignette: settingRow('vignette-toggle-menu'), shaders: settingRow('shaders-toggle-menu'),
        master: settingRow('vol-master'), music: settingRow('vol-music'), sfx: settingRow('vol-sfx')
    };
    const modSettings = get('lp-mod-settings-container');
    const modSettingsDescription = modSettings?.previousElementSibling;
    const textureList = get('texture-pack-list');
    const textureHelp = textureList?.previousElementSibling;
    const refreshPacks = get('btn-refresh-texture-packs');
    const modsList = get('mod-list');
    const modsHelp = modsList?.previousElementSibling;
    const refreshMods = get('btn-refresh-mods');

    const home = document.createElement('div'); home.id = 'settings-home';
    const title = document.createElement('h3'); title.textContent = 'Paramètres';
    const hint = document.createElement('p'); hint.className = 'settings-hint'; hint.textContent = 'Choisis une catégorie';
    const nav = document.createElement('div'); nav.className = 'settings-category-nav';
    const detail = document.createElement('div'); detail.id = 'settings-category-view'; detail.hidden = true;
    const header = document.createElement('div'); header.className = 'settings-category-header';
    const back = document.createElement('button'); back.id = 'btn-settings-back'; back.className = 'btn-menu small'; back.textContent = '← RETOUR';
    const detailTitle = document.createElement('h3'); detailTitle.id = 'settings-category-title';
    header.append(back, detailTitle);
    const content = document.createElement('div'); content.id = 'settings-category-content';
    detail.append(header, content);
    const panes = {};
    const categoryNames = { video: 'Vidéo & performances', graphics: 'Graphismes', effects: 'Effets visuels', particles: 'Animations & particules', interface: 'Interface', audio: 'Audio', mods: 'Mods', shaders: 'Shaders' };
    for (const [id, label] of Object.entries(categoryNames)) {
        const button = document.createElement('button'); button.type = 'button'; button.className = 'btn-menu settings-category-button'; button.textContent = label;
        button.addEventListener('click', () => {
            home.hidden = true; detail.hidden = false; detailTitle.textContent = label;
            Object.values(panes).forEach(pane => pane.hidden = true);
            panes[id].hidden = false;
            if (id === 'graphics') loadTexturePacks();
            if (id === 'mods') loadMods();
            if (id === 'shaders') loadShaders();
        });
        nav.appendChild(button);
        const pane = document.createElement('section'); pane.className = 'settings-pane'; pane.hidden = true; pane.dataset.category = id;
        panes[id] = pane; content.appendChild(pane);
    }
    back.addEventListener('click', () => { detail.hidden = true; home.hidden = false; });
    home.append(title, hint, nav);
    modal.replaceChildren(home, detail);

    const appendAll = (pane, items) => items.filter(Boolean).forEach(item => pane.appendChild(item));
    const sectionTitle = text => { const h = document.createElement('h4'); h.className = 'settings-subtitle'; h.textContent = text; return h; };
    const languageRow = document.createElement('div'); languageRow.className = 'setting-item';
    const languageLabel = document.createElement('label'); languageLabel.textContent = 'Langue du jeu';
    const languageSelect = document.createElement('select');
    [['fr','Français'],['en','English'],['de','Deutsch']].forEach(([value,label]) => {
        const option = document.createElement('option'); option.value = value; option.textContent = label; languageSelect.appendChild(option);
    });
    languageSelect.value = localStorage.getItem('laPlaine.language') || 'fr';
    languageSelect.addEventListener('change', () => {
        localStorage.setItem('laPlaine.language', languageSelect.value);
        window.LaPlaineI18n?.apply(languageSelect.value);
    });
    languageRow.append(languageLabel, languageSelect);
    appendAll(panes.interface, [sectionTitle('Language / Sprache / Langue'), languageRow]);

    const keyNames = {
        forward: 'Avancer / Move forward / Vorwärts', backward: 'Reculer / Move backward / Rückwärts',
        left: 'Gauche / Move left / Links', right: 'Droite / Move right / Rechts',
        jump: 'Sauter / Jump / Springen', sprint: 'Courir / Sprint / Rennen',
        inventory: 'Inventaire / Inventory / Inventar', camera: 'Changer la caméra / Toggle camera / Kamera wechseln',
        slot1: 'Barre 1 / Hotbar slot 1 / Schnellleiste 1', slot2: 'Barre 2 / Hotbar slot 2 / Schnellleiste 2',
        slot3: 'Barre 3 / Hotbar slot 3 / Schnellleiste 3', slot4: 'Barre 4 / Hotbar slot 4 / Schnellleiste 4',
        slot5: 'Barre 5 / Hotbar slot 5 / Schnellleiste 5', slot6: 'Barre 6 / Hotbar slot 6 / Schnellleiste 6',
        slot7: 'Barre 7 / Hotbar slot 7 / Schnellleiste 7', slot8: 'Barre 8 / Hotbar slot 8 / Schnellleiste 8',
        slot9: 'Barre 9 / Hotbar slot 9 / Schnellleiste 9'
    };
    const defaultKeys = { forward:'KeyW',backward:'KeyS',left:'KeyA',right:'KeyD',jump:'Space',sprint:'ShiftLeft',inventory:'KeyE',camera:'F5',
        slot1:'Digit1',slot2:'Digit2',slot3:'Digit3',slot4:'Digit4',slot5:'Digit5',slot6:'Digit6',slot7:'Digit7',slot8:'Digit8',slot9:'Digit9' };
    const readKeys = () => { try { return {...defaultKeys,...JSON.parse(localStorage.getItem('laPlaine.keybindings')||'{}')}; } catch (_) { return {...defaultKeys}; } };
    const keyLabel = code => ({Space:'Espace',ShiftLeft:'Maj gauche',ShiftRight:'Maj droite',ControlLeft:'Ctrl gauche',AltLeft:'Alt gauche'}[code] || code.replace('Key','').replace('Digit',''));
    const keyPaneTitle = sectionTitle('Commandes personnalisables');
    const keyHelp = document.createElement('p'); keyHelp.className='setting-description';
    keyHelp.textContent='Clique sur une touche, puis appuie sur la nouvelle touche. Les changements sont enregistrés automatiquement.';
    const keyRows = document.createElement('div'); keyRows.className='keybinding-list';
    Object.entries(keyNames).forEach(([action,label]) => {
        const row=document.createElement('div'); row.className='keybinding-row';
        const name=document.createElement('span'); name.textContent=label;
        const button=document.createElement('button'); button.type='button'; button.className='world-button';
        button.textContent=keyLabel(readKeys()[action]); button.setAttribute('aria-label',label);
        button.addEventListener('click', () => {
            button.textContent='Appuie sur une touche…'; button.classList.add('waiting');
            const capture = event => {
                event.preventDefault(); event.stopPropagation();
                if (['Escape','Tab'].includes(event.code)) { button.textContent=keyLabel(readKeys()[action]); button.classList.remove('waiting'); document.removeEventListener('keydown',capture,true); return; }
                const keys=readKeys();
                const conflict=Object.entries(keys).find(([other,code])=>other!==action&&code===event.code);
                if (conflict) { button.textContent='Déjà utilisée'; return; }
                keys[action]=event.code; localStorage.setItem('laPlaine.keybindings',JSON.stringify(keys));
                button.textContent=keyLabel(event.code); button.classList.remove('waiting');
                document.removeEventListener('keydown',capture,true);
            };
            document.addEventListener('keydown',capture,true);
        });
        row.append(name,button); keyRows.appendChild(row);
    });
    const resetKeys=document.createElement('button'); resetKeys.type='button'; resetKeys.className='btn-menu small'; resetKeys.textContent='RÉINITIALISER LES TOUCHES';
    resetKeys.addEventListener('click',()=>{localStorage.removeItem('laPlaine.keybindings'); keyRows.querySelectorAll('button').forEach((b,i)=>b.textContent=keyLabel(defaultKeys[Object.keys(keyNames)[i]]));});
    appendAll(panes.interface,[keyPaneTitle,keyHelp,keyRows,resetKeys]);

    appendAll(panes.video, [sectionTitle('Performances'), rows.render, rows.fps, rows.quality, rows.resolution, rows.resolutionScale]);
    appendAll(panes.audio, [sectionTitle('Volume'), rows.master, rows.music, rows.sfx]);
    appendAll(panes.effects, [rows.clouds, rows.vignette, rows.shaders]);
    const interfaceRow = document.createElement('div'); interfaceRow.className = 'setting-item';
    const interfaceLabel = document.createElement('label'); const compactToggle = document.createElement('input'); compactToggle.type = 'checkbox'; compactToggle.checked = localStorage.getItem('laPlaine.compactHud') === 'true'; compactToggle.addEventListener('change', () => localStorage.setItem('laPlaine.compactHud', String(compactToggle.checked))); interfaceLabel.append(compactToggle, document.createTextNode(' Interface compacte (préférence enregistrée)')); interfaceRow.append(interfaceLabel);
    const tipsRow = document.createElement('div'); tipsRow.className = 'setting-item'; const tipsLabel = document.createElement('label'); const tipsToggle = document.createElement('input'); tipsToggle.type = 'checkbox'; tipsToggle.checked = localStorage.getItem('laPlaine.showHints') !== 'false'; tipsToggle.addEventListener('change', () => localStorage.setItem('laPlaine.showHints', String(tipsToggle.checked))); tipsLabel.append(tipsToggle, document.createTextNode(' Afficher les aides et indications')); tipsRow.append(tipsLabel); appendAll(panes.interface, [interfaceRow, tipsRow]);
    const budgetRow = document.createElement('div'); budgetRow.className = 'setting-item';
    const budgetLabel = document.createElement('label'); budgetLabel.textContent = 'Budget de génération des chunks : ';
    const budgetValue = document.createElement('strong'); const budgetInput = document.createElement('input'); budgetInput.type = 'range'; budgetInput.min = '0.5'; budgetInput.max = '6'; budgetInput.step = '0.5'; budgetInput.value = String(Math.max(0.5, Math.min(6, Number(localStorage.getItem('laPlaine.chunkBudget')) || 2.5)));
    const updateBudget = () => { budgetValue.textContent = budgetInput.value + ' ms/frame'; localStorage.setItem('laPlaine.chunkBudget', budgetInput.value); }; budgetInput.addEventListener('input', updateBudget); updateBudget(); budgetLabel.appendChild(budgetValue); budgetRow.append(budgetLabel, budgetInput);
    const budgetHelp = document.createElement('p'); budgetHelp.className = 'setting-description'; budgetHelp.textContent = 'Une valeur basse privilégie la fluidité pendant la génération ; une valeur haute accélère le chargement au prix de possibles saccades.';
    appendAll(panes.video, [sectionTitle('Génération du monde'), budgetRow, budgetHelp]);
    const particlesTitle = sectionTitle('Effets de jeu');
    const particlesRow = document.createElement('div'); particlesRow.className = 'setting-item';
    const particlesLabel = document.createElement('label');
    const particlesToggle = document.createElement('input'); particlesToggle.type = 'checkbox'; particlesToggle.id = 'particles-toggle-menu';
    try { particlesToggle.checked = localStorage.getItem('laPlaine.particlesEnabled') !== 'false'; } catch (_) { particlesToggle.checked = true; }
    particlesLabel.append(particlesToggle, document.createTextNode(' Activer les particules (blocs, coups et interactions)')); particlesRow.appendChild(particlesLabel);
    const particlesHelp = document.createElement('p'); particlesHelp.className = 'setting-description'; particlesHelp.textContent = 'Désactive cette option pour réduire les effets visuels et privilégier les performances.';
    particlesToggle.addEventListener('change', () => { try { localStorage.setItem('laPlaine.particlesEnabled', String(particlesToggle.checked)); } catch (_) {} });
    appendAll(panes.particles, [particlesTitle, particlesRow, particlesHelp]);
    appendAll(panes.graphics, [textureHelp, textureList, refreshPacks]);
    appendAll(panes.mods, [modsHelp, modsList, refreshMods, sectionTitle('Paramètres des mods'), modSettingsDescription, modSettings]);
    const shaderIntro = document.createElement('p'); shaderIntro.className = 'setting-description'; shaderIntro.textContent = 'Ajoute des fichiers ZIP dans static/shaders/, puis sélectionne un shader ici. Les changements de pack et de résolution seront appliqués au prochain lancement du monde.';
    const shaderScaleRow = document.createElement('div'); shaderScaleRow.className = 'setting-item';
    const shaderScaleLabel = document.createElement('label'); shaderScaleLabel.htmlFor = 'shader-render-scale'; shaderScaleLabel.textContent = 'Résolution des shaders : ';
    const shaderScaleValue = document.createElement('strong');
    const shaderScale = document.createElement('input'); shaderScale.type = 'range'; shaderScale.id = 'shader-render-scale'; shaderScale.min = '0.5'; shaderScale.max = '1'; shaderScale.step = '0.05';
    let savedShaderScale = 1;
    try { const stored = Number(localStorage.getItem('laPlaine.shaderRenderScale')); if (Number.isFinite(stored) && stored > 0) savedShaderScale = Math.min(1, Math.max(0.5, stored)); } catch (_) {}
    shaderScale.value = String(savedShaderScale); shaderScaleValue.textContent = Math.round(savedShaderScale * 100) + '%';
    shaderScale.addEventListener('input', () => { shaderScaleValue.textContent = Math.round(Number(shaderScale.value) * 100) + '%'; });
    shaderScale.addEventListener('change', () => { try { localStorage.setItem('laPlaine.shaderRenderScale', String(Number(shaderScale.value))); } catch (_) {} });
    shaderScaleLabel.append(shaderScaleValue); shaderScaleRow.append(shaderScaleLabel, shaderScale);
    const shaderScaleHelp = document.createElement('p'); shaderScaleHelp.className = 'setting-description'; shaderScaleHelp.textContent = '100 % = qualité maximale. Une valeur plus basse réduit le coût du post-traitement, au prix d’une image un peu moins nette.';
    const shaderList = document.createElement('div'); shaderList.id = 'shader-pack-list'; shaderList.className = 'resource-list shader-pack-list';
    const shaderRefresh = document.createElement('button'); shaderRefresh.id = 'btn-refresh-shaders'; shaderRefresh.className = 'btn-menu small'; shaderRefresh.textContent = 'ACTUALISER LES SHADERS';
    shaderRefresh.addEventListener('click', loadShaders);
    appendAll(panes.shaders, [shaderIntro, shaderScaleRow, shaderScaleHelp, shaderList, shaderRefresh]);
    window.dispatchEvent(new CustomEvent('laplaine:menu-ready', { detail: { categories: panes, worldCreation: get('create-world-modal') } }));
    const empty = get('lp-mod-settings-empty');
    if (empty && !modSettings?.contains(empty)) modSettings?.appendChild(empty);
    if (texturePacksModal) texturePacksModal.style.display = 'none';
    if (modsModal) modsModal.style.display = 'none';
    return { home, detail };
}

window.LaPlaineI18n = {
    language: localStorage.getItem('laPlaine.language') || 'fr',
    dictionaries: {
        en: {'Jouer':'Play','Créer un monde':'Create world','Rejoindre':'Join','Retour':'Back','Inventaire':'Inventory','Vie':'Health','Chargement...':'Loading...','Monde':'World','Nom du monde':'World name','Graine':'Seed','Créer':'Create','Annuler':'Cancel','Supprimer':'Delete','Aucun monde':'No worlds','Paramètres':'Settings','Choisis une catégorie':'Choose a category','Vidéo & performances':'Video & performance','Graphismes':'Graphics','Effets visuels':'Visual effects','Animations & particules':'Animations & particles','Interface':'Interface','Audio':'Audio','Mods':'Mods','Shaders':'Shaders','← RETOUR':'← BACK','Performances':'Performance','Génération du monde':'World generation','Volume':'Volume','Langue du jeu':'Game language','Commandes personnalisables':'Custom key bindings'},
        de: {'Jouer':'Spielen','Créer un monde':'Welt erstellen','Rejoindre':'Beitreten','Retour':'Zurück','Inventaire':'Inventar','Vie':'Leben','Chargement...':'Wird geladen...','Monde':'Welt','Nom du monde':'Weltname','Graine':'Seed','Créer':'Erstellen','Annuler':'Abbrechen','Supprimer':'Löschen','Aucun monde':'Keine Welten','Paramètres':'Einstellungen','Choisis une catégorie':'Kategorie auswählen','Vidéo & performances':'Video & Leistung','Graphismes':'Grafik','Effets visuels':'Visuelle Effekte','Animations & particules':'Animationen & Partikel','Interface':'Oberfläche','Audio':'Audio','Mods':'Mods','Shaders':'Shader','← RETOUR':'← ZURÜCK','Performances':'Leistung','Génération du monde':'Weltgenerierung','Volume':'Lautstärke','Langue du jeu':'Spielsprache','Commandes personnalisables':'Tastaturbelegung'}
    },
    apply(language) {
        this.language = language;
        const dict=this.dictionaries[language]||{};
        document.querySelectorAll('#settings-home h3,#settings-home p,.settings-category-button,#btn-settings-back,.settings-subtitle').forEach(el=>{
            const translated=dict[el.textContent]; if(translated) el.textContent=translated;
        });
        const translateTextNodes = () => {
            const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
            let node;
            while ((node=walker.nextNode())) {
                const raw=node.nodeValue;
                const trimmed=raw.trim();
                if (dict[trimmed]) node.nodeValue=raw.replace(trimmed,dict[trimmed]);
            }
        };
        translateTextNodes();
        if (!this.observer) {
            this.observer = new MutationObserver(() => translateTextNodes());
            this.observer.observe(document.body, { childList: true, subtree: true });
        }
        document.documentElement.lang=language;
    }
};

const settingsViews = buildSettingsCategories();
window.LaPlaineI18n.apply(window.LaPlaineI18n.language);

(async () => {
    const emptyState = document.getElementById('lp-mod-settings-empty');
    try {
        const result = await window.LaPlaineModLoader.loadEnabledMods({ settingsOnly: true });
        if (emptyState) {
            if (result.loaded.length) emptyState.remove();
            else emptyState.textContent = 'Aucun réglage de mod compatible avec le menu.';
        }
        for (const failure of result.errors) console.warn(`[La Plaine] Mod ${failure.id} : ${failure.error}`);
    } catch (error) {
        console.warn('[La Plaine] Impossible de charger les paramètres des mods.', error);
        if (emptyState) emptyState.textContent = 'Impossible de charger les paramètres des mods.';
    }
})();

const closeAllModals = () => {
    worldsModal.style.display = 'none';
    createWorldModal.style.display = 'none';
    settingsModal.style.display = 'none';
    controlsModal.style.display = 'none';
    texturePacksModal.style.display = 'none';
    modsModal.style.display = 'none';
    skinsModal.style.display = 'none';
};

async function loadWorlds() {
    worldList.innerHTML = '<div class="world-empty">Chargement des mondes...</div>';

    try {
        const response = await fetch('/api/worlds');
        if (!response.ok) throw new Error('Impossible de charger les mondes.');

        const data = await response.json();
        const worlds = Array.isArray(data) ? data : (data.worlds || []);

        if (!worlds.length) {
            worldList.innerHTML = '<div class="world-empty">Aucun monde créé.<br>Crée ton premier monde !</div>';
            return;
        }

        worldList.innerHTML = '';

        worlds.forEach(world => {
            const item = document.createElement('div');
            item.className = 'world-item';

            const info = document.createElement('div');
            info.className = 'world-info';

            const name = document.createElement('div');
            name.className = 'world-name';
            name.textContent = world.name;

            const details = document.createElement('div');
            details.className = 'world-details';
            details.textContent = 'Seed : ' + world.seed;

            info.appendChild(name);
            info.appendChild(details);

            const actions = document.createElement('div');
            actions.className = 'world-item-actions';

            const play = document.createElement('button');
            play.className = 'world-button play-world';
            play.textContent = 'JOUER';
            play.addEventListener('click', () => {
                window.location.href = `/game?world=${encodeURIComponent(world.id)}`;
            });

            const remove = document.createElement('button');
            remove.className = 'world-button delete-world';
            remove.textContent = 'X';
            remove.title = 'Supprimer ce monde';
            remove.addEventListener('click', async () => {
                if (!confirm('Supprimer définitivement le monde "' + world.name + '" ?')) return;

                try {
                    const response = await fetch('/api/worlds/' + world.id, {
                        method: 'DELETE'
                    });

                    if (!response.ok) {
                        throw new Error('Impossible de supprimer le monde.');
                    }

                    loadWorlds();
                } catch (error) {
                    alert(error.message);
                }
            });

            actions.appendChild(play);
            actions.appendChild(remove);

            item.appendChild(info);
            item.appendChild(actions);
            worldList.appendChild(item);
        });
    } catch (error) {
        worldList.innerHTML = '<div class="world-empty error">Erreur : ' + error.message + '</div>';
    }
}

const skinGrid = document.getElementById('skin-grid');
const skinNames = Array.from({length:10}, (_,i)=>`Paul${i+1}.png`);
let selectedSkin = /^Paul(?:[1-9]|10)\.png$/.test(localStorage.getItem('laPlaine.selectedSkin') || '') ? localStorage.getItem('laPlaine.selectedSkin') : 'Paul1.png';
function renderSkinChoices() {
    if (!skinGrid) return; skinGrid.replaceChildren();
    skinNames.forEach((name,i)=>{
        const button=document.createElement('button'); button.type='button'; button.className='skin-choice'+(name===selectedSkin?' selected':'');
        const img=document.createElement('img'); img.src=`/static/assets/textures/player/skins/${name}`; img.alt=`Skin Paul ${i+1}`;
        const label=document.createElement('span'); label.textContent=`Paul ${i+1}`; button.append(img,label);
        button.addEventListener('click',()=>{selectedSkin=name;localStorage.setItem('laPlaine.selectedSkin',name);renderSkinChoices();window.LaPlaineSkinPreview?.setSkin(name);document.getElementById('skin-preview-name').textContent=`Paul ${i+1}`;});
        skinGrid.appendChild(button);
    });
}
btnSkins?.addEventListener('click',()=>{closeAllModals();skinsModal.style.display='block';renderSkinChoices();window.LaPlaineSkinPreview?.setSkin(selectedSkin);});
document.getElementById('btn-close-skins')?.addEventListener('click',closeAllModals);
document.getElementById('btn-skins-done')?.addEventListener('click',closeAllModals);

btnPlay.addEventListener('click', () => {
    closeAllModals();
    worldsModal.style.display = 'block';
    loadWorlds();
});

document.getElementById('btn-close-worlds').addEventListener('click', closeAllModals);
document.getElementById('btn-back-worlds').addEventListener('click', closeAllModals);

document.getElementById('btn-new-world').addEventListener('click', () => {
    worldName.value = '';
    worldSeed.value = '';
    createWorldError.textContent = '';
    worldsModal.style.display = 'none';
    createWorldModal.style.display = 'block';
    worldName.focus();
});

document.getElementById('btn-close-create').addEventListener('click', () => {
    createWorldModal.style.display = 'none';
    worldsModal.style.display = 'block';
});

document.getElementById('btn-cancel-create').addEventListener('click', () => {
    createWorldModal.style.display = 'none';
    worldsModal.style.display = 'block';
});

document.getElementById('btn-create-world').addEventListener('click', async () => {
    const name = worldName.value.trim();
    const seed = worldSeed.value.trim();

    if (!name) {
        createWorldError.textContent = 'Donne un nom à ton monde.';
        worldName.focus();
        return;
    }

    createWorldError.textContent = '';

    try {
        const response = await fetch('/api/worlds', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name: name,
                seed: seed === '' ? null : seed,
                options: {
                    generateStructures: document.getElementById('world-structures')?.checked !== false,
                    mods: window.LaPlaineAPI?.getWorldCreationOptions?.() || []
                }
            })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || 'Impossible de créer le monde.');
        }

        window.location.href = `/game?world=${encodeURIComponent(data.world.id)}`;
    } catch (error) {
        createWorldError.textContent = error.message;
    }
});

btnSettings.addEventListener('click', () => {
    const wasOpen = settingsModal.style.display === 'block';
    closeAllModals();
    settingsModal.style.display = wasOpen ? 'none' : 'block';
    if (!wasOpen) {
        settingsViews.detail.hidden = true;
        settingsViews.home.hidden = false;
    }
});

btnControls.addEventListener('click', () => {
    const wasOpen = controlsModal.style.display === 'block';
    closeAllModals();
    controlsModal.style.display = wasOpen ? 'none' : 'block';
});

async function loadTexturePacks() {
    texturePackList.replaceChildren(Object.assign(document.createElement('div'), { className: 'world-empty', textContent: 'Chargement des packs…' }));
    try {
        const response = await fetch('/api/asset-packs', { cache: 'no-store' });
        if (!response.ok) throw new Error('Impossible de lire les packs.');
        const payload = await response.json();
        const selected = localStorage.getItem('laPlaine.assetPack') || localStorage.getItem('laPlaine.texturePack') || 'default';
        texturePackList.replaceChildren();
        for (const pack of payload.packs || []) {
            const label = document.createElement('label');
            label.className = 'resource-card';
            const radio = document.createElement('input');
            radio.type = 'radio'; radio.name = 'texture-pack'; radio.value = pack.id;
            radio.checked = pack.id === selected;
            radio.addEventListener('change', () => {
                localStorage.setItem('laPlaine.assetPack', pack.id);
                texturePackList.querySelectorAll('.resource-card').forEach(card => card.classList.remove('selected'));
                label.classList.add('selected');
            });
            const text = document.createElement('span'); text.className = 'resource-card-text';
            const title = document.createElement('strong'); title.textContent = pack.name || pack.id;
            const description = document.createElement('small'); description.textContent = `${pack.description || 'Aucune description'} · v${pack.version || '?'}`;
            text.append(title, description); label.append(radio, text);
            if (radio.checked) label.classList.add('selected');
            texturePackList.append(label);
        }
        if (!texturePackList.children.length) texturePackList.textContent = 'Aucun pack trouvé.';
    } catch (error) { texturePackList.textContent = error.message; }
}

async function loadShaders() {
    const list = document.getElementById('shader-pack-list');
    if (!list) return;
    list.replaceChildren(Object.assign(document.createElement('div'), { className: 'world-empty', textContent: 'Chargement des shaders…' }));
    try {
        const response = await fetch('/api/shaders', { cache: 'no-store' });
        if (!response.ok) throw new Error('Impossible de lire la liste des shaders.');
        const payload = await response.json();
        const packs = payload.shaders || [];
        const selected = localStorage.getItem('laPlaine.activeShader') || 'off';
        list.replaceChildren();
        const options = [{ id: 'off', name: 'Désactivés', description: 'Rendu normal, sans shader plein écran.', version: '' }, ...packs];
        for (const pack of options) {
            const label = document.createElement('label'); label.className = 'resource-card';
            const radio = document.createElement('input'); radio.type = 'radio'; radio.name = 'shader-pack'; radio.value = pack.id; radio.checked = pack.id === selected;
            radio.addEventListener('change', () => {
                localStorage.setItem('laPlaine.activeShader', pack.id);
                list.querySelectorAll('.resource-card').forEach(card => card.classList.remove('selected'));
                label.classList.add('selected');
            });
            const text = document.createElement('span'); text.className = 'resource-card-text';
            const title = document.createElement('strong'); title.textContent = pack.name || pack.id;
            const description = document.createElement('small'); description.textContent = `${pack.description || ''}${pack.version ? ` · v${pack.version}` : ''}`;
            text.append(title, description); label.append(radio, text); label.classList.toggle('selected', radio.checked); list.append(label);
        }
        if (!packs.length) {
            const hint = document.createElement('p'); hint.className = 'setting-description'; hint.textContent = 'Aucun ZIP shader valide trouvé. Un exemple est fourni dans static/shaders/.'; list.append(hint);
        }
    } catch (error) { list.textContent = error.message; }
}

async function loadMods() {
    modList.replaceChildren(Object.assign(document.createElement('div'), { className: 'world-empty', textContent: 'Chargement des mods…' }));
    try {
        const response = await fetch('/api/mods', { cache: 'no-store' });
        if (!response.ok) throw new Error('Impossible de lire la liste des mods.');
        const payload = await response.json();
        const mods = payload.mods || [];
        let enabled;
        try { enabled = JSON.parse(localStorage.getItem('laPlaine.enabledMods') || 'null'); } catch (_) { enabled = null; }
        if (!Array.isArray(enabled)) enabled = mods.map(mod => mod.id);
        modList.replaceChildren();
        if (!mods.length) {
            const empty = document.createElement('div'); empty.className = 'world-empty';
            empty.textContent = 'Aucun mod installé. Consulte static/mods/README.md pour créer ton premier mod.';
            modList.append(empty); return;
        }
        for (const mod of mods) {
            const label = document.createElement('label'); label.className = 'resource-card';
            const toggle = document.createElement('input'); toggle.type = 'checkbox'; toggle.checked = enabled.includes(mod.id);
            const text = document.createElement('span'); text.className = 'resource-card-text';
            const title = document.createElement('strong'); title.textContent = `${mod.name || mod.id} · v${mod.version || '?'}`;
            const description = document.createElement('small'); description.textContent = `${mod.description || 'Aucune description'} · ${mod.author || 'Auteur inconnu'} · ${mod.category || 'Divers'} · API ${mod.api_version || '?'}`;
            toggle.addEventListener('change', () => {
                const current = new Set(enabled);
                if (toggle.checked) current.add(mod.id); else current.delete(mod.id);
                enabled = [...current]; localStorage.setItem('laPlaine.enabledMods', JSON.stringify(enabled));
                label.classList.toggle('selected', toggle.checked);
            });
            text.append(title, description); label.append(toggle, text);
            label.classList.toggle('selected', toggle.checked); modList.append(label);
        }
    } catch (error) { modList.textContent = error.message; }
}

function openResourceModal(modal) {
    closeAllModals(); modal.style.display = 'block';
}
btnTexturePacks.addEventListener('click', () => { openResourceModal(texturePacksModal); loadTexturePacks(); });
btnMods.addEventListener('click', () => { openResourceModal(modsModal); loadMods(); });
for (const id of ['btn-close-texture-packs', 'btn-back-texture-packs']) document.getElementById(id).addEventListener('click', closeAllModals);
for (const id of ['btn-close-mods', 'btn-back-mods']) document.getElementById(id).addEventListener('click', closeAllModals);
document.getElementById('btn-refresh-texture-packs').addEventListener('click', loadTexturePacks);
document.getElementById('btn-refresh-mods').addEventListener('click', loadMods);

const volMasterInput = document.getElementById('vol-master');
const volMusicInput = document.getElementById('vol-music');
const volSfxInput = document.getElementById('vol-sfx');

const volMasterVal = document.getElementById('vol-master-val');
const volMusicVal = document.getElementById('vol-music-val');
const volSfxVal = document.getElementById('vol-sfx-val');

volMasterInput.value = soundManager.masterVolume * 100;
volMasterVal.textContent = Math.round(soundManager.masterVolume * 100) + '%';
volMusicInput.value = soundManager.musicVolume * 100;
volMusicVal.textContent = Math.round(soundManager.musicVolume * 100) + '%';
volSfxInput.value = soundManager.sfxVolume * 100;
volSfxVal.textContent = Math.round(soundManager.sfxVolume * 100) + '%';

volMasterInput.addEventListener('input', e => {
    volMasterVal.textContent = e.target.value + '%';
    soundManager.setMasterVolume(e.target.value / 100);
});

volMusicInput.addEventListener('input', e => {
    volMusicVal.textContent = e.target.value + '%';
    soundManager.setMusicVolume(e.target.value / 100);
});

volSfxInput.addEventListener('input', e => {
    volSfxVal.textContent = e.target.value + '%';
    soundManager.setSfxVolume(e.target.value / 100);
});

const renderInput = document.getElementById('render-distance');
const renderVal = document.getElementById('render-val');
const resSelect = document.getElementById('resolution-select');
const fpsSelect = document.getElementById('fps-limit-select');
const cloudToggleMenu = document.getElementById('cloud-toggle-menu');

const savedDistance = Math.max(1, Math.min(100, Number(localStorage.getItem('renderDistance')) || 6));
renderInput.value = savedDistance;
renderVal.textContent = savedDistance;
renderInput.addEventListener('input', e => {
    renderVal.textContent = e.target.value;
    localStorage.setItem('renderDistance', e.target.value);
});

fpsSelect.value = localStorage.getItem('fpsLimit') || 'max';
fpsSelect.addEventListener('change', e => localStorage.setItem('fpsLimit', e.target.value));

resSelect.value = localStorage.getItem('gameResolution') || 'auto';
resSelect.addEventListener('change', e => localStorage.setItem('gameResolution', e.target.value));

const resolutionScaleSelect = document.getElementById('resolution-scale-select');
const resolutionScaleValue = document.getElementById('resolution-scale-value');
resolutionScaleSelect.value = localStorage.getItem('resolutionScale') || '100';
const updateResolutionScaleLabel = () => { if (resolutionScaleValue) resolutionScaleValue.textContent = `${resolutionScaleSelect.value}%`; };
updateResolutionScaleLabel();
resolutionScaleSelect.addEventListener('input', e => {
    localStorage.setItem('resolutionScale', e.target.value);
    updateResolutionScaleLabel();
});

const autoResolutionToggle = document.getElementById('auto-resolution-toggle');
autoResolutionToggle.checked = localStorage.getItem('autoResolution') !== 'false';
autoResolutionToggle.addEventListener('change', e => localStorage.setItem('autoResolution', e.target.checked));

const chunkBudgetSelect = document.getElementById('chunk-budget-select');
const chunkBudgetValue = document.getElementById('chunk-budget-value');
chunkBudgetSelect.value = String(Math.max(0.5, Math.min(6, Number(localStorage.getItem('laPlaine.chunkBudget')) || 2.5)));
const updateChunkBudgetLabel = () => { chunkBudgetValue.textContent = `${String(chunkBudgetSelect.value).replace('.', ',')} ms`; };
updateChunkBudgetLabel();
chunkBudgetSelect.addEventListener('input', e => {
    localStorage.setItem('laPlaine.chunkBudget', e.target.value);
    updateChunkBudgetLabel();
});

const graphicsQualitySelect = document.getElementById('graphics-quality-select');
graphicsQualitySelect.value = localStorage.getItem('graphicsQuality') || 'medium';
graphicsQualitySelect.addEventListener('change', e => {
    localStorage.setItem('graphicsQuality', e.target.value);
    if (e.target.value === 'low') {
        localStorage.setItem('fxShaders', 'false');
    } else if (e.target.value === 'high') {
        localStorage.setItem('fxShaders', 'true');
    }
    const shadersToggle = document.getElementById('shaders-toggle-menu');
    if (shadersToggle) shadersToggle.checked = localStorage.getItem('fxShaders') !== 'false';
});

cloudToggleMenu.checked = localStorage.getItem('showClouds') !== 'false';
cloudToggleMenu.addEventListener('change', e => localStorage.setItem('showClouds', e.target.checked));

const vignetteToggleMenu = document.getElementById('vignette-toggle-menu');
vignetteToggleMenu.checked = localStorage.getItem('fxDamageVignette') !== 'false';
vignetteToggleMenu.addEventListener('change', e => localStorage.setItem('fxDamageVignette', e.target.checked));

const shadersToggleMenu = document.getElementById('shaders-toggle-menu');
shadersToggleMenu.checked = localStorage.getItem('fxShaders') !== 'false';
shadersToggleMenu.addEventListener('change', e => {
    if (window.shaderRegistry) window.shaderRegistry.setEnabled(e.target.checked);
    localStorage.setItem('fxShaders', e.target.checked);
});

const textures = [
    '/static/assets/textures/blocks/naturals/dirt/dirt.png',
    '/static/assets/textures/blocks/naturals/grass-blocks/grass_side.png',
    '/static/assets/textures/blocks/undergrounds/stones/stone.png',
    '/static/assets/textures/blocks/naturals/logs/sides/oak_side.png',
    '/static/assets/textures/blocks/naturals/leaves/oak_leaves.gif'
];

const bgSlideshow = document.getElementById('bg-slideshow');
let currentTextureIdx = 0;

function updateBackground() {
    bgSlideshow.style.backgroundImage = `url('${textures[currentTextureIdx]}')`;
    currentTextureIdx = (currentTextureIdx + 1) % textures.length;
}

updateBackground();
setInterval(updateBackground, 1000);

const btnDownload = document.getElementById('btn-download');
const downloadModal = document.getElementById('download-modal');
const btnCloseDownload = document.getElementById('btn-close-download');
if (btnDownload && downloadModal) {
    btnDownload.addEventListener('click', () => {
        closeAllModals();
        downloadModal.style.display = 'block';
    });
}
if (btnCloseDownload && downloadModal) {
    btnCloseDownload.addEventListener('click', () => downloadModal.style.display = 'none');
}
