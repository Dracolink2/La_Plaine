blockRegistry.register({ id: 17, name: 'Pierre', type: 'pickaxe', level: 1, breakTime: 1.4, textures: { all: '/static/assets/textures/blocks/undergrounds/stones/stone.png' }, transparent: false });

blockRegistry.register({ id: 2, name: 'Terre', type: 'shovel', level: 1, breakTime: 0.35, textures: { all: '/static/assets/textures/blocks/naturals/dirt/dirt.png' }, transparent: false });

blockRegistry.register({ id: 3, name: 'Herbe', type: 'shovel', level: 1, breakTime: 0.4, textures: { top: '/static/assets/textures/blocks/naturals/grass-blocks/grass_top.png', bottom: '/static/assets/textures/blocks/naturals/dirt/dirt.png', sides: '/static/assets/textures/blocks/naturals/grass-blocks/grass_side.png' }, transparent: false });

blockRegistry.register({ id: 4, name: 'Bois', type: 'axe', level: 1, breakTime: 0.8, textures: { top: '/static/assets/textures/blocks/naturals/logs/top/oak_top.png', bottom: '/static/assets/textures/blocks/naturals/logs/top/oak_top.png', sides: '/static/assets/textures/blocks/naturals/logs/sides/oak_side.png' }, transparent: false });

blockRegistry.register({ id: 5, name: 'Feuilles chêne', breakTime: 0.15, textures: { all: '/static/assets/textures/blocks/naturals/leaves/oak_leaves.gif' }, transparent: true, alphaTest: 0.5 });

blockRegistry.register({ id: 6, name: 'Haute herbe (bas)', breakTime: 0.2, textures: { all: '/static/assets/textures/blocks/naturals/grass/high_grass_down.png' }, transparent: true, alphaTest: 0.1, isPlant: true });

blockRegistry.register({ id: 63, name: 'Haute herbe (haut)', breakTime: 0.2, textures: { all: '/static/assets/textures/blocks/naturals/grass/high_grass_up.png' }, transparent: true, alphaTest: 0.1, isPlant: true, drop: null });

blockRegistry.register({ id: 64, name: 'Coquelicot', breakTime: 0.2, textures: { all: '/static/assets/textures/blocks/naturals/flowers/coquelicot.png' }, transparent: true, alphaTest: 0.1, isPlant: true });

blockRegistry.register({ id: 65, name: 'Le Socle', textures: { all: '/static/assets/textures/blocks/undergrounds/socle/socle.png' }, transparent: false, type: 'pickaxe', level: 99, breakTime: 999999, drop: null });

blockRegistry.register({ id: 7, name: 'Rose', breakTime: 0.2, textures: { all: '/static/assets/textures/blocks/naturals/flowers/rose.png' }, transparent: true, alphaTest: 0.5, isPlant: true });

blockRegistry.register({ id: 8, name: 'Pissenlit', breakTime: 0.2, textures: { all: '/static/assets/textures/blocks/naturals/flowers/dandelion.png' }, transparent: true, alphaTest: 0.5, isPlant: true });

blockRegistry.register({ id: 9, name: 'Sable', type: 'shovel', level: 1, breakTime: 0.3, textures: { all: '/static/assets/textures/blocks/sands/sand.png' }, transparent: false });

blockRegistry.register({ id: 10, name: 'Cactus', breakTime: 0.8, 'damage-per-sec': 0.5, 'grow-speed': 10, behaviors: ['damage', 'growth'], textures: { top: '/static/assets/textures/blocks/naturals/cactus/cactus_top.png', bottom: '/static/assets/textures/blocks/naturals/cactus/cactus_bottom.png', sides: '/static/assets/textures/blocks/naturals/cactus/cactus_side.png' }, transparent: false, alphaTest: 0.5 });

blockRegistry.register({ id: 11, name: 'Eau', 'ambient-sound': '/static/assets/sounds/effects/game/water_flow.ogg', behaviors: ['fluid'], textures: { all: '/static/assets/textures/liquids/water.png' }, transparent: true, alphaTest: 0.1, isFluid: true, viscosity: 1, drop: null, breakTime: 0 });

blockRegistry.register({ id: 12, name: 'Neige', breakTime: 0.2, textures: { all: '/static/assets/textures/blocks/naturals/others/neige.png' }, transparent: false });

blockRegistry.register({ id: 13, name: 'Herbe froide', breakTime: 0.4, 'infect-dirt-speed': 30, 'biome-transform': true, 'biome-transform1': 'plaines', 'biome-transform1-trans': 3, behaviors: ['biome-transform'], textures: { top: '/static/assets/textures/blocks/naturals/grass-blocks/grass_top_cold.png', bottom: '/static/assets/textures/blocks/naturals/dirt/dirt.png', sides: '/static/assets/textures/blocks/naturals/grass-blocks/grass_side_cold.png' }, transparent: false });

blockRegistry.register({ id: 14, name: 'Dalle de Neige', breakTime: 0.35, textures: { all: '/static/assets/textures/blocks/slabs/snow_slab.png' }, transparent: false, isSlab: true });

blockRegistry.register({ id: 15, name: 'Bûche de Sapin', type: 'axe', level: 1, breakTime: 0.8, textures: { top: '/static/assets/textures/blocks/naturals/logs/top/pine_top.png', bottom: '/static/assets/textures/blocks/naturals/logs/top/pine_top.png', sides: '/static/assets/textures/blocks/naturals/logs/sides/pine_side.png' }, transparent: false });

blockRegistry.register({ id: 16, name: 'Feuilles de sapin', breakTime: 0.2, textures: { all: '/static/assets/textures/blocks/naturals/leaves/pine_leaves.png' }, transparent: true, alphaTest: 0.5 });

blockRegistry.register({ id: 1, name: 'Deepslate', type: 'pickaxe', level: 2, breakTime: 2.2, textures: { all: '/static/assets/textures/blocks/undergrounds/deesplates/deepslate/deepslate.png' }, transparent: false });

blockRegistry.register({ id: 22, name: 'Fleur Nyamée', breakTime: 0.2, textures: { all: '/static/assets/textures/blocks/naturals/flowers/Fleur-Nyamee.png' }, transparent: true, alphaTest: 0.5, isPlant: true });

blockRegistry.register({ id: 24, name: 'Feuilles_Nyamée', breakTime: 0.2, textures: { all: '/static/assets/textures/blocks/naturals/leaves/Nyamee_leaves.png' }, transparent: true, alphaTest: 0.5 });

blockRegistry.register({ id: 25, name: 'Bois_Nyamée', type: 'axe', level: 1, breakTime: 0.8, textures: { top: '/static/assets/textures/blocks/naturals/logs/top/Nyamee_top.png', bottom: '/static/assets/textures/blocks/naturals/logs/top/Nyamee_top.png', sides: '/static/assets/textures/blocks/naturals/logs/sides/Nyamee_side.png' }, transparent: false });

blockRegistry.register({ id: 26, name: 'Herbe_Nyamée', breakTime: 0.4, textures: { top: '/static/assets/textures/blocks/naturals/grass-blocks/grass_top_Nyamee.png', bottom: '/static/assets/textures/blocks/naturals/dirt/dirt.png', sides: '/static/assets/textures/blocks/naturals/grass-blocks/grass_side_Nyamee.png' }, transparent: false });

blockRegistry.register({ id: 27, name: 'Feuilles_savane', breakTime: 0.2, textures: { all: '/static/assets/textures/blocks/naturals/leaves/acacia_leaves.gif' }, transparent: true, alphaTest: 0.5 });

blockRegistry.register({ id: 28, name: 'Bois_savane', type: 'axe', level: 1, breakTime: 0.8, textures: { top: '/static/assets/textures/blocks/naturals/logs/top/acacia_top.png', bottom: '/static/assets/textures/blocks/naturals/logs/top/acacia_top.png', sides: '/static/assets/textures/blocks/naturals/logs/sides/acacia_side.png' }, transparent: false });

blockRegistry.register({ id: 29, name: 'Herbe_Nyamée', breakTime: 0.4, textures: { top: '/static/assets/textures/blocks/naturals/grass-blocks/grass_top_hot.png', bottom: '/static/assets/textures/blocks/naturals/dirt/dirt.png', sides: '/static/assets/textures/blocks/naturals/grass-blocks/grass_side_hot.png' }, transparent: false });

blockRegistry.register({ id: 30, name: 'Herbe Noire', breakTime: 0.4, textures: { top: '/static/assets/textures/blocks/naturals/grass-blocks/grass_top_dark.png', bottom: '/static/assets/textures/blocks/naturals/dirt/dirt.png', sides: '/static/assets/textures/blocks/naturals/grass-blocks/grass_side_dark.png' }, transparent: false });

blockRegistry.register({ id: 31, name: 'Herbe chaude', breakTime: 0.4, textures: { top: '/static/assets/textures/blocks/naturals/grass-blocks/grass_top_hot.png', bottom: '/static/assets/textures/blocks/naturals/dirt/dirt.png', sides: '/static/assets/textures/blocks/naturals/grass-blocks/grass_side_hot.png' }, transparent: false });

blockRegistry.register({ id: 32, name: 'Lave', textures: { all: '/static/assets/textures/liquids/lava.png' }, transparent: true, alphaTest: 0.1, isFluid: true, viscosity: 2, lightLevel: 14, emitColor: 0xff6b24, lightIntensity: 0.42, lightRadius: 12, drop: null, breakTime: 0 });

blockRegistry.register({ id: 33, name: 'Sable rouge', breakTime: 0.35, textures: { all: '/static/assets/textures/blocks/sands/red_sand.png' }, transparent: false });

blockRegistry.register({ id: 34, name: 'Feuilles acacia', breakTime: 0.2, textures: { all: '/static/assets/textures/blocks/naturals/leaves/acacia_leaves.gif' }, transparent: true, alphaTest: 0.5 });

blockRegistry.register({ id: 35, name: 'Bois Noir', type: 'axe', level: 1, breakTime: 0.9, textures: { top: '/static/assets/textures/blocks/naturals/logs/top/dark_top.png', bottom: '/static/assets/textures/blocks/naturals/logs/top/dark_top.png', sides: '/static/assets/textures/blocks/naturals/logs/sides/dark_side.png' }, transparent: false });

blockRegistry.register({ id: 36, name: 'Feuilles Noire', breakTime: 0.2, textures: { all: '/static/assets/textures/blocks/naturals/leaves/dark_leaves.png' }, transparent: true, alphaTest: 0.5 });

blockRegistry.register({ id: 37, name: 'Magma', breakTime: 1.2, textures: { all: '/static/assets/textures/blocks/undergrounds/others/magma.png' }, transparent: false, lightLevel: 12, emitColor: 0xff5424, lightIntensity: 0.34, lightRadius: 8 });

blockRegistry.register({ id: 38, name: 'Obsidienne', type: 'pickaxe', level: 3, breakTime: 5, textures: { all: '/static/assets/textures/blocks/undergrounds/others/obsidian.png' }, transparent: false });

blockRegistry.register({ id: 39, name: 'Dalle de cendre', breakTime: 0.35, textures: { all: '/static/assets/textures/blocks/slabs/ash_slab.png' }, transparent: false, isSlab: true });

blockRegistry.register({ id: 40, name: 'Basalte', breakTime: 2.5, type: 'pickaxe', level: 1, textures: { top: '/static/assets/textures/blocks/undergrounds/others/basalt_top.png', bottom: '/static/assets/textures/blocks/undergrounds/others/basalt_top.png', sides: '/static/assets/textures/blocks/undergrounds/others/basalt_side.png' }, transparent: false });

blockRegistry.register({
    id: 18,
    name: 'Pied de Champignon', breakTime: 0.8,
    textures: { all: '/static/assets/textures/blocks/naturals/mushrooms/mushroom_stem.png' },
    transparent: false
});

blockRegistry.register({
    id: 19,
    name: 'Chapeau Champignon Rouge', breakTime: 0.5,
    textures: { all: '/static/assets/textures/blocks/naturals/mushrooms/mushroom_block_red.png' },
    transparent: false
});

blockRegistry.register({
    id: 20,
    name: 'Mycélium', breakTime: 0.5,
    textures: {
        top: '/static/assets/textures/blocks/naturals/grass-blocks/mycelium_top.png',
        bottom: '/static/assets/textures/blocks/naturals/dirt/dirt.png',
        sides: '/static/assets/textures/blocks/naturals/grass-blocks/mycelium_side.png'
    },
    transparent: false
});

blockRegistry.register({
    id: 21,
    name: 'Petit Champignon', breakTime: 0.2,
    textures: { all: '/static/assets/textures/blocks/naturals/mushrooms/red_mushroom.png' },
    transparent: true,
    alphaTest: 0.5,
    isPlant: true,
    lightLevel: 8, 
    emitColor: 0xff4444
});

blockRegistry.register({
    id: 23,
    name: 'Feuilles d automne', breakTime: 0.2,
    textures: { all: '/static/assets/textures/blocks/naturals/leaves/automne-leaves.gif' },
    transparent: true,
    alphaTest: 0.5
});


blockRegistry.register({ id: 55, name: 'Minerai de charbon', 'drop-rate': '100%', 'drop-number': 1, 'XP-drop': 1, textures: { all: '/static/assets/textures/blocks/undergrounds/stones/ores/coal_ore.png' }, transparent: false, drop: 1102, type: 'pickaxe', level: 1, breakTime: 1.2 });
blockRegistry.register({ id: 56, name: 'Minerai de cuivre', textures: { all: '/static/assets/textures/blocks/undergrounds/stones/ores/cooper_ore.png' }, transparent: false, drop: 1114, type: 'pickaxe', level: 2, breakTime: 1.6 });
blockRegistry.register({ id: 57, name: 'Minerai de diamant', textures: { all: '/static/assets/textures/blocks/undergrounds/stones/ores/diamond_ore.png' }, transparent: false, drop: 1115, type: 'pickaxe', level: 3, breakTime: 2.4 });
blockRegistry.register({ id: 62, name: 'Torche', blockType: 'torch', textures: { all: '/static/assets/textures/items/others/torche.png' }, transparent: true, alphaTest: 0.08, isPlant: false, lightLevel: 14, emitColor: 0xffc36b, lightColor: 0xffc36b, lightIntensity: 0.92, lightRadius: 10, lightFlicker: true, breakTime: 0.2, drop: 62, 'drop-number': 1 });
blockRegistry.register({ id: 66, name: 'Calcite', breakTime: 1.3, type: 'pickaxe', level: 1, textures: { all: '/static/assets/textures/blocks/undergrounds/others/calcite.png' }, transparent: false });
blockRegistry.register({ id: 67, name: 'Gravier', breakTime: 0.35, type: 'shovel', level: 1, behaviors: ['falling'], textures: { all: '/static/assets/textures/blocks/undergrounds/others/gravel.png' }, transparent: false });
blockRegistry.register({ id: 68, name: 'Argile', breakTime: 0.6, type: 'shovel', level: 1, textures: { all: '/static/assets/textures/blocks/undergrounds/others/clay.png' }, transparent: false });
blockRegistry.register({ id: 69, name: 'Bloc de mousse', breakTime: 0.4, textures: { all: '/static/assets/textures/blocks/naturals/others/mosse_block.png' }, transparent: false });
blockRegistry.register({ id: 70, name: 'Minerai de charbon de deepslate', textures: { all: '/static/assets/textures/blocks/undergrounds/deesplates/ores/deepslate-coal.png' }, transparent: false, drop: 1102, type: 'pickaxe', level: 2, breakTime: 1.6 });
blockRegistry.register({ id: 71, name: 'Minerai de fer de deepslate', textures: { all: '/static/assets/textures/blocks/undergrounds/deesplates/ores/deepslate-iron.png' }, transparent: false, drop: 1103, type: 'pickaxe', level: 2, breakTime: 2.1 });
blockRegistry.register({ id: 72, name: 'Minerai de cuivre de deepslate', textures: { all: '/static/assets/textures/blocks/undergrounds/deesplates/ores/deepslate-cooper.png' }, transparent: false, drop: 1114, type: 'pickaxe', level: 2, breakTime: 2.0 });
blockRegistry.register({ id: 73, name: 'Minerai de diamant de deepslate', textures: { all: '/static/assets/textures/blocks/undergrounds/deesplates/ores/deepslate-diamond.png' }, transparent: false, drop: 1115, type: 'pickaxe', level: 3, breakTime: 2.8 });

blockRegistry.register({ id: 41, name: 'Planche de chêne', type: 'axe', level: 1, breakTime: 0.5, textures: { all: '/static/assets/textures/blocks/crafted/planks/oak_plank.png' }, transparent: false });

blockRegistry.register({ id: 42, name: 'Planche d acacia', type: 'axe', level: 1, breakTime: 0.5, textures: { all: '/static/assets/textures/blocks/crafted/planks/acacia_plank.png' }, transparent: false });

blockRegistry.register({ id: 43, name: 'Planche noire', type: 'axe', level: 1, breakTime: 0.5, textures: { all: '/static/assets/textures/blocks/crafted/planks/dark_plank.png' }, transparent: false });

blockRegistry.register({ id: 44, name: 'Planche de Nyamée', type: 'axe', level: 1, breakTime: 0.5, textures: { all: '/static/assets/textures/blocks/crafted/planks/nyamee_plank.png' }, transparent: false });

blockRegistry.register({ id: 45, name: 'Planche de sapin', type: 'axe', level: 1, breakTime: 0.5, textures: { all: '/static/assets/textures/blocks/crafted/planks/pine_plank.png' }, transparent: false });

blockRegistry.register({ id: 46, name: 'Pierre taillée', breakTime: 1.5, textures: { all: '/static/assets/textures/blocks/undergrounds/stones/chiseled_stone.png' }, transparent: false });

blockRegistry.register({ id: 47, name: 'Pierre taillée cassée', breakTime: 2.0, textures: { all: '/static/assets/textures/blocks/undergrounds/stones/broken_chiseled_stone.png' }, transparent: false });

blockRegistry.register({ id: 48, name: 'Brick', breakTime: 1.5, textures: { all: '/static/assets/textures/blocks/crafted/bricks/brick.png' }, transparent: false });

blockRegistry.register({ id: 49, name: 'Brick de deepslate', breakTime: 2.0, textures: { all: '/static/assets/textures/blocks/undergrounds/deesplates/deepslate/deepslate_brick.png' }, transparent: false });

blockRegistry.register({ id: 50, name: 'Brick de deepslate cassée', breakTime: 2.0, textures: { all: '/static/assets/textures/blocks/undergrounds/deesplates/deepslate/broken-deepslate-brick.png' }, transparent: false });

blockRegistry.register({ id: 51, name: 'verre', breakTime: 0.3, textures: { all: '/static/assets/textures/blocks/crafted/glass/glass.png' }, transparent: true });
blockRegistry.register({ id: 52, name: 'Minerai de fer', textures: { all: '/static/assets/textures/blocks/undergrounds/stones/ores/iron_ore.png' }, transparent: false, drop: 1103, type: 'pickaxe', level: 2, breakTime: 1.7 });

blockRegistry.register({ id: 54, name: 'Table de craft', textures: { top: '/static/assets/textures/blocks/crafted/utils/crafting-table/crafting_table_top.png', bottom: '/static/assets/textures/blocks/crafted/utils/crafting-table/crafting_table_top.png', sides: '/static/assets/textures/blocks/crafted/utils/crafting-table/crafting_table_side.png' }, transparent: false, breakTime: 1.2 });

blockRegistry.register({ id: 58, name: 'Bloc de charbon', textures: { all: '/static/assets/textures/blocks/undergrounds/ore-blocks/coal_block.png' }, transparent: false, type: 'pickaxe', level: 1, breakTime: 3.0 });


blockRegistry.register({ id: 53, name: 'Four', textures: { all: '/static/assets/textures/blocks/crafted/utils/furnace/furnace_off.png' }, transparent: false, type: 'pickaxe', level: 1, breakTime: 2.5 });

