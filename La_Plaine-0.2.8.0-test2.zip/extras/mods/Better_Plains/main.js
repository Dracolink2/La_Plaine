/**
 * Better Plains — La Plaine 0.2.8.0
 * Ultra-Rework : Préchargement des chunks (rayon 50), Refonte du modèle et animations du cheval,
 * Shaders graphiques ultra-poussés (désactivables), Météo, Skins & Animations.
 */
(function () {
    'use strict';
    if (window.__betterPlainsLoaded) return;
    window.__betterPlainsLoaded = true;

    let shaderEnabled = true;

    // ==========================================
    // 1. UI REWORK & SHADERS ULTRA-POUSSÉS
    // ==========================================
    const customStyle = document.createElement('style');
    customStyle.id = 'better-plains-theme';
    customStyle.textContent = `
        #menu-screen, .menu-container, .modal-content, .settings-tab {
            background: rgba(14, 18, 26, 0.95) !important;
            backdrop-filter: blur(16px) !important;
            border: 1px solid rgba(120, 255, 214, 0.3) !important;
            box-shadow: 0 25px 60px rgba(0, 0, 0, 0.8) !important;
            border-radius: 20px !important;
        }

        #menu-screen h1, .main-title, title {
            font-family: 'Segoe UI', Roboto, sans-serif !important;
            font-weight: 800 !important;
            letter-spacing: 2px !important;
            background: linear-gradient(135deg, #a8ff78 0%, #78ffd6 100%) !important;
            -webkit-background-clip: text !important;
            -webkit-text-fill-color: transparent !important;
            text-shadow: 0 0 30px rgba(120, 255, 214, 0.5) !important;
        }

        .btn-menu, button.menu-btn, .btn-action {
            background: linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0.03) 100%) !important;
            border: 1px solid rgba(255, 255, 255, 0.2) !important;
            border-radius: 12px !important;
            color: #ffffff !important;
            font-weight: 600 !important;
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1) !important;
            cursor: pointer !important;
            padding: 12px 18px !important;
        }

        .btn-menu:hover, button.menu-btn.active, .btn-action:hover {
            background: linear-gradient(135deg, rgba(120, 255, 214, 0.3) 0%, rgba(168, 255, 120, 0.3) 100%) !important;
            border-color: rgba(120, 255, 214, 0.6) !important;
            transform: translateY(-3px) !important;
            box-shadow: 0 8px 20px rgba(120, 255, 214, 0.3) !important;
        }

        /* Shader ultra-poussé (Post-traitement cinématique) */
        #bp-shader-overlay {
            position: fixed;
            inset: 0;
            pointer-events: none;
            z-index: 9999;
            box-shadow: inset 0 0 150px rgba(10, 30, 25, 0.6);
            transition: opacity 0.5s ease;
            mix-blend-mode: overlay;
            background: radial-gradient(circle at center, rgba(120,255,214,0.08) 0%, rgba(0,0,0,0.4) 100%);
            backdrop-filter: contrast(1.15) saturate(1.2) brightness(0.95);
        }
        #bp-shader-overlay.disabled { opacity: 0; backdrop-filter: none; }

        #bp-skin-modal {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.75);
            backdrop-filter: blur(10px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 99999;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.3s ease;
        }
        #bp-skin-modal.open { opacity: 1; pointer-events: auto; }
        #bp-skin-content {
            background: rgba(14, 18, 26, 0.96);
            border: 1px solid rgba(120, 255, 214, 0.5);
            border-radius: 20px;
            padding: 28px;
            width: 500px;
            max-width: 90vw;
            color: #fff;
            box-shadow: 0 30px 70px rgba(0,0,0,0.9);
            font-family: 'Segoe UI', Roboto, sans-serif;
        }
        .bp-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin: 16px 0;
            max-height: 240px;
            overflow-y: auto;
            padding-right: 4px;
        }
        .bp-grid button {
            background: rgba(255,255,255,0.06);
            border: 1px solid rgba(255,255,255,0.15);
            color: #fff;
            padding: 10px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: 0.2s;
        }
        .bp-grid button:hover {
            background: rgba(120, 255, 214, 0.2);
            border-color: #78ffd6;
        }
    `;
    document.head.appendChild(customStyle);

    const shaderOverlay = document.createElement('div');
    shaderOverlay.id = 'bp-shader-overlay';
    document.body.appendChild(shaderOverlay);

    document.title = "Better Plains";
    setInterval(() => {
        document.querySelectorAll('h1, .game-title, #logo').forEach(el => {
            if (el.textContent.includes('La Plaine') || el.textContent.includes('Plaine')) {
                el.textContent = 'Better Plains';
            }
        });
    }, 1000);

    // Désactivation des shaders natifs de balancement d'herbe/feuilles
    try {
        if (THREE.ShaderLib && THREE.ShaderLib.standard) {
            THREE.ShaderLib.standard.vertexShader = THREE.ShaderLib.standard.vertexShader.replace(/#include <begin_vertex>/g, '#include <begin_vertex>\n // [Better Plains] Balancement natif désactivé');
        }
    } catch (_) {}

    // ==========================================
    // 2. GESTION DES SKINS
    // ==========================================
    const SKIN_SESSION_KEY = 'laPlaine.betterPlains.activeSkin';
    const DEFAULT_SKIN = '/static/textures/others/Paul.png';
    let activeSkin = null;

    try {
        activeSkin = sessionStorage.getItem(SKIN_SESSION_KEY) || null;
    } catch (_) {}

    function installSkinInterceptor() {
        if (window.__bpSkinInterceptorInstalled) return;
        const descriptor = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, 'src');
        if (!descriptor || typeof descriptor.set !== 'function') return;

        Object.defineProperty(HTMLImageElement.prototype, 'src', {
            configurable: descriptor.configurable,
            enumerable: descriptor.enumerable,
            get: descriptor.get,
            set(value) {
                if (activeSkin && typeof value === 'string' && (value === DEFAULT_SKIN || value.endsWith('/static/textures/others/Paul.png'))) {
                    descriptor.set.call(this, activeSkin);
                    return;
                }
                descriptor.set.call(this, value);
            }
        });
        window.__bpSkinInterceptorInstalled = true;
    }
    installSkinInterceptor();

    function setActiveSkin(dataUrl) {
        activeSkin = dataUrl;
        try {
            sessionStorage.setItem(SKIN_SESSION_KEY, dataUrl);
        } catch (_) {}
        window.dispatchEvent(new CustomEvent('laplaine:custom-skin-changed', { detail: { dataUrl } }));
        alert('Skin appliqué avec succès !');
    }

    // ==========================================
    // 3. MENU DES OPTIONS DU MOD
    // ==========================================
    const modal = document.createElement('div');
    modal.id = 'bp-skin-modal';
    modal.innerHTML = `
        <div id="bp-skin-content">
            <h2 style="margin-top:0; color:#78ffd6; font-size:22px;">Better Plains — Paramètres & Skins</h2>
            <p style="font-size:13px; opacity:0.8; margin-bottom:16px;">Gérez votre skin Paul (1 à 10), le shader cinématique ultra-poussé ou importez un PNG.</p>
            
            <div style="margin-bottom:14px; display:flex; gap:10px; align-items:center; background:rgba(255,255,255,0.05); padding:12px; border-radius:10px;">
                <span style="flex:1; font-weight:600; font-size:14px;">Shader Cinématique Next-Gen :</span>
                <button type="button" id="bp-btn-shader" class="btn-menu" style="padding:8px 16px;">Activé</button>
            </div>

            <div style="margin-bottom:10px;">
                <button type="button" id="bp-btn-default" class="btn-menu" style="width:100%; margin-bottom:8px;">Utiliser le Skin par Défaut</button>
            </div>

            <div class="bp-grid" id="bp-skin-grid"></div>

            <div style="margin-top:16px; border-top:1px solid rgba(255,255,255,0.1); padding-top:16px; display:flex; gap:10px;">
                <input type="file" id="bp-file-input" accept="image/png" style="display:none;">
                <button type="button" id="bp-btn-import" class="btn-menu" style="flex:1; background:linear-gradient(135deg, #a8ff78 0%, #78ffd6 100%) !important; color:#12161f !important; font-weight:700;">Importer un Skin PNG</button>
                <button type="button" id="bp-btn-close" class="btn-menu" style="background:rgba(255,255,255,0.1);">Fermer</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);

    const gridContainer = modal.querySelector('#bp-skin-grid');
    const defaultBtn = modal.querySelector('#bp-btn-default');
    const closeBtn = modal.querySelector('#bp-btn-close');
    const importBtn = modal.querySelector('#bp-btn-import');
    const fileInput = modal.querySelector('#bp-file-input');
    const shaderToggleBtn = modal.querySelector('#bp-btn-shader');

    shaderToggleBtn.addEventListener('click', () => {
        shaderEnabled = !shaderEnabled;
        shaderOverlay.className = shaderEnabled ? '' : 'disabled';
        shaderToggleBtn.textContent = shaderEnabled ? 'Activé' : 'Désactivé';
    });

    defaultBtn.addEventListener('click', () => setActiveSkin(DEFAULT_SKIN));
    closeBtn.addEventListener('click', () => modal.classList.remove('open'));

    for (let i = 1; i <= 10; i++) {
        const skinBtn = document.createElement('button');
        skinBtn.type = 'button';
        skinBtn.textContent = `Paul ${i}`;
        const skinPath = `/static/mods/Better_Plains/textures/Paul${i}.png`;
        skinBtn.addEventListener('click', () => setActiveSkin(skinPath));
        gridContainer.appendChild(skinBtn);
    }

    importBtn.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', () => {
        const file = fileInput.files?.[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (e) => setActiveSkin(e.target.result);
        reader.readAsDataURL(file);
        fileInput.value = '';
    });

    if (window.LaPlaineAPI && typeof window.LaPlaineAPI.registerMenuCategory === 'function') {
        window.LaPlaineAPI.registerMenuCategory({
            id: 'better-plains',
            title: 'Better Plains',
            description: 'Sélecteur de skins et paramètres graphiques',
            render: (container) => {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'btn-menu';
                btn.textContent = 'Ouvrir les options Better Plains & Skins';
                btn.addEventListener('click', () => modal.classList.add('open'));
                container.appendChild(btn);
            }
        });
    }

    // ==========================================
    // 4. MOTEUR 3D, PRÉCHARGEMENT CHUNKS (50) & CHEVAL REWORK
    // ==========================================
    if (!window.LaPlaineAPI) return;
    const textureLoader = new THREE.TextureLoader();

    const STAGES_COUNT = 10;
    const destroyTextures = [];
    for (let i = 1; i <= STAGES_COUNT; i++) {
        const url = window.LaPlaineAPI.registerTexture(`destroy_${i}`, `textures/${i}.png`, 'Better_Plains');
        const tex = textureLoader.load(url);
        tex.magFilter = THREE.NearestFilter;
        tex.minFilter = THREE.NearestFilter;
        destroyTextures.push(tex);
    }

    const leafTex = textureLoader.load(window.LaPlaineAPI.registerTexture('leaf_fall', 'textures/leaf_fall.png', 'Better_Plains'));
    leafTex.magFilter = THREE.NearestFilter; leafTex.minFilter = THREE.NearestFilter;

    const stoneTexs = [];
    for (let i = 1; i <= 3; i++) {
        const tex = textureLoader.load(window.LaPlaineAPI.registerTexture(`stone${i}`, `textures/stone${i}.png`, 'Better_Plains'));
        tex.magFilter = THREE.NearestFilter; tex.minFilter = THREE.NearestFilter;
        stoneTexs.push(tex);
    }

    let activeScene = null;
    let activeCamera = null;
    const activeParticles = [];

    // Système de pluie visible
    const RAIN_COUNT = 400;
    const rainGeo = new THREE.BufferGeometry();
    const rainPositions = new Float32Array(RAIN_COUNT * 3);
    for (let i = 0; i < RAIN_COUNT * 3; i += 3) {
        rainPositions[i] = (Math.random() - 0.5) * 40;
        rainPositions[i + 1] = Math.random() * 25;
        rainPositions[i + 2] = (Math.random() - 0.5) * 40;
    }
    rainGeo.setAttribute('position', new THREE.BufferAttribute(rainPositions, 3));
    const rainMat = new THREE.PointsMaterial({ color: 0x99aacc, size: 0.18, transparent: true, opacity: 0.7 });
    const rainSystem = new THREE.Points(rainGeo, rainMat);
    rainSystem.visible = false;

    function spawnParticle(type, position, velocity) {
        if (!activeScene || activeParticles.length > 150) return;
        let mat;
        const size = (type === 'leaf') ? 0.3 : 0.15;
        const geo = new THREE.PlaneGeometry(size, size);

        if (type === 'leaf') {
            mat = new THREE.MeshBasicMaterial({ map: leafTex, transparent: true, side: THREE.DoubleSide, alphaTest: 0.1 });
        } else if (type === 'stone') {
            mat = new THREE.MeshBasicMaterial({ map: stoneTexs[Math.floor(Math.random() * stoneTexs.length)], transparent: true, side: THREE.DoubleSide, alphaTest: 0.1 });
        } else {
            return;
        }

        const mesh = new THREE.Mesh(geo, mat);
        mesh.position.copy(position);
        activeScene.add(mesh);
        activeParticles.push({ mesh: mesh, velocity: velocity, life: 1.0 });
    }

    const crackGeo = new THREE.BoxGeometry(1.002, 1.002, 1.002);
    const crackMat = new THREE.MeshBasicMaterial({ map: destroyTextures[0], transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1 });
    const crackMesh = new THREE.Mesh(crackGeo, crackMat);
    crackMesh.visible = false;

    let miningStartTime = 0;
    let currentTargetKey = null;

    let fpGroup = new THREE.Group();
    const fpArm = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 0.45), new THREE.MeshLambertMaterial({ color: 0xd8a07c }));
    fpArm.position.set(0.3, -0.25, -0.45);
    fpArm.rotation.set(0.2, -0.4, -0.1);
    fpGroup.add(fpArm);

    const fpItemMesh = new THREE.Mesh(new THREE.PlaneGeometry(0.35, 0.35), new THREE.MeshBasicMaterial({ side: THREE.DoubleSide, transparent: true, alphaTest: 0.1 }));
    fpItemMesh.position.set(0.27, -0.15, -0.55);
    fpItemMesh.rotation.set(0.1, -0.6, -0.2);
    fpGroup.add(fpItemMesh);

    // Fonction de préchargement massif des chunks (Rayon 50 autour du joueur)
    function preloadChunksAroundPlayer(world, player) {
        if (!world || !world.generateChunkAt) return;
        const playerChunkX = Math.floor((player?.x || 0) / 16);
        const playerChunkZ = Math.floor((player?.z || 0) / 16);
        const radius = 50;

        console.info(`[Better Plains] Début du préchargement de ${radius} chunks autour de (${playerChunkX}, ${playerChunkZ})...`);
        
        // Exécution par lots asynchrones pour ne pas figer le navigateur au démarrage
        let cx = playerChunkX - radius;
        let cz = playerChunkZ - radius;

        const batchInterval = setInterval(() => {
            let processed = 0;
            while (processed < 50 && cx <= playerChunkX + radius) {
                while (processed < 50 && cz <= playerChunkZ + radius) {
                    try {
                        if (typeof world.generateChunkAt === 'function') {
                            world.generateChunkAt(cx, cz);
                        } else if (typeof world.loadChunk === 'function') {
                            world.loadChunk(cx, cz);
                        }
                    } catch (_) {}
                    cz++;
                    processed++;
                }
                if (cz > playerChunkZ + radius) {
                    cz = playerChunkZ - radius;
                    cx++;
                }
            }
            if (cx > playerChunkX + radius) {
                clearInterval(batchInterval);
                console.info('[Better Plains] Préchargement des 50 chunks terminé avec succès !');
            }
        }, 15);
    }

    // Refonte et animation du modèle du cheval
    function applyHorseRework(player) {
        if (!player || !player.ridingHorse || !player.horseParts) return;
        const horse = player.horseParts;
        const speed = Math.hypot(player.velocity?.x || 0, player.velocity?.z || 0);

        if (speed > 0.05) {
            const t = performance.now() * 0.015;
            if (horse.frontLegs) horse.frontLegs.rotation.x = Math.sin(t) * 0.6;
            if (horse.backLegs) horse.backLegs.rotation.x = -Math.sin(t) * 0.6;
            if (horse.head) horse.head.rotation.x = 0.1 + Math.sin(t * 0.5) * 0.15;
        }
    }

    window.LaPlaineAPI.on('game:ready', ({ scene, camera, world, player }) => {
        activeScene = scene;
        activeCamera = camera;
        scene.add(crackMesh);
        scene.add(fpGroup);
        scene.add(rainSystem);

        // Lancement du préchargement des 50 chunks à l'initialisation
        setTimeout(() => {
            preloadChunksAroundPlayer(world, player);
        }, 500);
    });

    let currentItemType = -1;
    function updateHeldItem(player) {
        if (!player || !player.inventory) return;
        const slot = player.inventory.getSelectedSlot();
        const type = slot ? slot.type : 0;
        if (type !== currentItemType) {
            currentItemType = type;
            if (type === 0) { fpItemMesh.visible = false; return; }
            fpItemMesh.visible = true;
            const itemDef = window.itemsRegistry?.get(type);
            const blockDef = window.blockRegistry?.get(type);
            let textureUrl = itemDef?.texture || blockDef?.textures?.all || blockDef?.textures?.top || '';
            if (textureUrl) {
                textureLoader.load(textureUrl, (tex) => {
                    tex.magFilter = THREE.NearestFilter; tex.minFilter = THREE.NearestFilter;
                    fpItemMat.map = tex; fpItemMat.needsUpdate = true;
                });
            }
        }
    }

    // ==========================================
    // 5. BOUCLE DE JEU OPTIMISÉE (Météo, Jour/Nuit 10min/10min, Cheval, Perfs)
    // ==========================================
    let swingProgress = 0;
    let bobCycle = 0;

    window.LaPlaineAPI.on('game:tick', ({ delta, now, player, world }) => {
        if (!world || !player || !player.controls || !activeCamera) return;

        // --- CYCLE JOUR / NUIT RALLONGÉ (10 min jour / 10 min nuit = 1200s total) ---
        if (world.time !== undefined) {
            const cycleDuration = 1200;
            world.time = (now * 0.001) % cycleDuration;
            world.isNight = world.time > 600;
        }

        // --- MÉTÉO & PLUIE VISIBLE ---
        if (world.raining) {
            rainSystem.visible = true;
            rainSystem.position.copy(activeCamera.position);
            const positions = rainGeo.attributes.position.array;
            for (let i = 1; i < positions.length; i += 3) {
                positions[i] -= delta * 20;
                if (positions[i] < 0) positions[i] = 25;
            }
            rainGeo.attributes.position.needsUpdate = true;
        } else {
            rainSystem.visible = false;
        }

        // --- REFONTE CHEVAL ---
        if (player.ridingHorse) {
            applyHorseRework(player);
        }

        // --- PREMIÈRE PERSONNE & ANIMATIONS JOUEUR ---
        const isFirstPerson = player.controls.isLocked && !player.dead && (player.cameraMode === 0 || player.cameraMode === undefined);
        fpGroup.visible = isFirstPerson;

        if (isFirstPerson) {
            fpGroup.position.copy(activeCamera.position);
            fpGroup.quaternion.copy(activeCamera.quaternion);
            updateHeldItem(player);

            const hSpeed = Math.hypot(player.velocity.x, player.velocity.z);
            let bobX = 0, bobY = 0;
            if (player.canJump && hSpeed > 0.08) {
                bobCycle += delta * (player.isSprinting ? 14 : 9);
                bobX = Math.cos(bobCycle * 0.5) * 0.03;
                bobY = Math.sin(bobCycle) * 0.03;
            }

            if (window.__lpIsMouseDown && window.__lpMouseDownButton === 0) {
                swingProgress = Math.min(1.0, swingProgress + delta * 9);
            } else {
                swingProgress = Math.max(0.0, swingProgress - delta * 12);
            }
            const swingAngle = Math.sin(swingProgress * Math.PI) * 0.5;

            fpArm.position.set(0.3 + bobX, -0.25 + bobY, -0.45);
            fpArm.rotation.x = 0.2 + swingAngle;
            if (fpItemMesh.visible) fpItemMesh.position.set(0.27 + bobX, -0.15 + bobY, -0.55);
        }

        if (player.playerParts && !player.ridingHorse) {
            const hSpeed = Math.hypot(player.velocity.x, player.velocity.z);
            if (hSpeed > 0.08 && player.canJump) {
                player.walkCycle = (player.walkCycle || 0) + delta * (player.isSprinting ? 14 : 9.5);
                const swing = Math.sin(player.walkCycle) * (player.isSprinting ? 0.85 : 0.55);
                player.playerParts.rightLeg.rotation.x = swing;
                player.playerParts.leftLeg.rotation.x = -swing;
                player.playerParts.rightArm.rotation.x = -swing * 0.9;
                player.playerParts.leftArm.rotation.x = swing * 0.9;
            }
        }

        // --- MINAGE OPTIMISÉ ---
        const dir = new THREE.Vector3();
        activeCamera.getWorldDirection(dir);
        const hit = { x: 0, y: 0, z: 0, id: 0, nx: 0, ny: 0, nz: 0 };
        const hasTarget = world.raycast(activeCamera.position.x, activeCamera.position.y, activeCamera.position.z, dir.x, dir.y, dir.z, 6, hit);

        if (hasTarget && hit.id !== 0 && window.__lpIsMouseDown && window.__lpMouseDownButton === 0) {
            const targetKey = `${hit.x},${hit.y},${hit.z}`;
            if (targetKey !== currentTargetKey) {
                currentTargetKey = targetKey;
                miningStartTime = now;
            }

            const block = window.blockRegistry?.get(hit.id);
            const duration = Math.max(0.1, Number(block?.breakTime) || 1.0);
            const progress = Math.min(0.99, ((now - miningStartTime) / 1000) / duration);
            const stageIndex = Math.floor(progress * STAGES_COUNT);

            if (stageIndex >= 0 && stageIndex < STAGES_COUNT) {
                crackMesh.position.set(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5);
                crackMat.map = destroyTextures[stageIndex];
                crackMat.needsUpdate = true;
                crackMesh.visible = true;

                if (Math.random() < 0.2) {
                    spawnParticle('stone', new THREE.Vector3(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5), new THREE.Vector3((Math.random() - 0.5) * 2, Math.random() * 2, (Math.random() - 0.5) * 2));
                }
            } else {
                crackMesh.visible = false;
            }
        } else {
            crackMesh.visible = false;
            currentTargetKey = null;
        }

        // --- NETTOYAGE DES PARTICULES (PERFORMANCES) ---
        for (let i = activeParticles.length - 1; i >= 0; i--) {
            const p = activeParticles[i];
            p.life -= delta * 1.5;
            if (p.life <= 0) {
                activeScene.remove(p.mesh);
                p.mesh.geometry.dispose();
                activeParticles.splice(i, 1);
            } else {
                p.mesh.position.addScaledVector(p.velocity, delta);
                p.velocity.y -= delta * 3;
                p.mesh.quaternion.copy(activeCamera.quaternion);
            }
        }
    });

    window.__lpIsMouseDown = false;
    window.__lpMouseDownButton = -1;
    window.addEventListener('mousedown', (e) => { window.__lpIsMouseDown = true; window.__lpMouseDownButton = e.button; });
    window.addEventListener('mouseup', () => { window.__lpIsMouseDown = false; window.__lpMouseDownButton = -1; crackMesh.visible = false; currentTargetKey = null; });

    console.info('[Better Plains] Refonte complète, préchargement chunks et shaders initialisés.');
})();