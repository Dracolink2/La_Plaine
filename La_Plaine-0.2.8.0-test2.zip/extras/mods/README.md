# Mods — La Plaine 0.2.8.0

Place each mod in its own folder under `extras/mods/<mod-id>/` with a `manifest.json` and an entry script.

Example manifest:

```json
{
  "id": "example-mod",
  "name": "Example Mod",
  "version": "1.0.0",
  "api_version": "5",
  "compatibility": "0.2.8.0",
  "dependencies": [],
  "entry": "main.js"
}
```

`compatibility` accepts `*` or the exact game version. Dependencies are other mod folder IDs and are loaded first. IDs must use letters, digits, `_` or `-`. Entry paths are relative to the mod folder and cannot traverse outside it.

**Security warning:** mods are JavaScript loaded into the game's page. They can access the same browser APIs and game state as the game itself. The manifest, dependency checks and path validation are not a sandbox. Only install mods from sources you trust. Do not use this system to run unknown code or secrets in the game process.

The `extras/mods` directory is external to the PyInstaller executable and can be edited without rebuilding the game.

## Réglages et tâches périodiques

Les réglages sont enregistrés séparément pour chaque mod. Ils peuvent être lus avec
`getSetting` ou `getSettings` et peuvent être créés depuis le script ou un callback :

```js
const speed = LaPlaineAPI.registerSetting({
  id: 'animation-speed', label: 'Vitesse des animations', type: 'slider',
  min: 0.5, max: 2, step: 0.1, defaultValue: 1
});

LaPlaineAPI.on('game:ready', ({ world }) => {
  const stop = LaPlaineAPI.registerTask('refresh-nearby', ({ delta }) => {
    // Rafraîchir les données du mod au plus quatre fois par seconde.
  }, 250);
});
```

`registerTask` partage la boucle de mise à jour du jeu et évite d'exécuter les
travaux périodiques à chaque image. La fonction renvoyée arrête la tâche.
`getSettings()` retourne les valeurs du mod courant ; `getSettings('mod-id')`
permet de demander les valeurs d'un autre mod.

L'événement `game:tick` contient `simulationActive`. Les tâches périodiques sont
suspendues automatiquement pendant la pause, dans l'inventaire et dans le chat.
Si un mod écoute directement `game:tick`, il peut ignorer le travail coûteux tant
que `simulationActive` vaut `false`.
