/* Performance Mode — La Plaine 0.2.8.0
 * Quatre profils appliqués à l’exécution, sans modifier les fichiers du jeu :
 *   Moche    : tout est affreux mais ça vole (FPS maximum)
 *   Faible   : rendu allégé
 *   Meilleur : réglages d’origine du jeu, rien n’est touché
 *   Ultra    : le plus beau (supersampling, distance accrue, eau animée, couleurs)
 * Le profil est mémorisé dans le navigateur. Les réglages du joueur (particules,
 * nuages, eau animée, distance de rendu du menu) ne sont jamais écrasés.
 */
(function () {
    'use strict';
    if (window.__laPlainePerformanceModeLoaded) return;
    window.__laPlainePerformanceModeLoaded = true;

    const STORAGE_KEY = 'laPlaine.performanceMode';
    const SETTING_ID = 'performance-mode.quality';
    const MAX_PIXELS = 3840 * 2160;   // plafond du supersampling (Ultra)
    const KIND_FLUID = 3;             // même valeur que dans world.js
    const BODY_CLASSES = ['lp-perf-moche', 'lp-perf-faible', 'lp-perf-meilleur', 'lp-perf-ultra'];

    // resolution   : échelle appliquée à la résolution choisie par le jeu
    // distance     : cap = maximum, bonus/max = ajout limité (par rapport au menu du jeu)
    // fog          : null = brouillard d’origine ; sinon far = max(minFar, R*farScale - farOffset)
    // water        : 'simple' | 'shader' | 'user' (= choix du joueur)
    // mobInterval  : secondes entre deux mises à jour des créatures (0 = chaque image)
    // fluidInterval: millisecondes minimum entre deux mises à jour des fluides (0 = jeu d’origine)
    // queueFactor  : budget de construction des chunks par image
    const MODES = [
        {
            name: 'Moche', css: 'moche',
            summary: 'Tout est affreux, mais ça vole : image minuscule et pixelisée, brouillard épais, rien ne bouge normalement.',
            details: 'Résolution ×0,4 pixelisée · distance ≤ 3 · brouillard épais · sans particules, nuages ni pluie · eau simple · créatures et fluides au ralenti',
            resolution: 0.4, distance: { cap: 3 },
            fog: { farScale: 0.7, farOffset: 0, minFar: 18, nearRatio: 0.08 },
            particles: false, particleFactor: 0, clouds: false, rain: false, water: 'simple',
            mobInterval: 0.1, fluidInterval: 900, queueFactor: 0.5
        },
        {
            name: 'Faible', css: 'faible',
            summary: 'Rendu allégé : résolution réduite, distance limitée et peu de particules.',
            details: 'Résolution ×0,7 · distance ≤ 5 · brouillard plus dense · particules réduites · eau simple',
            resolution: 0.7, distance: { cap: 5 },
            fog: { farScale: 1, farOffset: 4, minFar: 24, nearRatio: 0.35 },
            particles: true, particleFactor: 0.25, clouds: true, rain: true, water: 'simple',
            mobInterval: 0.05, fluidInterval: 600, queueFactor: 0.7
        },
        {
            name: 'Meilleur', css: 'meilleur',
            summary: 'Équilibré : les réglages d’origine du jeu, rien n’est modifié.',
            details: 'Résolution ×1 · distance du menu · brouillard d’origine · eau selon tes réglages',
            resolution: 1, distance: {}, fog: null,
            particles: true, particleFactor: 1, clouds: true, rain: true, water: 'user',
            mobInterval: 0, fluidInterval: 0, queueFactor: 1
        },
        {
            name: 'Ultra', css: 'ultra',
            summary: 'Le plus beau : bords lissés, vue plus lointaine, eau animée, couleurs plus vives et vignettage.',
            details: 'Supersampling ×1,5 · distance +2 · brouillard lointain et net · eau animée · couleurs vives · vignettage · particules renforcées',
            resolution: 1.5, distance: { bonus: 2, max: 16 },
            fog: { farScale: 1, farOffset: 2, minFar: 24, nearRatio: 0.62 },
            particles: true, particleFactor: 1.5, clouds: true, rain: true, water: 'shader',
            mobInterval: 0, fluidInterval: 0, queueFactor: 1.5
        }
    ];

    let modeIndex = 2;
    try {
        const saved = Number(localStorage.getItem(STORAGE_KEY));
        if (Number.isInteger(saved) && saved >= 0 && saved < MODES.length) modeIndex = saved;
    } catch (_) {}

    let runtime = null;
    let baseDistance = null;
    let rainMesh = null;
    let rainSearches = 0;
    let pauseSettingRegistered = false;

    function mode() { return MODES[modeIndex]; }
    function readStorage(key) { try { return localStorage.getItem(key); } catch (_) { return null; } }
    function safe(label, fn) {
        try { fn(); } catch (error) { console.warn(`[Performance Mode] ${label} indisponible.`, error); }
    }

    /* ---------- Style, classe du body, vignettage ---------- */

    function ensureStyle() {
        if (document.getElementById('lp-performance-mode-style')) return;
        const style = document.createElement('style');
        style.id = 'lp-performance-mode-style';
        style.textContent = `
            body.lp-perf-moche > canvas { image-rendering: crisp-edges; image-rendering: pixelated; }
            body.lp-perf-ultra > canvas { filter: saturate(1.1) contrast(1.05); }
            #lp-perf-vignette { position: fixed; inset: 0; z-index: 5; pointer-events: none; display: none;
                background: radial-gradient(ellipse at center, rgba(0,0,0,0) 58%, rgba(0,0,0,.30) 100%); }
            body.lp-perf-ultra #lp-perf-vignette { display: block; }
        `;
        (document.head || document.documentElement).appendChild(style);
    }

    function setBodyClass() {
        const body = document.body;
        if (!body) return;
        for (const name of BODY_CLASSES) body.classList.remove(name);
        body.classList.add('lp-perf-' + mode().css);
    }

    function ensureVignette() {
        if (!document.body || document.getElementById('lp-perf-vignette')) return;
        const vignette = document.createElement('div');
        vignette.id = 'lp-perf-vignette';
        document.body.appendChild(vignette);
    }

    /* ---------- Rendu : résolution relative à celle du jeu ---------- */

    function scaleFor(width, height) {
        const wanted = mode().resolution;
        if (wanted <= 1) return wanted;
        const cap = Math.sqrt(MAX_PIXELS / Math.max(1, width * height));
        return Math.max(1, Math.min(wanted, cap));
    }

    function installRenderer(renderer) {
        if (renderer.__lpPerfInstalled) return;
        const originalSetSize = renderer.setSize.bind(renderer);
        const originalRender = renderer.render.bind(renderer);
        // Le jeu choisit sa propre résolution (auto, 720p…) : on la multiplie, on ne la remplace pas.
        renderer.setSize = function (width, height, updateStyle) {
            const scale = scaleFor(width, height);
            return originalSetSize(Math.max(2, Math.round(width * scale)), Math.max(2, Math.round(height * scale)), updateStyle);
        };
        // Juste avant chaque dessin : évite qu’un changement de météo réaffiche un nuage ou la pluie une image.
        renderer.render = function (scene, camera) {
            enforceVisuals();
            return originalRender(scene, camera);
        };
        Object.defineProperty(renderer, '__lpPerfInstalled', { value: true });
    }

    /* ---------- Monde : distance, brouillard, cadence des simulations ---------- */

    function installWorld(world) {
        if (world.__lpPerfInstalled) return;

        if (typeof world.applyFog === 'function') {
            const originalApplyFog = world.applyFog.bind(world);
            world.applyFog = function () {
                originalApplyFog();
                const fog = mode().fog;
                if (!fog) return;
                const range = this.renderDistance * 16;
                this.fogFar = Math.max(fog.minFar, range * fog.farScale - fog.farOffset);
                this.fogNear = this.fogFar * fog.nearRatio;
                if (typeof this._syncFog === 'function') this._syncFog();
            };
        }

        if (typeof world.updateMobs === 'function') {
            const originalUpdateMobs = world.updateMobs;
            let elapsed = 0;
            world.updateMobs = function (delta, ...args) {
                const interval = mode().mobInterval;
                if (!interval) { elapsed = 0; return originalUpdateMobs.call(this, delta, ...args); }
                elapsed += Math.max(0, Number(delta) || 0);
                if (elapsed < interval) return;
                // Pas de grand saut de temps d’un coup : les créatures ne traversent pas le décor.
                const step = Math.min(elapsed, 0.1);
                elapsed = 0;
                return originalUpdateMobs.call(this, step, ...args);
            };
        }

        if (typeof world.updateFluids === 'function') {
            const originalUpdateFluids = world.updateFluids;
            let last = 0;
            // updateFluids reçoit un horodatage en millisecondes (et non un delta).
            world.updateFluids = function (time, ...args) {
                const interval = mode().fluidInterval;
                if (interval && time - last < interval) return;
                last = time;
                return originalUpdateFluids.call(this, time, ...args);
            };
        }

        if (typeof world.processQueue === 'function') {
            const originalProcessQueue = world.processQueue;
            world.processQueue = function (budget, ...args) {
                const base = budget === undefined ? 4 : Number(budget) || 1;
                return originalProcessQueue.call(this, Math.max(0.35, base * mode().queueFactor), ...args);
            };
        }

        Object.defineProperty(world, '__lpPerfInstalled', { value: true });
    }

    function targetDistance(base, rule) {
        let distance = base;
        if (rule.cap) distance = Math.min(base, rule.cap);
        if (rule.bonus) distance = Math.max(base, Math.min(base + rule.bonus, rule.max));
        return Math.max(1, Math.min(100, Math.round(distance)));
    }

    function applyDistance(refreshChunks) {
        const world = runtime.world;
        // La distance du menu du jeu reste la référence : on la mémorise une seule fois.
        if (baseDistance === null) baseDistance = Number(world.renderDistance) || 6;
        const distance = targetDistance(baseDistance, mode().distance);
        const changed = world.renderDistance !== distance;
        world.renderDistance = distance;
        if (typeof world.applyFog === 'function') world.applyFog();
        const position = runtime.player && runtime.player.position;
        if (changed && refreshChunks && position && typeof world.updateChunks === 'function') {
            world.updateChunks(position.x, position.z, true);
        }
    }

    function applyWater() {
        const world = runtime.world;
        const mats = world.mats;
        if (!mats || !mats.waterSimple || !mats.waterShader) return;
        const userWantsShader = Boolean(world.settings && world.settings.waterShader);
        const kind = mode().water;
        const useShader = kind === 'shader' || (kind === 'user' && userWantsShader);
        const target = useShader ? mats.waterShader : mats.waterSimple;
        mats.water = target;
        for (const chunk of world.chunks.values()) {
            if (!chunk.meshes) continue;
            for (const mesh of chunk.meshes) {
                if (mesh.userData && mesh.userData.kind === KIND_FLUID) mesh.material = target;
            }
        }
    }

    /* ---------- Particules ---------- */

    function applyParticles() {
        const particles = window.particleManager;
        if (!particles) return;
        if (!particles.__lpPerfSpawn) {
            const originalSpawn = particles.spawnBurst;
            particles.spawnBurst = function (pos, color, count, options) {
                const factor = mode().particleFactor;
                if (factor <= 0) return;
                const base = count === undefined ? 8 : Number(count) || 1;
                return originalSpawn.call(this, pos, color, Math.max(1, Math.round(base * factor)), options);
            };
            Object.defineProperty(particles, '__lpPerfSpawn', { value: true });
        }
        // On n’appelle pas setEnabled() : il écrirait dans les réglages du joueur.
        const userEnabled = readStorage('laPlaine.particlesEnabled') !== 'false';
        const enabled = userEnabled && mode().particles;
        particles.enabled = enabled;
        if (!enabled && Array.isArray(particles.active) && Array.isArray(particles.free)) {
            for (const particle of particles.active) { particle.mesh.visible = false; particles.free.push(particle); }
            particles.active.length = 0;
        }
    }

    /* ---------- Nuages et pluie ---------- */

    function findRain() {
        if (rainMesh || !runtime || !runtime.scene || rainSearches >= 20) return rainMesh;
        rainSearches++;
        const children = runtime.scene.children || [];
        rainMesh = children.find(o => o && o.isLineSegments && o.geometry && o.geometry.attributes &&
            o.geometry.attributes.position && o.geometry.attributes.position.count === 360) || null;
        return rainMesh;
    }

    function enforceVisuals() {
        if (!runtime) return;
        const current = mode();
        const world = runtime.world;
        if (!current.clouds && world && world.cloudMesh && world.cloudMesh.visible) world.cloudMesh.visible = false;
        if (!current.rain) {
            const rain = findRain();
            if (rain && rain.visible) rain.visible = false;
        }
    }

    function applyWeatherVisuals() {
        const current = mode();
        const world = runtime.world;
        if (current.clouds && world.cloudMesh) world.cloudMesh.visible = readStorage('showClouds') !== 'false';
        if (current.rain) {
            const rain = findRain();
            const label = document.getElementById('weather-indicator');
            if (rain && label) rain.visible = (label.textContent || '').includes('Pluie');
        }
        enforceVisuals();
    }

    /* ---------- Application d’un profil ---------- */

    function applyToGame(context) {
        if (!context || !context.renderer || !context.world) return;
        const first = !runtime;
        runtime = context;
        safe('style', () => { ensureStyle(); setBodyClass(); ensureVignette(); });
        safe('rendu', () => installRenderer(context.renderer));
        safe('monde', () => installWorld(context.world));
        safe('distance', () => applyDistance(!first));
        safe('eau', applyWater);
        safe('particules', applyParticles);
        safe('météo', applyWeatherVisuals);
        // Le jeu recalcule alors sa résolution (resolution automatique, shaders, caméra).
        safe('résolution', () => window.dispatchEvent(new Event('resize')));
        console.info(`[Performance Mode] Profil ${mode().name} appliqué.`);
    }

    function applyMode() {
        try { localStorage.setItem(STORAGE_KEY, String(modeIndex)); } catch (_) {}
        setBodyClass();
        if (runtime) applyToGame(runtime);
        window.dispatchEvent(new CustomEvent('laplaine:performance-mode-changed', {
            detail: { index: modeIndex, mode: mode().name }
        }));
    }

    /* ---------- Interface ---------- */

    function renderSettings(container) {
        const panel = document.createElement('div');
        panel.style.cssText = 'margin:14px 0;padding:16px;border:1px solid rgba(255,255,255,.14);border-radius:12px;background:rgba(0,0,0,.16);';

        const title = document.createElement('strong');
        title.textContent = 'Qualité graphique et performances';
        title.style.cssText = 'display:block;font-size:16px;margin-bottom:8px;';

        const value = document.createElement('div');
        value.style.cssText = 'font-size:22px;font-weight:800;text-align:center;margin:10px 0 4px;';

        const slider = document.createElement('input');
        slider.type = 'range';
        slider.min = '0'; slider.max = String(MODES.length - 1); slider.step = '1';
        slider.setAttribute('aria-label', 'Niveau de qualité graphique');
        slider.style.cssText = 'width:100%;accent-color:#79c95b;cursor:pointer;';

        const ticks = document.createElement('div');
        ticks.style.cssText = 'display:flex;justify-content:space-between;gap:6px;font-size:11px;opacity:.85;';
        for (const entry of MODES) {
            const tick = document.createElement('span');
            tick.textContent = entry.name;
            ticks.appendChild(tick);
        }

        const description = document.createElement('p');
        description.style.cssText = 'font-size:13px;line-height:1.5;opacity:.9;margin:12px 0 0;';

        const details = document.createElement('p');
        details.style.cssText = 'font-size:12px;line-height:1.5;opacity:.65;margin:6px 0 0;';

        const note = document.createElement('p');
        note.textContent = 'Le profil s’applique à la partie. En jeu, tu peux le changer depuis le menu pause (Qualité graphique).';
        note.style.cssText = 'font-size:11px;line-height:1.4;opacity:.5;margin:10px 0 0;';

        function refresh() {
            const current = mode();
            value.textContent = current.name;
            description.textContent = current.summary;
            details.textContent = current.details;
            slider.value = String(modeIndex);
        }
        slider.addEventListener('input', () => {
            modeIndex = Math.max(0, Math.min(MODES.length - 1, Number(slider.value) | 0));
            refresh();
            applyMode();
        });

        panel.append(title, value, slider, ticks, description, details, note);
        container.appendChild(panel);
        refresh();
    }

    // Dans la partie : un réglage dans le menu pause pour changer de profil en direct.
    function registerPauseSetting() {
        if (pauseSettingRegistered) return;
        if (!document.getElementById('pause-overlay') || document.getElementById('lp-mod-settings-container')) return;
        if (typeof window.LaPlaineAPI.registerSetting !== 'function') return;
        // Le réglage lit sa propre valeur sauvegardée : on la synchronise avec le profil actuel.
        try { localStorage.setItem('laPlaine.modSetting.' + SETTING_ID, String(modeIndex)); } catch (_) {}
        safe('réglage du menu pause', () => {
            window.LaPlaineAPI.registerSetting({
                id: SETTING_ID,
                label: 'Qualité graphique',
                type: 'select',
                defaultValue: String(modeIndex),
                options: MODES.map((entry, index) => ({ value: String(index), label: entry.name })),
                description: 'Moche = FPS maximum · Ultra = le plus beau',
                onChange(value) {
                    const index = Number(value);
                    if (!Number.isInteger(index) || index < 0 || index >= MODES.length || index === modeIndex) return;
                    modeIndex = index;
                    applyMode();
                }
            });
            pauseSettingRegistered = true;
        });
    }

    if (!window.LaPlaineAPI || typeof window.LaPlaineAPI.registerMenuCategory !== 'function') {
        console.error('[Performance Mode] API de menu indisponible.');
        return;
    }

    safe('catégorie de menu', () => {
        window.LaPlaineAPI.registerMenuCategory({
            id: 'performance-mode',
            title: 'Performances',
            description: 'Moche pour les FPS, Ultra pour la beauté : choisis ton profil',
            render: renderSettings
        });
    });

    window.LaPlaineAPI.on('game:ready', context => {
        applyToGame(context);
        registerPauseSetting();
    });
    window.LaPlaineAPI.on('game:tick', enforceVisuals);

    setBodyClass();
    if (!document.body) document.addEventListener('DOMContentLoaded', setBodyClass, { once: true });
    console.info('[Performance Mode] Mod chargé.');
})();