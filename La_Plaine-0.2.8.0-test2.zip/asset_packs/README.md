Dépose ici les fichiers ZIP de tes packs d'assets. Chaque archive doit contenir un manifest.json à sa racine. Voir extras/asset_packs/README.md pour le format du manifeste.
