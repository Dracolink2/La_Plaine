# Interfaces indépendantes des blocs

Placez ici les fichiers HTML déclarés par la propriété `UI` d’un bloc. Chaque fichier peut contenir son propre HTML, CSS et JavaScript. Le jeu le charge via `/api/block-ui/<fichier>` dans une couche indépendante. `Escape` ou un clic sur le fond ferme l’interface.
