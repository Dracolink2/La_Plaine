class ParticleManager {
    constructor(scene, world) {
        this.scene = scene;
        this.world = world || null;
        this.geometry = new THREE.BoxGeometry(0.10, 0.10, 0.10);
        this.materials = new Map();
        this.free = [];
        this.active = [];
        this.MAX = 120;
        this.spriteMax = 96;
        this.spriteFree = [];
        this.spriteActive = [];
        this.spriteMaterials = new Map();
        this.spriteTextures = new Map();
        this.spriteLoader = new THREE.TextureLoader();
        this.enabled = this.readEnabled();
        for (let i = 0; i < this.spriteMax; i++) {
            const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ color: 0xffffff, transparent: true, opacity: 0, depthWrite: false }));
            sprite.visible = false; sprite.frustumCulled = true; scene.add(sprite);
            this.spriteFree.push({ mesh: sprite, vx: 0, vy: 0, vz: 0, life: 0, maxLife: 1, drag: 0.98, gravity: 12, spin: 0 });
        }
        for (let i = 0; i < this.spriteMax; i++) {
            const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ color: 0xffffff, transparent: true, opacity: 0, depthWrite: false }));
            sprite.visible = false; sprite.frustumCulled = true; scene.add(sprite);
            this.spriteFree.push({ mesh: sprite, vx: 0, vy: 0, vz: 0, life: 0, maxLife: 1, drag: 0.98, gravity: 12, spin: 0 });
        }
        for (let i = 0; i < this.MAX; i++) {
            const mesh = new THREE.Mesh(this.geometry, this.getMaterial(0x888888));
            mesh.visible = false;
            mesh.frustumCulled = true;
            scene.add(mesh);
            this.free.push({ mesh, vx: 0, vy: 0, vz: 0, life: 0, maxLife: 1, drag: 0.98 });
        }
    }
    readEnabled() {
        try { return localStorage.getItem('laPlaine.particlesEnabled') !== 'false'; }
        catch (_) { return true; }
    }
    setEnabled(enabled) {
        this.enabled = !!enabled;
        try { localStorage.setItem('laPlaine.particlesEnabled', String(this.enabled)); } catch (_) {}
        if (!this.enabled) {
            for (const p of this.active) { p.mesh.visible = false; this.free.push(p); }
            this.active.length = 0;
            for (const p of this.spriteActive) { p.mesh.visible = false; this.spriteFree.push(p); }
            this.spriteActive.length = 0;
            for (const p of this.spriteActive) { p.mesh.visible = false; this.spriteFree.push(p); }
            this.spriteActive.length = 0;
        }
    }
    getMaterial(color) {
        if (!this.materials.has(color)) this.materials.set(color, new THREE.MeshLambertMaterial({ color, transparent: true, opacity: 0.95 }));
        return this.materials.get(color);
    }
    spawnBurst(pos, color = 0xb7a58a, count = 8, options = {}) {
        if (!this.enabled || !pos || !Number.isFinite(pos.x) || !Number.isFinite(pos.y) || !Number.isFinite(pos.z)) return;
        const material = this.getMaterial(color);
        const amount = Math.min(count, this.free.length);
        for (let i = 0; i < amount; i++) {
            const p = this.free.pop();
            p.mesh.material = material;
            p.mesh.visible = true;
            p.mesh.scale.setScalar(0.55 + Math.random() * 0.8);
            p.mesh.position.set(pos.x + (Math.random() - .5) * (options.spread || .35), pos.y + (Math.random() - .5) * (options.spread || .35), pos.z + (Math.random() - .5) * (options.spread || .35));
            p.vx = (Math.random() - .5) * (options.speed || 2.8);
            p.vy = Math.random() * (options.up || 2.5) + .25;
            p.vz = (Math.random() - .5) * (options.speed || 2.8);
            p.life = p.maxLife = options.life || (0.25 + Math.random() * .35);
            p.drag = options.drag || 0.98;
            this.active.push(p);
        }
    }
    getSpriteMaterial(name) {
        if (this.spriteMaterials.has(name)) return this.spriteMaterials.get(name);
        let texture = this.spriteTextures.get(name);
        if (!texture) {
            const textures = {
                stone1: '/static/assets/textures/particles/after-breaking/stone1.png',
                stone2: '/static/assets/textures/particles/after-breaking/stone2.png',
                stone3: '/static/assets/textures/particles/after-breaking/stone3.png',
                sparks: '/static/assets/textures/particles/others/sparks.png',
                poussiere: '/static/assets/textures/particles/others/poussiere.png',
                leaf_fall: '/static/assets/textures/particles/leaves/leaf_fall.png',
                leaf_fall_automne: '/static/assets/textures/particles/leaves/leaf_fall_automne.png',
                leaf_fall_pine: '/static/assets/textures/particles/leaves/leaf_fall_pine.png',
                leaf_fall_accacia: '/static/assets/textures/particles/leaves/leaf_fall_accacia.png',
                leaf_fall_dark: '/static/assets/textures/particles/leaves/leaf_fall_dark.png',
                lava_splash: '/static/assets/textures/particles/lava/lava_splash.png',
                water_splash: '/static/assets/textures/particles/water/water_splash.png',
                cassage: '/static/assets/textures/particles/breaking/cassage.gif'
            };
            texture = this.spriteLoader.load(textures[name] || `/static/assets/textures/particles/${name}.png`);
            texture.magFilter = THREE.NearestFilter; texture.minFilter = THREE.NearestFilter;
            texture.generateMipmaps = false; this.spriteTextures.set(name, texture);
        }
        const material = new THREE.SpriteMaterial({ map: texture, transparent: true, alphaTest: 0.04, depthWrite: false, color: 0xffffff });
        this.spriteMaterials.set(name, material);
        return material;
    }
    spawnTextured(name, pos, count = 1, options = {}) {
        if (!this.enabled || !pos || !this.spriteFree.length) return;
        const material = this.getSpriteMaterial(name);
        for (let i = 0; i < Math.min(count, this.spriteFree.length); i++) {
            const p = this.spriteFree.pop(); if (p._baseMaterial !== material) { p.mesh.material?.dispose?.(); p.mesh.material = material.clone(); p._baseMaterial = material; } p.mesh.visible = true; p.mesh.material.opacity = 1; p.mesh.material.rotation = 0;
            const spread = options.spread ?? 0.35;
            p.mesh.position.set(pos.x + (Math.random()-.5)*spread, pos.y + (Math.random()-.5)*spread, pos.z + (Math.random()-.5)*spread);
            const size = options.size ?? 0.18; p.baseScale = size * (0.7 + Math.random()*.6); p.mesh.scale.set(p.baseScale,p.baseScale,1);
            p.vx = (Math.random()-.5) * (options.speed ?? 1.5); p.vy = options.up ?? (0.3 + Math.random()*.7); p.vz = (Math.random()-.5) * (options.speed ?? 1.5);
            p.life = p.maxLife = options.life ?? (0.35 + Math.random()*.25); p.drag = options.drag ?? 0.97; p.gravity = options.gravity ?? 12; p.spin = (Math.random()-.5) * (options.spin ?? 2);
            this.spriteActive.push(p);
        }
    }
    spawnBlockBreakParticles(pos, blockId) {
        const center = { x: pos.x + .5, y: pos.y + .5, z: pos.z + .5 };
        const color = this.world?.getBlockColor ? this.world.getBlockColor(blockId) : 0x888888;
        this.spawnBurst(center, color, 7, { spread: .65, speed: 3.6, up: 2.4, life: .38 });
        this.spawnTextured('cassage', center, 1, { size: 0.9, spread: 0, up: 0, speed: 0, life: 0.18, gravity: 0 });
        if ([1,17,37,38,40,55,56,57,70,71,72,73].includes(blockId)) {
            this.spawnTextured(`stone${1 + Math.floor(Math.random()*3)}`, center, 2, { size: .13, spread: .55, speed: 2.8, up: 1.8, life: .42 });
        }
    }
    spawnOreSparks(pos) { this.spawnTextured('sparks', {x:pos.x+.5,y:pos.y+.5,z:pos.z+.5}, 5, {size:.32,spread:.35,speed:2.8,up:2.8,life:.32,gravity:7,spin:5}); }
    spawnDust(pos) { this.spawnTextured('poussiere', pos, 1, {size:.12,spread:.2,speed:.22,up:.16,life:1.1,gravity:0.15,drag:.995}); }
    spawnFallingLeaf(pos, texture = 'leaf_fall') { this.spawnTextured(texture, pos, 1, {size:.17,spread:.25,speed:.22,up:-.15,life:2.8,gravity:0.45,drag:.995,spin:3}); }
    spawnFluidSplash(pos, lava = false) { this.spawnTextured(lava ? 'lava_splash' : 'water_splash', pos, 3, {size:.20,spread:.5,speed:1.8,up:1.3,life:.4,gravity:8}); }

    spawnBlockPlaceParticles(pos, blockId) {
        const color = this.world?.getBlockColor ? this.world.getBlockColor(blockId) : 0x9a9a9a;
        this.spawnBurst({ x: pos.x + .5, y: pos.y + .5, z: pos.z + .5 }, color, 5, { spread: .42, speed: 1.4, up: .8, life: .2 });
    }
    spawnEntityHitParticles(pos, color = 0xb84c42) {
        this.spawnBurst(pos, color, 7, { spread: .32, speed: 2.1, up: 1.4, life: .28 });
    }
    spawnEntityDeathParticles(pos, color = 0xc4b08a) {
        this.spawnBurst(pos, color, 15, { spread: .8, speed: 2.8, up: 2.1, life: .55 });
    }
    spawnStepParticles(pos, color = 0x9c927d) {
        this.spawnBurst(pos, color, 2, { spread: .18, speed: .65, up: .25, life: .18 });
    }
    update(delta) {
        if (!this.enabled) return;
        const gravity = 12;
        for (let i = this.spriteActive.length - 1; i >= 0; i--) {
            const p = this.spriteActive[i]; p.life -= delta;
            if (p.life <= 0) { p.mesh.visible = false; this.spriteActive[i] = this.spriteActive[this.spriteActive.length-1]; this.spriteActive.pop(); this.spriteFree.push(p); continue; }
            p.vy -= p.gravity * delta; const drag = Math.pow(p.drag, delta*60); p.vx*=drag; p.vz*=drag;
            p.mesh.position.x += p.vx*delta; p.mesh.position.y += p.vy*delta; p.mesh.position.z += p.vz*delta; p.mesh.material.opacity = Math.min(1, p.life / p.maxLife * 1.4); p.mesh.material.rotation += p.spin*delta;
            const fade = Math.max(.08, p.life/p.maxLife); p.mesh.scale.set(p.baseScale*fade,p.baseScale*fade,1);
        }
        for (let i = this.active.length - 1; i >= 0; i--) {
            const p = this.active[i]; p.life -= delta;
            if (p.life <= 0) {
                p.mesh.visible = false; this.active[i] = this.active[this.active.length - 1]; this.active.pop(); this.free.push(p); continue;
            }
            p.vy -= gravity * delta;
            const drag = Math.pow(p.drag, delta * 60);
            p.vx *= drag; p.vz *= drag;
            p.mesh.position.x += p.vx * delta; p.mesh.position.y += p.vy * delta; p.mesh.position.z += p.vz * delta;
            const t = p.life / p.maxLife;
            p.mesh.scale.setScalar(Math.max(.015, t) * .8);
        }
    }
}
window.ParticleManager = ParticleManager;
