(function () {
    const loadingText = document.getElementById('loading-text');
    const setStatus = (t) => { if (loadingText) loadingText.textContent = t; };

    main().catch((err) => {
        console.error(err);
        setStatus('Erreur : ' + (err && err.message ? err.message : err) + ' (voir la console)');
    });

    async function main() {
        
        const params = new URLSearchParams(window.location.search);
        const worldId = params.get('world');
        if (!worldId) { window.location.href = '/'; return; }

        const worldResponse = await fetch(`/api/worlds/${encodeURIComponent(worldId)}`);
        if (!worldResponse.ok) {
            window.location.href = '/';
            return;
        }

        const worldPayload = await worldResponse.json();
        const worldInfo = worldPayload.world || worldPayload;
        if (!Number.isInteger(Number(worldInfo.id)) || !worldInfo.seed) {
            throw new Error("Réponse du monde invalide : identifiant ou seed manquant.");
        }

        const worldKey = encodeURIComponent(worldInfo.id);
        const [changesResponse, playerResponse, stateResponse, chunksResponse] = await Promise.all([
            fetch(`/api/worlds/${worldKey}/changes`),
            fetch(`/api/worlds/${worldKey}/player`),
            fetch(`/api/worlds/${worldKey}/state`),
            fetch(`/api/worlds/${worldKey}/generated-chunks`)
        ]);
        if (!changesResponse.ok) throw new Error('Impossible de charger les modifications du monde.');
        if (!playerResponse.ok) throw new Error('Impossible de charger l’état du joueur.');
        if (!stateResponse.ok) throw new Error('Impossible de charger l’état du monde.');
        if (!chunksResponse.ok) throw new Error('Impossible de charger les chunks générés.');

        const changesInfo = await changesResponse.json();
        const playerInfo = await playerResponse.json();
        const worldStateInfo = await stateResponse.json();
        const generatedChunksInfo = await chunksResponse.json();

        
        const scene = new THREE.Scene();
        const playerAmbientLight = new THREE.HemisphereLight(0xffffff, 0x777788, 1.65);
        playerAmbientLight.name = 'player-ambient-light';
        scene.add(playerAmbientLight);
        const playerSunLight = new THREE.DirectionalLight(0xffffff, 1.4);
        playerSunLight.name = 'player-directional-light';
        playerSunLight.position.set(-30, 70, 40);
        scene.add(playerSunLight);
        scene.background = new THREE.Color(0x87ceeb);
        scene.fog = new THREE.Fog(0x87ceeb, 20, 44);

        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 2200);
        const renderer = new THREE.WebGLRenderer({
            antialias: false,
            alpha: false,
            stencil: false,
            powerPreference: 'high-performance',
            precision: 'mediump',
            preserveDrawingBuffer: false
        });
        renderer.setPixelRatio(1);
        renderer.outputColorSpace = THREE.SRGBColorSpace || renderer.outputColorSpace;
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.08;
        renderer.sortObjects = true;
        const canvas = renderer.domElement;
        canvas.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;display:block;z-index:0;';
        document.body.appendChild(canvas);

        const shaderPackRenderer = window.ShaderPackRenderer ? new window.ShaderPackRenderer(renderer) : null;
        if (shaderPackRenderer) {
            const activeShader = localStorage.getItem('laPlaine.activeShader') || 'off';
            if (activeShader !== 'off') shaderPackRenderer.setActive(activeShader).catch(error => console.warn('[La Plaine] Shader désactivé :', error));
        }

        
        const qualitySetting = localStorage.getItem('graphicsQuality') || 'medium';
        const qualityScale = { low: 0.68, medium: 0.88, high: 1.0 }[qualitySetting] || 0.88;
        let autoScale = qualityScale;
        function applyResolution() {
            const setting = localStorage.getItem('gameResolution') || 'auto';
            const resolutionScale = Math.max(0.5, Math.min(1.5, (Number(localStorage.getItem('resolutionScale')) || 100) / 100));
            const fixed = { '480p': 480, '720p': 720, '1080p': 1080, '2k': 1440, '4k': 2160 }[setting];
            const h = Math.max(2, Math.round((fixed || window.innerHeight * autoScale) * resolutionScale));
            const w = Math.max(2, Math.round(h * (window.innerWidth / window.innerHeight)));
            renderer.setSize(w, h, false);
            if (shaderPackRenderer) shaderPackRenderer.resize();
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
        }
        applyResolution();
        window.addEventListener('resize', applyResolution);

        
        const waterOverlay = document.createElement('div');
        waterOverlay.style.cssText = 'position:fixed;inset:0;background:rgba(20,80,170,0.32);pointer-events:none;display:none;z-index:12;';
        document.body.appendChild(waterOverlay);

        const weatherLabel = document.createElement('div');
        weatherLabel.id = 'weather-indicator';
        weatherLabel.style.cssText = 'position:fixed;top:12px;right:14px;padding:5px 9px;border-radius:6px;background:rgba(0,0,0,.35);color:#fff;font:13px sans-serif;text-shadow:0 1px 2px #000;pointer-events:none;z-index:8;';
        document.body.appendChild(weatherLabel);
        const rainCount = 180;
        const rainPositions = new Float32Array(rainCount * 2 * 3);
        const rainGeometry = new THREE.BufferGeometry();
        rainGeometry.setAttribute('position', new THREE.BufferAttribute(rainPositions, 3));
        const rainMaterial = new THREE.LineBasicMaterial({ color: 0xb8d7ef, transparent: true, opacity: 0.55 });
        const rainMesh = new THREE.LineSegments(rainGeometry, rainMaterial);
        rainMesh.frustumCulled = false;
        rainMesh.visible = false;
        scene.add(rainMesh);
        let world = null;
        let weatherType = 'rain';
        let weatherTimer = 0;
        let nextWeatherChange = 85 + Math.random() * 80;
        function setWeather(type) {
            weatherType = type;
            rainMesh.visible = type === 'rain';
            weatherLabel.textContent = type === 'rain' ? '' : '';
            weatherLabel.style.background = type === 'rain' ? 'rgba(18,25,38,.82)' : 'rgba(0,0,0,.35)';
            if (world && world.cloudMat) {
                world.cloudMat.color.set(type === 'rain' ? 0x252a35 : 0xffffff);
                world.cloudMat.opacity = type === 'rain' ? 0.97 : 0.85;
                world.cloudMat.needsUpdate = true;
            }
            if (world && world.cloudMesh) world.cloudMesh.visible = localStorage.getItem('showClouds') !== 'false';
            scene.background = new THREE.Color(type === 'rain' ? 0x3d4654 : 0x87ceeb);
            if (scene.fog) scene.fog.color.set(type === 'rain' ? 0x3d4654 : 0x87ceeb);
            playerAmbientLight.intensity = type === 'rain' ? 0.9 : 1.35;
            playerSunLight.intensity = type === 'rain' ? 0.45 : 1.15;
        }
        function updateWeather(delta) {
            weatherTimer += delta;
            if (weatherTimer >= nextWeatherChange) {
                weatherTimer = 0;
                setWeather(weatherType === 'sun' ? 'rain' : 'sun');
                nextWeatherChange = weatherType === 'rain' ? 35 + Math.random() * 35 : 85 + Math.random() * 100;
            }
            if (weatherType !== 'rain') return;
            const p = player.position;
            for (let i = 0; i < rainCount; i++) {
                const j = i * 6;
                const x = p.x + (Math.random() - 0.5) * 30;
                const z = p.z + (Math.random() - 0.5) * 30;
                const y = p.y + 3 + Math.random() * 13;
                rainPositions[j] = x; rainPositions[j + 1] = y; rainPositions[j + 2] = z;
                rainPositions[j + 3] = x - 0.12; rainPositions[j + 4] = y - 0.75; rainPositions[j + 5] = z - 0.04;
            }
            rainGeometry.attributes.position.needsUpdate = true;
            rainGeometry.computeBoundingSphere();
        }
        setWeather('rain');

        
        setStatus('Chargement des textures...');
        world = new World(scene, {
            worldId: Number(worldInfo.id),
            seed: worldInfo.seed,
            dimensionId: 'overworld',
            worldOptions: worldInfo.options || {}
        });
        setWeather(weatherType);

        world.loadPersistedChanges(changesInfo.changes || []);
        world.loadPlayerStates(playerInfo.states || []);
        world.loadGeneratedChunks(generatedChunksInfo.chunks || []);
        world.loadWorldState(worldStateInfo.state || null);

        const initialDimensionId = world.currentDimensionId || 'overworld';
        if (window.dimensionRegistry) window.dimensionRegistry.setInitialDimension(world, initialDimensionId);
        await world.init(setStatus);
        window.LaPlaineAPI?.emit('world:ready', { world });
        window.LaPlaineAPI?.emit('world:loaded', { world });

        const particleManager = new ParticleManager(scene, world);
        window.particleManager = particleManager;
        const player = new Player(camera, document.body, world);
        if (player.inventory && typeof player.inventory.updateUI === 'function') player.inventory.updateUI();
        const inventoryUI = new InventoryUI(player);
        window.LaPlaineAPI?.emit('game:ready', { world, player, scene, camera, renderer });
        window.addEventListener('pagehide', () => { window.LaPlaineAPI?.emit('world:unloaded', { world }); window.LaPlaineLifecycle?.dispose?.({ world, player }); }, { once: true });

        const loadingOverlay = document.getElementById('loading-overlay');
        const clickOverlay = document.getElementById('click-overlay');
        const pauseOverlay = document.getElementById('pause-overlay');
        const btnStart = document.getElementById('btn-start');
        const btnResume = document.getElementById('btn-resume');
        const btnRespawn = document.getElementById('btn-respawn');
        const cloudToggleGame = document.getElementById('cloud-toggle-game');

        
        const chatContainer = document.createElement('div');
        chatContainer.style.cssText = `
            position: fixed;
            bottom: 20px;
            left: 20px;
            width: 380px;
            max-height: 250px;
            display: flex;
            flex-direction: column;
            z-index: 20;
            font-family: monospace;
            font-size: 14px;
            pointer-events: none;
        `;

        const chatLogs = document.createElement('div');
        chatLogs.style.cssText = `
            flex: 1;
            overflow-y: auto;
            background: rgba(0, 0, 0, 0.4);
            color: #fff;
            padding: 8px;
            border-radius: 4px;
            margin-bottom: 5px;
            text-shadow: 1px 1px 2px #000;
            display: flex;
            flex-direction: column;
            gap: 4px;
        `;

        const chatInput = document.createElement('input');
        chatInput.type = 'text';
        chatInput.placeholder = 'Ex. GIVE 1201 (Entrée pour exécuter)';
        chatInput.style.cssText = `
            width: 100%;
            padding: 8px;
            background: rgba(0, 0, 0, 0.7);
            border: 1px solid rgba(255, 255, 255, 0.4);
            color: #fff;
            border-radius: 4px;
            outline: none;
            display: none;
            pointer-events: auto;
            box-sizing: border-box;
        `;

        chatContainer.appendChild(chatLogs);
        chatContainer.appendChild(chatInput);
        document.body.appendChild(chatContainer);

        let isChatOpen = false;

        function addChatMessage(msg, color = '#ffffff') {
            const line = document.createElement('div');
            line.style.color = color;
            line.textContent = msg;
            chatLogs.appendChild(line);
            chatLogs.scrollTop = chatLogs.scrollHeight;
        }

        function openChat() {
            if (isChatOpen) return;
            isChatOpen = true;
            chatInput.style.display = 'block';
            chatInput.focus();
            if (player.controls?.isLocked) {
                window.dispatchEvent(new CustomEvent('laplaine:controls-unlock-intent', { detail: { reason: 'chat' } }));
                player.controls.unlock();
            }
        }

        function closeChat() {
            if (!isChatOpen) return;
            isChatOpen = false;
            chatInput.value = '';
            chatInput.style.display = 'none';
            if (player.controls) player.controls.lock();
        }

        function executeCommand(cmdText) {
            const trimmed = cmdText.trim();
            if (!trimmed) return;

            addChatMessage('> ' + trimmed, '#aaaaaa');

            const lower = trimmed.toLowerCase();
            const giveMatch = trimmed.match(/^give\s+(\d+)(?:\s+(\d+))?$/i);
            if (giveMatch) {
                const itemId = Number(giveMatch[1]);
                const count = giveMatch[2] ? Number(giveMatch[2]) : 1;
                const item = Number.isSafeInteger(itemId) ? window.itemsRegistry?.get(itemId) : null;
                if (!item) {
                    addChatMessage(`Aucun objet trouvé pour l'ID ${giveMatch[1]}.`, '#ff5555');
                    return;
                }
                if (!Number.isSafeInteger(count) || count < 1 || count > 1000) {
                    addChatMessage('Usage : GIVE <ID> [quantité de 1 à 1000].', '#ffaa00');
                    return;
                }
                const remaining = player.inventory.addItem(itemId, count);
                const given = count - remaining;
                if (given > 0) addChatMessage(`${item.name} ×${given} ajouté à l'inventaire.`, '#55ff55');
                if (remaining > 0) addChatMessage(`Inventaire plein : ${remaining} objet(s) non ajouté(s).`, '#ffaa00');
                return;
            }

            if (lower === 'list biomes') {
                let biomes = [];
                if (typeof biomeRegistry !== 'undefined' && biomeRegistry) {
                    biomes = Object.keys(biomeRegistry);
                } else if (world.biomeRegistry) {
                    biomes = Object.keys(world.biomeRegistry);
                } else if (world.biomes) {
                    biomes = Object.keys(world.biomes);
                }

                if (biomes.length > 0) {
                    addChatMessage('Biomes disponibles : ' + biomes.join(', '), '#55ff55');
                } else {
                    addChatMessage('Aucun biome répertorié ou registre indisponible.', '#ff5555');
                }
                return;
            }

            
            if (lower.startsWith('tp biome ')) {
                const targetBiomeName = trimmed.substring(9).trim();
                if (!targetBiomeName) {
                    addChatMessage('Usage: TP biome <nom_du_biome>', '#ffaa00');
                    return;
                }

                addChatMessage(`Recherche du biome "${targetBiomeName}"...`, '#ffff55');

                
                let found = false;
                const startX = Math.floor(player.position.x);
                const startZ = Math.floor(player.position.z);
                const step = 32;
                const maxRadius = 3000;

                for (let r = step; r <= maxRadius; r += step) {
                    for (let dx = -r; dx <= r; dx += step) {
                        for (let dz = -r; dz <= r; dz += step) {
                            if (Math.abs(dx) !== r && Math.abs(dz) !== r) continue;

                            const testX = startX + dx;
                            const testZ = startZ + dz;
                            const biomeAtPos = world.biomeRegistry?.getBiomeAt?.(testX, testZ, world.perlin) || null;
                            const biomeName = (typeof biomeAtPos === 'string' ? biomeAtPos : (biomeAtPos && biomeAtPos.name)) || '';

                            if (biomeName.toLowerCase() === targetBiomeName.toLowerCase()) {
                                
                                let surfaceY = 64;
                                if (typeof world.getTerrainHeight === 'function') {
                                    surfaceY = world.getTerrainHeight(testX, testZ);
                                } else if (typeof world.getGroundHeight === 'function') {
                                    surfaceY = world.getGroundHeight(testX, testZ);
                                }

                                player.position.set(testX + 0.5, surfaceY + 2, testZ + 0.5);
                                player.velocity.set(0, 0, 0);
                                world.updateChunks(testX, testZ, true);

                                addChatMessage(`Téléporté au biome "${targetBiomeName}" en [${testX}, ${surfaceY + 2}, ${testZ}]`, '#55ff55');
                                found = true;
                                break;
                            }
                        }
                        if (found) break;
                    }
                    if (found) break;
                }

                if (!found) {
                    addChatMessage(`Biome "${targetBiomeName}" introuvable dans un rayon de ${maxRadius} blocs.`, '#ff5555');
                }
                return;
            }

            addChatMessage('Commande inconnue. Essayez GIVE <ID> [quantité], "list biomes" ou "TP biome <nom>".', '#ff5555');
        }

        window.addEventListener('keydown', (e) => {
            if (e.key === 't' || e.key === 'T') {
                if (!isChatOpen && player.controls && player.controls.isLocked) {
                    e.preventDefault();
                    openChat();
                }
            } else if (e.key === 'Enter') {
                if (isChatOpen) {
                    executeCommand(chatInput.value);
                    closeChat();
                }
            } else if (e.key === 'Escape') {
                if (isChatOpen) {
                    closeChat();
                }
            }
        });

        
        const preRadius = Math.min(world.renderDistance, 2);
        const savedPlayer = world.getSavedPlayerState(initialDimensionId);
        let preloadX = 0, preloadZ = 0;
        if (savedPlayer) {
            preloadX = Number(savedPlayer.x) || 0;
            preloadZ = Number(savedPlayer.z) || 0;
        } else if (initialDimensionId === 'overworld') {
            const spawnOrigin = world.findBiomeSpawnOrigin();
            preloadX = spawnOrigin.x;
            preloadZ = spawnOrigin.z;
        } else {
            const dim = window.dimensionRegistry?.get(initialDimensionId);
            if (dim) { preloadX = dim.offsetX; preloadZ = dim.offsetZ; }
        }
        world.spawnOrigin = { x: preloadX, z: preloadZ };
        await world.preload(Math.floor(preloadX / 16), Math.floor(preloadZ / 16), preRadius, (p) => setStatus('Génération du terrain... ' + Math.round(p * 100) + '%'));

        if (savedPlayer) {
            player.restoreState(savedPlayer);
        } else {
            const spawn = world.findSpawn(preRadius * 16 - 4, preloadX, preloadZ);
            player.position.set(spawn.x, spawn.y + 0.18, spawn.z);
            player.velocity.set(0, 0, 0);
            // Reset both PointerLockControls pivots: a previous
            // camera rotation must never offset the respawn position sideways.
            const yawObject = player.controls?.getObject?.();
            if (yawObject) { yawObject.rotation.order = 'YXZ'; yawObject.rotation.set(0, 0, 0); yawObject.position.set(spawn.x, spawn.y + player.eyeHeight + 0.18, spawn.z); }
            camera.rotation.order = 'YXZ'; camera.rotation.set(0, 0, 0); camera.position.set(0, 0, 0);
            player.cameraMode = 0; player.ridingHorse = null;
            player.fallPeakY = player.position.y;
        }

        player.isReady = true;
        player.updateCameraPosition();
        world.updateChunks(player.position.x, player.position.z, true);

        
        
        world.onDimensionChanged = (dimensionId) => {
            const state = world.getSavedPlayerState(dimensionId);
            if (!state) return;
            player.restoreState(state, { full: false });
            world.updateChunks(player.position.x, player.position.z, true);
        };

        async function savePlayerState() {
            if (!world.worldId || !player.isReady) return;
            const dimension = world.currentDimensionId || 'overworld';
            const payload = {
                dimension,
                ...player.serializeState(),
                skin: localStorage.getItem('laPlaine.selectedSkin') || 'Paul1.png'
            };

            world.savedPlayerStates.set(dimension, payload);

            try {
                const response = await fetch(`/api/worlds/${encodeURIComponent(world.worldId)}/player`, {
                    method: 'PUT',
                    keepalive: true,
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                if (!response.ok) throw new Error(`HTTP ${response.status}`);
            } catch (error) {
                console.warn('Sauvegarde de la position impossible :', error);
            }
        }

        
        window.addEventListener('inventory-changed', () => { savePlayerState(); });
        window.addEventListener('health-changed', () => { savePlayerState(); });

        const saveEverything = () => {
            savePlayerState();
            world.flushChanges();
            world.flushGeneratedChunks();
            world.saveWorldState();
        };

        setInterval(() => {
            world.flushChanges();
            world.flushGeneratedChunks();
        }, 3000);
        setInterval(() => {
            savePlayerState();
            world.saveWorldState();
        }, 5000);

        window.addEventListener('pagehide', saveEverything);
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'hidden') saveEverything();
        });

        if (btnRespawn) btnRespawn.addEventListener('click', () => {
            const spawnOrigin = world.spawnOrigin || { x: 0, z: 0 };
            const spawn = world.findSpawn(Math.min(world.renderDistance * 16, 48), spawnOrigin.x, spawnOrigin.z);
            world.updateChunks(spawn.x, spawn.z, true);
            player.resetAfterRespawn(spawn);
            const overlay = document.getElementById('death-overlay');
            if (overlay) overlay.style.display = 'none';
            world.updateChunks(player.position.x, player.position.z, true);
            savePlayerState();
        });

        let isWorldLoading = false;
        if (loadingOverlay) loadingOverlay.style.display = 'none';
        if (clickOverlay) clickOverlay.style.display = 'flex';

        
        if (cloudToggleGame) {
            cloudToggleGame.checked = localStorage.getItem('showClouds') !== 'false';
            cloudToggleGame.addEventListener('change', (e) => {
                world.setCloudsVisible(e.target.checked);
                localStorage.setItem('showClouds', e.target.checked);
            });
        }

        const startGame = () => {
            if (window.soundManager && typeof window.soundManager.init === 'function') window.soundManager.init();
            if (player.controls) player.controls.lock();
        };
        if (btnStart) btnStart.addEventListener('click', startGame);
        if (btnResume) btnResume.addEventListener('click', startGame);

        let mouseHeld = -1;
        let pendingUiUnlockReason = null;
        window.addEventListener('laplaine:controls-unlock-intent', (event) => {
            const reason = event.detail?.reason;
            if (['inventory', 'crafting', 'furnace', 'block-ui', 'chat', 'death'].includes(reason)) {
                pendingUiUnlockReason = reason;
            }
        });
        if (player.controls) {
            player.controls.addEventListener('lock', () => {
                if (clickOverlay) clickOverlay.style.display = 'none';
                if (pauseOverlay) pauseOverlay.style.display = 'none';
            });
            player.controls.addEventListener('unlock', () => {
                mouseHeld = -1;
                const uiOpen = player.inventory.isOpen || isChatOpen || inventoryUI.isBlockInterfaceOpen();
                const expectedUiUnlock = pendingUiUnlockReason !== null;
                pendingUiUnlockReason = null;
                if (pauseOverlay && !player.dead && !uiOpen && !expectedUiUnlock) pauseOverlay.style.display = 'flex';
                else if (pauseOverlay) pauseOverlay.style.display = 'none';
            });
        }
        window.addEventListener('inventory-toggle', (e) => {
            if (!e.detail.open && player.controls && !isChatOpen) player.controls.lock();
        });

        
        const REACH = 6;
        const hit = { x: 0, y: 0, z: 0, id: 0, nx: 0, ny: 0, nz: 0 };
        const dir = new THREE.Vector3();
        let hasTarget = false;

        const selBox = new THREE.LineSegments(
            new THREE.EdgesGeometry(new THREE.BoxGeometry(1.004, 1.004, 1.004)),
            new THREE.LineBasicMaterial({ color: 0x000000, fog: false })
        );
        selBox.visible = false;
        scene.add(selBox);
        const crackCanvas = document.createElement('canvas');
        crackCanvas.width = crackCanvas.height = 16;
        const crackContext = crackCanvas.getContext('2d');
        const crackTexture = new THREE.CanvasTexture(crackCanvas);
        crackTexture.magFilter = THREE.NearestFilter; crackTexture.minFilter = THREE.NearestFilter; crackTexture.generateMipmaps = false;
        const crackSheet = new Image();
        let lastCrackFrame = -1;
        crackSheet.onload = () => {
            crackContext.clearRect(0, 0, 16, 16);
            crackContext.drawImage(crackSheet, 0, 0, 16, 16, 0, 0, 16, 16);
            crackTexture.needsUpdate = true;
        };
        crackSheet.src = '/static/assets/textures/particles/breaking/cassage.frames.png';
        const crackMaterial = new THREE.MeshBasicMaterial({ map: crackTexture, transparent: true, alphaTest: 0.015, opacity: 0.88, depthWrite: false, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -1 });
        const crackOverlay = new THREE.Mesh(new THREE.BoxGeometry(1.004,1.004,1.004), crackMaterial);
        crackOverlay.visible = false; crackOverlay.renderOrder = 3; scene.add(crackOverlay);

        function updateTarget() {
            camera.getWorldDirection(dir);
            hasTarget = world.raycast(camera.position.x, camera.position.y, camera.position.z, dir.x, dir.y, dir.z, REACH, hit);
            return hasTarget;
        }

        function breakBlock() {
            const block = window.blockRegistry?.get(hit.id);
            const slot = player.inventory.getSelectedSlot();
            const item = window.itemsRegistry?.get(slot?.type);
            const removed = world.removeBlockAt(hit);
            if (removed > 0) {
                const definition = window.blockRegistry?.get(removed);
                const requiredLevel = Number(definition?.level) || 1;
                const canDrop = !definition?.type || (item?.tool && item.type === definition.type && item.level >= requiredLevel) || (!item?.tool && requiredLevel <= 1);
                const drop = definition?.drop === undefined ? removed : definition.drop;
                if (canDrop && drop != null) {
                    const dropIds = Array.isArray(drop) ? drop : [drop];
                    for (const dropId of dropIds) {
                        const rawRate = definition?.dropRates?.[dropId] ?? definition?.dropRate ?? 100;
                        const chance = Math.max(0, Math.min(100, Number(rawRate))) / 100;
                        const quantity = Math.max(0, Math.floor(Number(definition?.dropNumber ?? 1)));
                        if (Number.isFinite(Number(dropId)) && Math.random() < chance && quantity > 0) player.inventory.addItem(Number(dropId), quantity);
                    }
                }
                window.blockBehaviorRegistry?.dispatch?.(removed, 'onBreak', { world, player, position: {x:hit.x,y:hit.y,z:hit.z}, item });
                if (window.soundManager) window.soundManager.playBlockBreak(removed);
                particleManager.spawnBlockBreakParticles(hit, removed);
                if ([55,56,57].includes(removed) && item?.tool && item.type === 'pickaxe' && item.level >= 3) particleManager.spawnOreSparks(hit);
                crackOverlay.visible = false;
            }
        }

        function placeBlock() {
            const slot = player.inventory.getSelectedSlot();
            if (!slot || slot.type === 0 || slot.count <= 0) return;
            const item = window.itemsRegistry?.get(slot.type);
            if (item && item.place == null) return;
            const placeId = item?.place ?? slot.type;

            let px = hit.x + hit.nx, py = hit.y + hit.ny, pz = hit.z + hit.nz;
            if (world.plantT[hit.id]) { px = hit.x; py = hit.y; pz = hit.z; }
            if (py < 0 || py >= world.maxHeight) return;

            const cur = world.getBlockI(px, py, pz);
            if (cur !== 0 && !world.fluidT[cur] && !world.plantT[cur]) return;
            if (world.torchT[placeId] && (py <= 0 || !world.solidT[world.getBlockI(px, py - 1, pz)])) return;

            if (world.solidT[placeId]) {
                const p = player.position, hw = player.width / 2;
                if (px < p.x + hw && px + 1 > p.x - hw &&
                    py < p.y + player.height && py + 1 > p.y &&
                    pz < p.z + hw && pz + 1 > p.z - hw) return;
            }

            const used = player.inventory.useSelectedBlock();
            if (!used) return;
            const type = placeId;
            world.addBlock({ x: px, y: py, z: pz }, type);
            window.blockBehaviorRegistry?.dispatch?.(type, 'onPlace', { world, player, position: {x:px,y:py,z:pz} });
            particleManager.spawnBlockPlaceParticles({ x: px, y: py, z: pz }, type);
            if (window.soundManager) window.soundManager.playBlockPlace(type);

            
            if (window.dimensionRegistry && type === window.dimensionRegistry.PORTAL_FRAME_ID) {
                window.dimensionRegistry.tryActivatePortal(world, px, py, pz);
            }
        }

        function interact(button) {
            if (button === 2 && player.consumeSelectedFood?.()) return;
            if (button === 2 && player.controls?.isLocked && world.mobManager) {
                if (player.ridingHorse) { player.dismountHorse(); return; }
                const direction = new THREE.Vector3(); camera.getWorldDirection(direction);
                const targetMob = world.mobManager.getTargetMob(camera.position, direction, 4.5);
                if (targetMob?.definition?.id === 'horse') { player.mountHorse(targetMob); return; }
            }
            if (button === 0 && world.mobManager && player.controls?.isLocked) {
                const direction = new THREE.Vector3(); camera.getWorldDirection(direction);
                if (world.mobManager.hitTarget(camera.position, direction, 4.5, player)) return;
            }
            if (!updateTarget()) return;
            if (button === 2) {
                const definition = window.blockRegistry?.get(hit.id);
                if (definition?.ui && window.BlockUIManager) { window.BlockUIManager.open(definition, {world, player, position:{x:hit.x,y:hit.y,z:hit.z}}); return; }
                window.blockBehaviorRegistry?.dispatch?.(hit.id, 'onInteract', {world,player,position:{x:hit.x,y:hit.y,z:hit.z}});
            }
            if (button === 2 && hit.id === 54) { inventoryUI.openCraftingTable(); return; }
            if (button === 2 && hit.id === 53) { inventoryUI.openFurnace(); return; }
            if (button === 0) breakBlock();
            else if (button === 2) placeBlock();
        }

        let lastRepeat = 0;
        let miningKey = null;
        let miningStarted = 0;
        window.addEventListener('mousedown', (e) => {
            if (!player.controls || !player.controls.isLocked || isWorldLoading || isChatOpen) return;
            if (e.button !== 0 && e.button !== 2) return;
            // A left click should first attempt to hit a creature.
            // Before this fix, interact(0) was never called on click:
            // the player could only mine blocks behind nearby animals.
            if (e.button === 0 && world.mobManager) {
                const direction = new THREE.Vector3();
                camera.getWorldDirection(direction);
                if (world.mobManager.hitTarget(camera.position, direction, 4.5, player)) {
                    player.triggerAttack?.();
                    window.soundManager?.playAttack?.();
                    mouseHeld = -1;
                    miningKey = null;
                    return;
                }
            }
            mouseHeld = e.button;
            lastRepeat = performance.now();
            miningKey = null;
            miningStarted = performance.now();
            if (e.button !== 0) interact(e.button);
        });
        window.addEventListener('mouseup', (e) => { if (e.button === mouseHeld) { mouseHeld = -1; miningKey = null; } });
        window.addEventListener('contextmenu', (e) => e.preventDefault());

        
        const fpsVal = document.getElementById('fps-val');
        const savedLimit = localStorage.getItem('fpsLimit') || 'max';
        const limit = savedLimit === 'max' ? 0 : parseInt(savedLimit, 10) || 0;
        const resolutionSetting = localStorage.getItem('gameResolution') || 'auto';
        const minFrame = limit ? 1000 / limit : 0;

        const configuredChunkBudget = Math.max(0.5, Math.min(6, Number(localStorage.getItem('laPlaine.chunkBudget')) || 2.5));
        let ambientParticleTimer = 0.35, ambientSoundTimer = 24, blockDamageTimer = 0;
        let frameCount = 0, lastFpsUpdate = performance.now(), lastFrame = 0, prevTime = performance.now();
        let measuredFps = 60;
        let lastChunkUpdate = 0, wasUnderwater = false, slowSeconds = 0, stableSeconds = 0, lavaDamageTimer = 0, fluidSoundState = ''; 
        const startedAt = performance.now();

        function animate(now) {
            requestAnimationFrame(animate);
            now = now || performance.now();

            if (minFrame && now - lastFrame < minFrame - 1) return;
            lastFrame = now;

            const delta = Math.min((now - prevTime) * 0.001, 0.1);
            prevTime = now;
            world.updateAnimatedTextures(now);
            blockDamageTimer += delta;
            if (blockDamageTimer >= 0.75) {
                const damageStep = blockDamageTimer; blockDamageTimer = 0;
                const px = Math.floor(player.position.x), pz = Math.floor(player.position.z);
                const ys = [Math.floor(player.position.y + 0.15), Math.floor(player.position.y + 0.9)];
                const neighbors = [[-1,0],[1,0],[0,-1],[0,1]];
                const touched = new Set();
                for (const y of ys) for (const [dx,dz] of neighbors) {
                    const id = world.getBlockI(px + dx, y, pz + dz);
                    if (!id || touched.has(id)) continue;
                    const definition = window.blockRegistry?.get(id);
                    if (Number(definition?.damagePerSec) > 0) {
                        touched.add(id);
                        window.blockBehaviorRegistry?.dispatch?.(id, 'onContact', {world,player,position:{x:px+dx,y,z:pz+dz},delta:damageStep});
                    }
                }
            }

            frameCount++;
            if (now - lastFpsUpdate >= 1000) {
                const fps = (frameCount * 1000) / (now - lastFpsUpdate);
                measuredFps = fps;
                if (fpsVal) fpsVal.textContent = Math.round(fps);
                frameCount = 0;
                lastFpsUpdate = now;

                const isAuto = resolutionSetting === 'auto';
                const target = limit ? Math.min(limit, 120) : 60;
                if (isAuto && localStorage.getItem('autoResolution') !== 'false' && now - startedAt > 4000) {
                    if (fps < target * 0.8 && autoScale > 0.5) {
                        stableSeconds = 0;
                        if (++slowSeconds >= 2) {
                            autoScale = Math.max(0.5, autoScale * 0.85);
                            slowSeconds = 0;
                            applyResolution();
                        }
                    } else if (fps > target * 0.95 && autoScale < qualityScale) {
                        slowSeconds = 0;
                        if (++stableSeconds >= 3) {
                            autoScale = Math.min(qualityScale, autoScale + 0.05);
                            stableSeconds = 0;
                            applyResolution();
                        }
                    } else { slowSeconds = 0; stableSeconds = 0; }
                } else { slowSeconds = 0; stableSeconds = 0; }
            }

            const simulationActive = Boolean(player.controls?.isLocked) && !player.inventory.isOpen && !isChatOpen && !player.dead;
            window.LaPlaineAPI?.emit('game:tick', { delta, now, world, player, camera, simulationActive });
            if (simulationActive) {
                window.LaPlaineUpdateManager?.tick(delta, { now, world, player, camera });
                world.updateDayNightCycle(delta, camera.position);
            }
            const chunkBudgetMs = Math.min(configuredChunkBudget, measuredFps >= 100 ? 4 : measuredFps >= 60 ? 2.5 : 1.0);
            world.processQueue(chunkBudgetMs);

            if (simulationActive) {
                player.update(delta);
                updateWeather(delta);
            }
            const feetBlock = world.getBlockI(Math.floor(player.position.x), Math.floor(player.position.y + 0.05), Math.floor(player.position.z));
            const groundBlock = world.getBlockI(Math.floor(player.position.x), Math.floor(player.position.y - 0.1), Math.floor(player.position.z));
            if (simulationActive && (feetBlock === 32 || groundBlock === 32)) {
                if (fluidSoundState !== 'lava') { fluidSoundState = 'lava'; window.soundManager?.setFluidAmbience?.('lava'); particleManager.spawnFluidSplash({x:player.position.x,y:player.position.y+.1,z:player.position.z},true); }
                lavaDamageTimer -= delta;
                if (lavaDamageTimer <= 0) { player.takeDamage(2); lavaDamageTimer = 1; }
            } else { lavaDamageTimer = 0; const nextFluid = world.isFluidAt(player.position.x, player.position.y + player.eyeHeight, player.position.z) ? 'water' : ''; if (fluidSoundState !== nextFluid) { fluidSoundState = nextFluid; window.soundManager?.setFluidAmbience?.(nextFluid); } }
            if (simulationActive) {
                world.updateMobs(delta, player);
                particleManager.update(delta);
            }
            ambientParticleTimer -= delta;
            ambientSoundTimer -= delta;
            if (ambientSoundTimer <= 0 && player.controls?.isLocked) { ambientSoundTimer = 32 + Math.random()*28; window.soundManager?.playRandomAmbient?.(); }
            if (ambientParticleTimer <= 0 && player.controls?.isLocked) {
                ambientParticleTimer = 0.65 + Math.random() * 1.15;
                const px = Math.floor(player.position.x + (Math.random()-.5)*12), pz = Math.floor(player.position.z + (Math.random()-.5)*12);
                const py = world.getTerrainHeight(px,pz);
                if (py > 0) {
                    particleManager.spawnDust({x:px+Math.random(),y:py+1.15+Math.random()*1.5,z:pz+Math.random()});
                    if (Math.random() < 0.22) {
                        const leafIds = new Set([5,16,23,24,27,34,36]);
                        let foundLeafId = 0;
                        for(let yy=py+2; yy<=py+8 && !foundLeafId; yy++) for(let zz=pz-2;zz<=pz+2&&!foundLeafId;zz++) for(let xx=px-2;xx<=px+2;xx++){ const bid=world.getBlockI(xx,yy,zz); if(leafIds.has(bid)){foundLeafId=bid;break;} }
                        if(foundLeafId){ const leaf=foundLeafId===23?'leaf_fall_automne':foundLeafId===27||foundLeafId===34?'leaf_fall_accacia':foundLeafId===16?'leaf_fall_pine':foundLeafId===36?'leaf_fall_dark':'leaf_fall'; particleManager.spawnFallingLeaf({x:px+Math.random(),y:py+5+Math.random()*2,z:pz+Math.random()},leaf); }
                    }
                }
            }
            inventoryUI.updateFurnace?.(delta);
            if (simulationActive) world.updateFluids(now);

            if (simulationActive && window.dimensionRegistry) window.dimensionRegistry.checkPlayerInPortal(world, player, now);

            if (now - lastChunkUpdate > 250) {
                world.updateChunks(player.position.x, player.position.z);
                lastChunkUpdate = now;
            }

            const locked = player.controls && player.controls.isLocked;
            if (locked && !isChatOpen && updateTarget()) {
                selBox.position.set(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5);
                selBox.visible = true;
                if (mouseHeld === 0) {
                    const key = `${hit.x},${hit.y},${hit.z}`;
                    if (key !== miningKey) { miningKey = key; miningStarted = now; lastCrackFrame = -1; }
                    const block = window.blockRegistry?.get(hit.id);
                    const slot = player.inventory.getSelectedSlot();
                    const tool = window.itemsRegistry?.get(slot?.type);
                    const duration = Math.max(0, Number(block?.breakTime) || 0);
                    const speed = tool?.tool && (!block?.type || tool.type === block.type) ? (tool.level >= 3 ? 2.4 : tool.level >= 2 ? 1.7 : 1.25) : 1;
                    const progress = duration > 0 ? Math.max(0,Math.min(0.999,((now-miningStarted)/1000)/(duration/speed))) : 0;
                    if (crackSheet.complete && crackSheet.naturalWidth) {
                        const frameCount = Math.max(1, Math.floor(crackSheet.naturalWidth / 16));
                        const frame = Math.min(frameCount - 1, Math.floor(progress * frameCount));
                        if (frame !== lastCrackFrame) {
                            lastCrackFrame = frame;
                            crackContext.clearRect(0, 0, 16, 16);
                            crackContext.drawImage(crackSheet, frame * 16, 0, 16, 16, 0, 0, 16, 16);
                            crackTexture.needsUpdate = true;
                        }
                    }
                    crackOverlay.position.set(hit.x+.5,hit.y+.5,hit.z+.5); crackOverlay.visible = duration > 0;
                    if ((now - miningStarted) / 1000 >= duration / speed) { breakBlock(); miningStarted = now; miningKey = null; mouseHeld = -1; crackOverlay.visible = false; }
                } else {
                    crackOverlay.visible = false;
                    if (mouseHeld === 2 && now - lastRepeat > 220) { lastRepeat = now; placeBlock(); }
                }
            } else {
                selBox.visible = false;
                crackOverlay.visible = false;
                miningKey = null;
            }

            const underwater = world.isFluidAt(camera.position.x, camera.position.y, camera.position.z);
            if (underwater !== wasUnderwater) {
                wasUnderwater = underwater;
                world.setUnderwater(underwater);
                waterOverlay.style.display = underwater ? 'block' : 'none';
                if (window.soundManager) window.soundManager.setUnderwater(underwater);
                if (underwater) particleManager.spawnFluidSplash({x:player.position.x,y:player.position.y+0.45,z:player.position.z}, false);
            }

            if (shaderPackRenderer) shaderPackRenderer.render(scene, camera);
            else renderer.render(scene, camera);
        }
        requestAnimationFrame(animate);
    }
})();
