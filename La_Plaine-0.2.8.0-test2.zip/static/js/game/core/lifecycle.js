/* Ordered, failure-tolerant lifecycle for engine subsystems. */
(function (global) {
    'use strict';
    const modules = new Map();
    const states = new Map();
    const events = global.LaPlaineEvents;
    const api = {
        register(id, definition) {
            if (typeof id !== 'string' || !/^[a-z0-9_.:-]{1,100}$/i.test(id)) throw new TypeError('Identifiant de module invalide.');
            if (!definition || typeof definition !== 'object' || modules.has(id)) throw new Error(`Module invalide ou déjà déclaré : ${id}`);
            modules.set(id, Object.freeze({ id, dependencies: Array.isArray(definition.dependencies) ? [...definition.dependencies] : [], init: definition.init, dispose: definition.dispose }));
            states.set(id, 'registered'); return true;
        },
        getState(id) { return states.get(id) || 'missing'; },
        async initialize(context = {}) {
            const visiting = new Set(), initialized = [];
            async function start(id) {
                const mod = modules.get(id);
                if (!mod) throw new Error(`Dépendance absente : ${id}`);
                if (states.get(id) === 'ready') return;
                if (visiting.has(id)) throw new Error(`Cycle de dépendances : ${[...visiting, id].join(' -> ')}`);
                visiting.add(id); states.set(id, 'initializing');
                try {
                    for (const dependency of mod.dependencies) await start(dependency);
                    if (typeof mod.init === 'function') await mod.init(context);
                    states.set(id, 'ready'); initialized.push(id); events?.emit('module:ready', { id });
                } catch (error) { states.set(id, 'failed'); events?.emit('module:error', { id, error }); throw error; }
                finally { visiting.delete(id); }
            }
            const errors = [];
            for (const id of modules.keys()) { try { await start(id); } catch (error) { errors.push({ id, message: error.message }); } }
            return { initialized, errors };
        },
        async dispose(context = {}) {
            for (const id of [...modules.keys()].reverse()) {
                if (states.get(id) !== 'ready') continue;
                try { if (typeof modules.get(id).dispose === 'function') await modules.get(id).dispose(context); states.set(id, 'registered'); }
                catch (error) { states.set(id, 'failed'); console.error(`[La Plaine] Arrêt du module ${id} impossible`, error); }
            }
        },
        list() { return [...modules.keys()].map(id => ({ id, state: states.get(id), dependencies: [...modules.get(id).dependencies] })); }
    };
    global.LaPlaineLifecycle = Object.freeze(api);
})(window);
