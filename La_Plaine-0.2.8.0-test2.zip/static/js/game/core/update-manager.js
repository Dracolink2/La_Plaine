/* Frequency-based task scheduler. Tasks are opt-in; the legacy game loop remains authoritative. */
(function (global) {
    'use strict';
    const tasks = new Map();
    const api = {
        register(id, callback, intervalMs = 0, options = {}) {
            if (typeof id !== 'string' || typeof callback !== 'function' || !Number.isFinite(intervalMs) || intervalMs < 0) throw new TypeError('Tâche invalide.');
            if (tasks.has(id)) throw new Error(`Tâche déjà enregistrée : ${id}`);
            tasks.set(id, { callback, intervalMs, elapsed: 0, enabled: options.enabled !== false });
            return () => tasks.delete(id);
        },
        setEnabled(id, enabled) { const task = tasks.get(id); if (!task) return false; task.enabled = Boolean(enabled); return true; },
        tick(delta, context = {}) {
            const dt = Math.max(0, Math.min(Number(delta) || 0, 0.25));
            for (const [id, task] of tasks) {
                if (!task.enabled) continue;
                task.elapsed += dt * 1000;
                if (task.intervalMs > 0 && task.elapsed < task.intervalMs) continue;
                const elapsed = task.elapsed; task.elapsed = 0;
                try { task.callback({ ...context, delta: elapsed / 1000, elapsedMs: elapsed }); }
                catch (error) { console.error(`[La Plaine][UpdateManager] ${id}`, error); }
            }
        },
        list() { return [...tasks.entries()].map(([id, task]) => ({ id, intervalMs: task.intervalMs, enabled: task.enabled })); }
    };
    global.LaPlaineUpdateManager = Object.freeze(api);
})(window);
