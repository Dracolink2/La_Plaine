/* Developer diagnostics commands. Invoke LaPlaineDiagnostics.execute('/registry'). */
(function (global) {
    'use strict';
    const api = {
        snapshot() { return global.LaPlaineEngine?.getDiagnostics?.() || {}; },
        registry() {
            const snapshot = this.snapshot();
            const rows = [
                ['Blocs', global.blockRegistry?.getAll?.().length || 0],
                ['Items', global.itemsRegistry?.getAll?.().length || 0],
                ['Biomes Overworld', global.overworldBiomeRegistry?.getAll?.().length || 0],
                ['Dimensions', global.dimensionRegistry?.getAll?.().length || 0],
                ['Mobs', global.mobRegistry?.getAll?.().length || 0],
                ['Structures namespacées', global.LaPlaineContentRegistries?.structures?.getAll?.().length || 0],
                ['Types de blocs', global.LaPlaineBlockTypes?.getAll?.().length || 0]
            ];
            const output = ['[La Plaine Diagnostics] — V0.2.8.0', ...rows.map(([name, count]) => `${name.padEnd(25)} ${count}`), `Mods chargés              ${global.LaPlaineModLoader?.getLoaded?.().length || 0}`, `Avertissements            ${(global.LaPlaineWarnings || []).length}`].join('\n');
            console.info(output); return output;
        },
        execute(command) {
            const normalized = String(command || '').trim().toLowerCase();
            if (normalized === '/registry') return this.registry();
            if (normalized === '/diagnostics') { const result = this.snapshot(); console.table(result); return result; }
            return 'Commande inconnue. Commandes : /registry, /diagnostics';
        },
        display() {
            const panel = document.getElementById('lp-diagnostics');
            const warnings = global.LaPlaineWarnings || [];
            if (!panel || !warnings.length) return;
            panel.style.display = 'block';
            panel.textContent = `La Plaine 0.2.8.0 — ${warnings.length} avertissement(s)\n` + warnings.map((item, index) => `${index + 1}. [${item.scope || 'jeu'}] ${item.message}`).join('\n');
        }
    };
    global.LaPlaineDiagnostics = api;
})(window);
