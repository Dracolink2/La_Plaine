/* Public engine facade: stable entry point for internal systems and extensions. */
(function (global) {
    'use strict';
    const engine = {
        version: '0.2.8.0',
        events: global.LaPlaineEvents,
        lifecycle: global.LaPlaineLifecycle,
        updates: global.LaPlaineUpdateManager,
        getDiagnostics() {
            return {
                version: this.version,
                blocks: global.blockRegistry?.getAll?.().length || 0,
                items: global.itemsRegistry?.getAll?.().length || 0,
                biomes: global.overworldBiomeRegistry?.getAll?.().length || 0,
                dimensions: global.dimensionRegistry?.getAll?.().length || 0,
                mobs: global.mobRegistry?.getAll?.().length || 0,
                structures: global.structureRegistry?.getAll?.().length || 0,
                mods: global.LaPlaineModLoader?.getLoaded?.().length || 0,
                warnings: (global.LaPlaineWarnings || []).length
            };
        }
    };
    global.LaPlaineEngine = Object.freeze(engine);
})(window);
