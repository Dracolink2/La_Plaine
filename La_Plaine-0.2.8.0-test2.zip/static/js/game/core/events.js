/* La Plaine 0.2.8.0 — lightweight engine event bus. */
(function installEventBus(global) {
    'use strict';
    if (global.LaPlaineEvents) return;
    const listeners = new Map();
    const bus = {
        on(name, callback, options = {}) {
            if (typeof name !== 'string' || !name.trim() || typeof callback !== 'function') throw new TypeError('Événement et callback requis.');
            const bucket = listeners.get(name) || new Set();
            const record = { callback, once: options.once === true };
            bucket.add(record); listeners.set(name, bucket);
            return () => { bucket.delete(record); if (!bucket.size) listeners.delete(name); };
        },
        once(name, callback) { return this.on(name, callback, { once: true }); },
        emit(name, detail = {}) {
            const bucket = listeners.get(name);
            if (!bucket) return [];
            const results = [];
            for (const record of [...bucket]) {
                if (!bucket.has(record)) continue;
                try { results.push(record.callback(detail)); }
                catch (error) { console.error(`[La Plaine][EventBus] ${name}`, error); }
                if (record.once) bucket.delete(record);
            }
            if (!bucket.size) listeners.delete(name);
            return results;
        },
        clear(name) { if (name) listeners.delete(name); else listeners.clear(); },
        listenerCount(name) { return listeners.get(name)?.size || 0; },
        eventNames() { return [...listeners.keys()]; }
    };
    global.LaPlaineEvents = Object.freeze(bus);
})(window);
