/* Base game item declarations — La Plaine 0.2.8.0.
   Les blocs sont automatiquement copiés dans le registre d'items avant les items autonomes. */
(function () {
    const registry = window.itemsRegistry;
    if (!registry) {
        console.error('[La Plaine] Le registre des items est introuvable.');
        return;
    }

    // Each block has its own item, with a separate inventory texture when itemTexture is defined.
    registry.registerBlocks();

    // Tools
    registry.register({ id: 1001, name: 'Pioche en bois', type: 'pickaxe', level: 1, textures: { all: '/static/assets/textures/items/tools/wood/wooden_pick.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1002, name: 'Pioche en pierre', type: 'pickaxe', level: 2, textures: { all: '/static/assets/textures/items/tools/stone/stone_pick.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1003, name: 'Pioche en fer', type: 'pickaxe', level: 3, textures: { all: '/static/assets/textures/items/tools/iron/iron_pick.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1004, name: 'Pioche en diamant', type: 'pickaxe', level: 4, textures: { all: '/static/assets/textures/items/tools/diamond/diamond_pick.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1005, name: 'Pioche en cuivre', type: 'pickaxe', level: 2, textures: { all: '/static/assets/textures/items/tools/cooper/cooper-pick.png' }, place: null, 'stack-number': 1 });

    registry.register({ id: 1011, name: 'Hache en bois', type: 'axe', level: 1, textures: { all: '/static/assets/textures/items/tools/wood/wooden_axe.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1012, name: 'Hache en pierre', type: 'axe', level: 2, textures: { all: '/static/assets/textures/items/tools/stone/stone_axe.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1013, name: 'Hache en fer', type: 'axe', level: 3, textures: { all: '/static/assets/textures/items/tools/iron/iron_axe.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1014, name: 'Hache en diamant', type: 'axe', level: 4, textures: { all: '/static/assets/textures/items/tools/diamond/diamond_axe.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1015, name: 'Hache en cuivre', type: 'axe', level: 2, textures: { all: '/static/assets/textures/items/tools/cooper/cooper-axe.png' }, place: null, 'stack-number': 1 });

    registry.register({ id: 1021, name: 'Pelle en bois', type: 'shovel', level: 1, textures: { all: '/static/assets/textures/items/tools/wood/wooden_shovel.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1022, name: 'Pelle en pierre', type: 'shovel', level: 2, textures: { all: '/static/assets/textures/items/tools/stone/stone_shovel.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1023, name: 'Pelle en fer', type: 'shovel', level: 3, textures: { all: '/static/assets/textures/items/tools/iron/iron_shovel.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1024, name: 'Pelle en diamant', type: 'shovel', level: 4, textures: { all: '/static/assets/textures/items/tools/diamond/diamond_shovel.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1025, name: 'Pelle en cuivre', type: 'shovel', level: 2, textures: { all: '/static/assets/textures/items/tools/cooper/cooper-shovel.png' }, place: null, 'stack-number': 1 });

    registry.register({ id: 1031, name: 'Épée en bois', type: 'sword', level: 1, textures: { all: '/static/assets/textures/items/tools/wood/wooden_sword.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1032, name: 'Épée en pierre', type: 'sword', level: 2, textures: { all: '/static/assets/textures/items/tools/stone/stone_sword.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1033, name: 'Épée en fer', type: 'sword', level: 3, textures: { all: '/static/assets/textures/items/tools/iron/iron_sword.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1034, name: 'Épée en diamant', type: 'sword', level: 4, textures: { all: '/static/assets/textures/items/tools/diamond/diamond_sword.png' }, place: null, 'stack-number': 1 });
    registry.register({ id: 1035, name: 'Épée en cuivre', type: 'sword', level: 2, textures: { all: '/static/assets/textures/items/tools/cooper/cooper-sword.png' }, place: null, 'stack-number': 1 });

    // Wearable armor pieces. Each material uses one 64×64 player atlas.
    const armorTiers = [
        { material: 'cuir', atlas: 'leather', defense: { head: 1, chest: 3, legs: 2, feet: 1 } },
        { material: 'cuivre', atlas: 'cooper', defense: { head: 1, chest: 4, legs: 3, feet: 1 } },
        { material: 'fer', atlas: 'iron', defense: { head: 2, chest: 5, legs: 4, feet: 2 } },
        { material: 'diamant', atlas: 'diamond', defense: { head: 3, chest: 6, legs: 5, feet: 3 } },
        { material: 'lévitite', atlas: 'levitite', defense: { head: 4, chest: 8, legs: 6, feet: 4 } }
    ];
    const armorParts = [
        { slot: 'head', label: 'Casque', base: 1210 },
        { slot: 'chest', label: 'Plastron', base: 1200 },
        { slot: 'legs', label: 'Jambières', base: 1220 },
        { slot: 'feet', label: 'Bottes', base: 1230 }
    ];
    armorTiers.forEach((tier, tierIndex) => armorParts.forEach(part => {
        const id = part.base + tierIndex + 1;
        registry.register({
            id, name: `${part.label} en ${tier.material}`, type: 'armor', behaviors: ['armor'],
            armorSlot: part.slot, defense: tier.defense[part.slot], armorMaterial: tier.material,
            armorAtlas: `/static/assets/textures/items/armors/${tier.atlas}-armor.png`,
            textures: { all: `/static/assets/textures/items/armors/${tier.atlas}-armor.png` }, place: null, 'stack-number': 1
        });
    }));

    // Materials and resources
    registry.register({ id: 1101, name: 'Bâton', type: 'material', textures: { all: '/static/assets/textures/items/materials/stick.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1102, name: 'Charbon', type: 'material', textures: { all: '/static/assets/textures/items/ores/coal.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1103, name: 'Minerai de fer', type: 'material', textures: { all: '/static/assets/textures/blocks/undergrounds/stones/ores/iron_ore.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1104, name: 'Lingot de fer', type: 'material', textures: { all: '/static/assets/textures/items/ores/iron_ingot.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1105, name: 'Mouton cuit', type: 'food', foodPoints: 6, saturation: 8, healPoints: 1, textures: { all: '/static/assets/textures/items/foods/cooked_sheep.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1106, name: 'Laine', type: 'material', textures: { all: '/static/assets/textures/blocks/dropped/laine.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1107, name: 'Mouton cru', type: 'food', foodPoints: 2, saturation: 1, textures: { all: '/static/assets/textures/items/foods/raw_sheep.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1108, name: 'Plume', type: 'material', textures: { all: '/static/assets/textures/items/materials/feather.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1109, name: 'Œuf', type: 'material', textures: { all: '/static/assets/textures/items/others/egg.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1110, name: 'Lévitite', type: 'material', textures: { all: '/static/assets/textures/blocks/undergrounds/stones/ores/levitite.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1111, name: 'Cuir', type: 'material', textures: { all: '/static/assets/textures/items/materials/leather.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1112, name: 'Charbon de bois', type: 'material', textures: { all: '/static/assets/textures/items/others/wood_coal.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1113, name: 'Pierre brute', type: 'material', textures: { all: '/static/assets/textures/blocks/undergrounds/stones/stone.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1114, name: 'Minerai de cuivre', type: 'material', textures: { all: '/static/assets/textures/blocks/undergrounds/stones/ores/cooper_ore.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1115, name: 'Diamant', type: 'material', textures: { all: '/static/assets/textures/blocks/undergrounds/stones/ores/diamond_ore.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1116, name: 'Lingot de cuivre', type: 'material', textures: { all: '/static/assets/textures/blocks/undergrounds/ore-blocks/raw_cooper_block.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1117, name: 'Charbon de bois', type: 'material', textures: { all: '/static/assets/textures/items/others/wood_coal.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1118, name: 'Poulet cru', type: 'food', foodPoints: 2, saturation: 1, textures: { all: '/static/assets/textures/items/foods/raw_chicken.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1119, name: 'Poulet cuit', type: 'food', foodPoints: 5, saturation: 6, healPoints: 1, textures: { all: '/static/assets/textures/items/foods/cooked_chicken.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1120, name: 'Porc cru', type: 'food', foodPoints: 3, saturation: 2, textures: { all: '/static/assets/textures/items/foods/raw_pig.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1121, name: 'Porc cuit', type: 'food', foodPoints: 7, saturation: 10, healPoints: 2, textures: { all: '/static/assets/textures/items/foods/cooked_pig.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1122, name: 'Bœuf cru', type: 'food', foodPoints: 3, saturation: 2, textures: { all: '/static/assets/textures/items/foods/raw_cow.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1123, name: 'Bœuf cuit', type: 'food', foodPoints: 7, saturation: 10, healPoints: 2, textures: { all: '/static/assets/textures/items/foods/cooked_cow.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1124, name: 'Fil', type: 'material', textures: { all: '/static/assets/textures/items/materials/string.png' }, place: null, 'stack-number': 100 });
    registry.register({ id: 1125, name: 'Os', type: 'material', textures: { all: '/static/assets/textures/items/materials/bone.png' }, place: null, 'stack-number': 100 });
})();
