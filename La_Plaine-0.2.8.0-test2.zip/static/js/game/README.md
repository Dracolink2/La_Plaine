# Architecture — La Plaine 0.2.8.0

- `core/events.js`: synchronous event bus; `LaPlaineAPI.on/emit` forwards to it.
- `core/lifecycle.js`: dependency-ordered initialization and reverse disposal for engine modules.
- `core/update-manager.js`: optional interval scheduler; legacy per-frame systems remain unchanged until migrated deliberately.
- `core/engine.js`: stable engine facade and diagnostics snapshot.
- `features/content-registry.js`: namespaced registries for extensible content categories.
- `features/blocks/registry.js`: block behavior types, separate from individual block definitions.

Legacy numeric block/item IDs are intentionally preserved for save compatibility. The current voxel storage uses byte-sized block IDs, so arbitrary namespaced block IDs cannot safely replace that format in this release. New namespaced definitions can be registered through `LaPlaineAPI.registerContent(category, definition)`; categories are `biomes`, `dimensions`, `mobs`, `structures`, `particles`, `effects`, `sounds`, `recipeTypes`, `physicalBlockTypes`, and `interactiveTypes`.

`LaPlaineUpdateManager.register(id, callback, intervalMs)` registers opt-in periodic work. The survival feature uses it for 250 ms updates; render and movement systems remain per-frame.

Developer commands are available in the console through `LaPlaineDiagnostics.execute('/registry')` and `LaPlaineDiagnostics.execute('/diagnostics')`.
# Tâches de jeu et performances

Les scripts de base et les mods peuvent planifier les mises à jour qui n'ont pas
besoin de tourner à chaque image avec `LaPlaineAPI.registerTask(id, callback,
intervalMs)`. La tâche reçoit le contexte du jeu et le temps écoulé depuis son
dernier appel. Le budget de génération des chunks, réglable dans les paramètres
graphiques, limite aussi le temps passé à créer des chunks pendant une image.
