/* Generic namespace-aware registries for extensible game content. */
(function (global) {
    'use strict';
    class ContentRegistry {
        constructor(category) { this.category = category; this.entries = new Map(); }
        register(definition) {
            if (!definition || typeof definition !== 'object' || typeof definition.id !== 'string' || !/^[a-z0-9_.-]+:[a-z0-9_./-]+$/i.test(definition.id)) throw new TypeError(`${this.category}: identifiant namespacé requis (namespace:name).`);
            if (this.entries.has(definition.id)) throw new Error(`${this.category}: identifiant déjà utilisé : ${definition.id}`);
            const item = Object.freeze({ ...definition }); this.entries.set(item.id, item);
            global.LaPlaineEvents?.emit('registry:registered', { category: this.category, item });
            return item;
        }
        get(id) { return this.entries.get(id) || null; }
        has(id) { return this.entries.has(id); }
        getAll() { return [...this.entries.values()]; }
        remove(id) { const item = this.entries.get(id); if (!item) return false; this.entries.delete(id); global.LaPlaineEvents?.emit('registry:removed', { category: this.category, id }); return true; }
    }
    const categories = ['biomes','dimensions','mobs','structures','particles','effects','sounds','recipeTypes','physicalBlockTypes','interactiveTypes'];
    const registries = Object.fromEntries(categories.map(category => [category, new ContentRegistry(category)]));
    global.LaPlaineContentRegistries = Object.freeze(registries);
    global.LaPlaineContentRegistry = ContentRegistry;
})(window);
