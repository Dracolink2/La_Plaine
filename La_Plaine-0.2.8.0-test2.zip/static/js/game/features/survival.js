/* Hunger, food and natural recovery for the existing survival game. */
(function (global) {
    'use strict';
    const clamp = (value, max) => Math.max(0, Math.min(max, Number(value) || 0));

    global.LaPlaineFeatureRegistry?.register('survival', {
        description: 'Faim, consommation des aliments et récupération naturelle.',
        init({ player } = {}) {
            if (!player || player.__survivalReady) return;
            player.__survivalReady = true;
            player.maxHunger = 20;
            player.hunger = clamp(player.hunger ?? 20, player.maxHunger);
            player.saturation = clamp(player.saturation ?? 5, player.hunger);
            let hungerClock = 0;
            let recoveryClock = 0;
            let starvationClock = 0;

            player.updateHungerUI = () => {
                const root = document.getElementById('hunger-container');
                if (!root) return;
                root.replaceChildren();
                for (let i = 0; i < player.maxHunger; i++) {
                    const icon = document.createElement('span');
                    icon.className = `hunger-icon${i >= Math.ceil(player.hunger) ? ' empty' : ''}`;
                    root.appendChild(icon);
                }
                root.title = `Faim : ${Math.ceil(player.hunger)}/20 · Réserve : ${Math.floor(player.saturation)}`;
            };

            player.consumeSelectedFood = () => {
                if (player.dead || player.inventory.isOpen) return false;
                const slot = player.inventory.getSelectedSlot();
                const food = slot?.type ? global.itemsRegistry?.get(slot.type) : null;
                const nutrition = Number(food?.foodPoints) || 0;
                if (!food || nutrition <= 0 || (!food.healPoints && player.hunger >= player.maxHunger)) return false;
                slot.count--;
                if (slot.count <= 0) { slot.type = 0; slot.count = 0; }
                player.hunger = Math.min(player.maxHunger, player.hunger + nutrition);
                player.saturation = Math.min(player.hunger, player.saturation + (Number(food.saturation) || nutrition));
                if (food.healPoints && player.health < player.maxHealth) player.heal(Number(food.healPoints));
                player.inventory.updateUI();
                player.updateHungerUI();
                global.LaPlaineAPI?.emit('player:ate', { player, item: food, nutrition });
                return true;
            };

            player.updateHungerUI();
            global.LaPlaineAPI?.registerTask('survival-hunger', ({ delta = 0 } = {}) => {
                if (player.dead || !Number.isFinite(delta) || delta <= 0) return;
                const moving = player.moveForward || player.moveBackward || player.moveLeft || player.moveRight;
                hungerClock += delta * (player.isSprinting ? 2.4 : moving ? 1.2 : 0.45);
                const drainInterval = 36;
                if (hungerClock >= drainInterval) {
                    hungerClock %= drainInterval;
                    if (player.saturation > 0) player.saturation = Math.max(0, player.saturation - 1);
                    else player.hunger = Math.max(0, player.hunger - 1);
                    player.updateHungerUI();
                }

                if (player.hunger >= 18 && player.health < player.maxHealth && player.saturation >= 1) {
                    recoveryClock += delta;
                    if (recoveryClock >= 8) {
                        recoveryClock = 0;
                        player.saturation = Math.max(0, player.saturation - 1);
                        player.heal(1);
                        player.updateHungerUI();
                    }
                } else recoveryClock = 0;

                if (player.hunger <= 0 && player.health > 1) {
                    starvationClock += delta;
                    if (starvationClock >= 8) { starvationClock = 0; player.takeDamage(1, { ignoreArmor: true }); }
                } else starvationClock = 0;
            }, 250);
        }
    });
})(window);
