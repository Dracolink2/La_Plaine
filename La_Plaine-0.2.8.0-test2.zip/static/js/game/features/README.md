# Fonctionnalités extensibles

Le registre central est `register.js`. Les fichiers JavaScript placés directement
à côté de celui-ci sont découverts par `/api/modules` puis chargés au démarrage.

Exemple de `ma-fonction.js` :

```js
window.LaPlaineFeatureRegistry.register('ma-fonction', {
    description: 'Exemple de fonctionnalité',
    init({ world, player } = {}) {
        console.info('Ma fonctionnalité est initialisée', { world, player });
    }
});
```

Le registre expose `register`, `get`, `getAll`, `has`, `on`, `emit` et
`initialize`. Une fonctionnalité peut également déclarer `register(api)` pour
installer ses extensions au chargement, puis `init(context)` pour son initialisation.

Le module `survival.js` active la faim et la saturation pour les aliments existants.
Les aliments déclarent `foodPoints`, `saturation` et éventuellement `healPoints` dans
`static/js/game/items/Items1.js`. Le joueur peut consommer l'objet sélectionné au clic
droit. La faim et la saturation sont enregistrées dans l'état du joueur.
