/* Modular feature registry and shared namespaced content registries. */
(function installFeatureRegistry(global) {
    'use strict';
    const features = new Map();
    const listeners = new Map();
    const emit = (name, payload) => {
        global.LaPlaineEvents?.emit(`feature:${name}`, payload);
        for (const callback of [...(listeners.get(name) || [])]) { try { callback(payload); } catch (error) { console.error(`[La Plaine] Événement feature:${name}`, error); } }
    };
    const api = {
        register(id, definition) {
            if (typeof id !== 'string' || !/^[a-zA-Z0-9_.-]{1,100}$/.test(id)) throw new TypeError('Identifiant de fonctionnalité invalide.');
            if (!definition || typeof definition !== 'object' || Array.isArray(definition)) throw new TypeError(`Définition invalide : ${id}`);
            if (features.has(id)) throw new Error(`Fonctionnalité déjà enregistrée : ${id}`);
            const feature = Object.freeze({ id, ...definition }); features.set(id, feature); emit('registered', { feature });
            if (typeof feature.register === 'function') feature.register(api);
            return feature;
        },
        get: id => features.get(id) || null,
        getAll: () => [...features.values()],
        has: id => features.has(id),
        on(name, callback) { if (typeof name !== 'string' || typeof callback !== 'function') throw new TypeError('Événement et callback requis.'); const set = listeners.get(name) || new Set(); set.add(callback); listeners.set(name, set); return () => set.delete(callback); },
        emit,
        initialize(context) { for (const feature of features.values()) { try { feature.init?.(context); } catch (error) { console.error(`[La Plaine] Initialisation ${feature.id}`, error); } } }
    };
    global.LaPlaineFeatureRegistry = global.featureRegistry = api;
    if (global.LaPlaineAPI?.on) global.LaPlaineAPI.on('game:ready', async context => { api.initialize(context); await global.LaPlaineLifecycle?.initialize?.(context); });
})(window);
