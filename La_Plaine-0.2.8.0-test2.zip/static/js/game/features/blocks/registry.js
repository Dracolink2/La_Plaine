/* Block type handlers are distinct from individual block definitions. */
(function (global) {
    'use strict';
    const types = new Map();
    const api = {
        register(id, handler) {
            if (typeof id !== 'string' || !/^[a-z][a-z0-9_-]{0,47}$/i.test(id) || !handler || typeof handler !== 'object') throw new TypeError('Type de bloc invalide.');
            if (types.has(id)) throw new Error(`Type de bloc déjà enregistré : ${id}`);
            types.set(id, Object.freeze({ id, ...handler }));
            return types.get(id);
        },
        get: id => types.get(id) || null,
        getAll: () => [...types.values()]
    };
    global.LaPlaineBlockTypes = api;
})(window);
