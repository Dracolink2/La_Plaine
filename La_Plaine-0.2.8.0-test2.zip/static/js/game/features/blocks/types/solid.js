window.LaPlaineBlockTypes?.register('solid', { render: 'cube', collision: 'full', opaque: true });
