window.LaPlaineBlockTypes?.register('liquid', { render: 'fluid', collision: 'none', opaque: false, animated: true });
