/* The world mesher renders torches as small 3D models with non-solid collision. */
window.LaPlaineBlockTypes?.register('torch', {
    render: 'torch-model', collision: 'none', opaque: false,
    placement: Object.freeze({ floor: true, wall: false, requiresSolidFloor: true }),
    animation: Object.freeze({ flame: true }),
    lighting: Object.freeze({ dynamic: true, flicker: true }),
    note: 'Modèle de torche 3D rendu dans un maillage dédié.'
});
