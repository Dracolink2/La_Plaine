

blockRegistry.register({
    id: 240,
    name: 'Bloc de Portail',
    breakTime: 2.0,
    textures: { all: '/static/assets/textures/blocks/undergrounds/deesplates/deepslate/deepslate.png' },
    transparent: false
});



blockRegistry.register({
    id: 241,
    name: 'Portail',
    breakTime: 0.2,
    textures: { all: '/static/assets/textures/liquids/water.png' },
    transparent: true,
    alphaTest: 0.1,
    isPlant: true,
    lightLevel: 12,
    emitColor: 0x9b30ff
});


dimensionRegistry.register({
    id: 'overworld',
    name: 'La Plaine',
    biomeRegistry: window.overworldBiomeRegistry,
    portalTarget: 'aether'
});
