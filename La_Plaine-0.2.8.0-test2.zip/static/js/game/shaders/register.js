


class ShaderRegistry {
    constructor() {
        this.byBlock = new Map();
        this.byBiome = new Map();
        this.enabled = localStorage.getItem('fxShaders') !== 'false';
    }

    registerForBlock(blockId, factory) {
        
        this.byBlock.set(blockId, factory);
    }

    registerForBiome(biomeId, factory) {
        this.byBiome.set(biomeId, factory);
    }

    getMaterialForBlock(blockId, baseTexture, fallback) {
        if (!this.enabled) return fallback;
        const factory = this.byBlock.get(blockId);
        return factory ? factory(baseTexture) : fallback;
    }

    getMaterialForBiome(biomeId, baseTexture, fallback) {
        if (!this.enabled) return fallback;
        const factory = this.byBiome.get(biomeId);
        return factory ? factory(baseTexture) : fallback;
    }

    setEnabled(v) {
        this.enabled = v;
        localStorage.setItem('fxShaders', v);
        window.dispatchEvent(new CustomEvent('shaders-toggled', { detail: { enabled: v } }));
    }
}

window.shaderRegistry = new ShaderRegistry();

