(function(){
    const base=(worldId,dimension='overworld',position={})=>`/api/worlds/${encodeURIComponent(worldId)}/block-data?dimension=${encodeURIComponent(dimension)}&x=${encodeURIComponent(position.x)}&y=${encodeURIComponent(position.y)}&z=${encodeURIComponent(position.z)}`;
    window.LaPlaineWorldData=Object.freeze({
        async getBlockData(worldId,dimension,position){const response=await fetch(base(worldId,dimension,position));if(!response.ok)throw new Error('Lecture des données du bloc impossible.');return (await response.json()).data||{};},
        async saveBlockData(worldId,dimension,position,data){const response=await fetch(base(worldId,dimension,position),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({data})});if(!response.ok){const payload=await response.json().catch(()=>({}));throw new Error(payload.error||'Enregistrement des données du bloc impossible.');}return true;},
        async deleteBlockData(worldId,dimension,position){const response=await fetch(base(worldId,dimension,position),{method:'DELETE'});if(!response.ok)throw new Error('Suppression des données du bloc impossible.');return true;}
    });
})();
