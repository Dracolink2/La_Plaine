(function(){
    'use strict';
    let root=null, activeScripts=[], activePlayer=null, restorePointerLock=false;
    function close(options={}){if(!root)return false;const player=activePlayer,shouldRestore=restorePointerLock&&options.resume!==false;for(const script of activeScripts)script.remove();activeScripts=[];root.remove();root=null;activePlayer=null;restorePointerLock=false;document.removeEventListener('keydown',onKey);window.dispatchEvent(new CustomEvent('laplaine:block-ui-close'));if(shouldRestore&&player?.inventory?.isOpen!==true)player.controls?.lock?.();return shouldRestore;}
    function onKey(event){if(event.key==='Escape')close();}
    async function open(block,context={}){
        const ui=block?.ui||block?.UI;if(typeof ui!=='string'||!ui.trim())return false;
        let path=ui.replace(/\\/g,'/');path=path.replace(/^\/?templates\/in-game-UI\//,'');path=path.replace(/^\//,'');
        if(!path||path.split('/').some(part=>!part||part==='.'||part==='..')||!path.toLowerCase().endsWith('.html')){console.warn('[La Plaine] Chemin UI invalide :',ui);return false;}
        try{
            const response=await fetch(`/api/block-ui/${path.split('/').map(encodeURIComponent).join('/')}`);
            if(!response.ok)throw new Error(`HTTP ${response.status}`);
            const html=await response.text();const shouldRestore=close({resume:false})||Boolean(context.player?.controls?.isLocked);
            const parsed=new DOMParser().parseFromString(html,'text/html');
            root=document.createElement('div');root.id='lp-block-ui-root';root.style.cssText='position:fixed;inset:0;z-index:10010;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.58);';
            activePlayer=context.player||null;restorePointerLock=shouldRestore;
            for(const style of parsed.head.querySelectorAll('style,link[rel=stylesheet]')) root.appendChild(style.cloneNode(true));
            const panel=document.createElement('div');panel.style.cssText='position:relative;max-width:96vw;max-height:94vh;overflow:auto;';panel.innerHTML=parsed.body.innerHTML;root.appendChild(panel);root.addEventListener('mousedown',e=>{if(e.target===root)close();});document.body.appendChild(root);if(context.player?.controls?.isLocked)window.dispatchEvent(new CustomEvent('laplaine:controls-unlock-intent',{detail:{reason:'block-ui'}}));context.player?.controls?.unlock?.();document.addEventListener('keydown',onKey);
            for(const old of [...panel.querySelectorAll('script')]){const script=document.createElement('script');for(const attr of old.attributes)script.setAttribute(attr.name,attr.value);if(old.src){script.src=old.src.startsWith('/')?old.src:`/static/js/${old.src}`;activeScripts.push(script);document.body.appendChild(script);}else{script.textContent=old.textContent;activeScripts.push(script);document.body.appendChild(script);}old.remove();}
            window.dispatchEvent(new CustomEvent('laplaine:block-ui-open',{detail:{block,context,root,panel,close}}));return true;
        }catch(error){console.warn(`[La Plaine] Interface du bloc ${block?.id} indisponible :`,error);return false;}
    }
    window.BlockUIManager=Object.freeze({open,close,isOpen:()=>Boolean(root)});
})();
