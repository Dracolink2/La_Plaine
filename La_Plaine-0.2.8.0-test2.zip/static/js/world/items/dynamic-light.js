/* Dynamic lighting associated with held items. */
window.itemBehaviorRegistry?.register('dynamic-light', { description: 'Indique qu’un item peut produire une lumière dynamique.' });
