# Registre des items et comportements

`register.js` crée `window.itemsRegistry` et `window.itemBehaviorRegistry`. Les définitions de base se trouvent dans `static/js/game/items/Items1.js` et utilisent `itemsRegistry.register({...})`. Les blocs sont automatiquement copiés comme items; la propriété `itemTexture` d'un bloc permet de choisir une texture d'inventaire différente.

Les items acceptent notamment `id`, `name`, `type`, `textures`, `place`, `'stack-number'`, `custom-file`, `'dynamic-light'`, `atlas`, `level` et `maxDurability`. Les fichiers JavaScript ajoutés directement dans ce dossier sont détectés automatiquement.
