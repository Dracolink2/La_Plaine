/* Extensible item durability management. */
window.itemBehaviorRegistry?.register('durability', { description: 'Comportement de durabilité pour les outils et équipements.' });
