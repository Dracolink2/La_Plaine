/* Armor behavior: equipped pieces contribute defense and use the player armor atlas. */
window.itemBehaviorRegistry?.register('armor', { description: 'Pièce d’armure équipable dans son emplacement dédié; sa défense réduit les dégâts reçus.' });
