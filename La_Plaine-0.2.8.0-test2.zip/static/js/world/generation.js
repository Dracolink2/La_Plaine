const CORE_BIOME_IDS = new Set(['plaine', 'foret', 'desert', 'ocean', 'montagne', 'foret_sapin', 'plaine_enneigee', 'foret_automne', 'foret_champignon', 'Nyamée', 'Savane', 'terres_brulees']);
function hashSeed(seed) {
    seed = String(seed ?? '0');
    let h = 2166136261 >>> 0;
    for (let i = 0; i < seed.length; i++) {
        h ^= seed.charCodeAt(i);
        h = Math.imul(h, 16777619);
    }
    return h >>> 0;
}

function getWorldSeed() {
    let seed = localStorage.getItem('worldSeed');
    if (seed === null || seed === '') {
        seed = String((Date.now() ^ (Math.random() * 0xFFFFFFFF)) >>> 0);
        localStorage.setItem('worldSeed', seed);
    }
    return seed;
}

class SeededRandom {
    constructor(seed) {
        this.state = hashSeed(seed) || 0x6D2B79F5;
    }

    next() {
        let t = this.state += 0x6D2B79F5;
        t = Math.imul(t ^ t >>> 15, t | 1);
        t ^= t + Math.imul(t ^ t >>> 7, t | 61);
        return ((t ^ t >>> 14) >>> 0) / 4294967296;
    }
}

class PerlinNoise {
    constructor(seed = '0') {
        this.seed = seed;
        this.p = new Uint8Array(256);

        const random = new SeededRandom(seed);
        for (let i = 0; i < 256; i++) this.p[i] = i;

        
        for (let i = 255; i > 0; i--) {
            const j = Math.floor(random.next() * (i + 1));
            const tmp = this.p[i];
            this.p[i] = this.p[j];
            this.p[j] = tmp;
        }

        this.perm = new Uint8Array(512);
        for (let i = 0; i < 512; i++) this.perm[i] = this.p[i & 255];
    }

    fade(t) { return t * t * t * (t * (t * 6 - 15) + 10); }
    lerp(t, a, b) { return a + t * (b - a); }

    grad(hash, x, y) {
        const h = hash & 7;
        const u = h < 4 ? x : y;
        const v = h < 4 ? y : x;
        return ((h & 1) === 0 ? u : -u) + ((h & 2) === 0 ? v : -v);
    }

    noise(x, y) {
        const X = Math.floor(x) & 255;
        const Y = Math.floor(y) & 255;

        x -= Math.floor(x);
        y -= Math.floor(y);

        const u = this.fade(x);
        const v = this.fade(y);

        const A = this.perm[X] + Y;
        const B = this.perm[X + 1] + Y;

        return this.lerp(v,
            this.lerp(u, this.grad(this.perm[A], x, y), this.grad(this.perm[B], x - 1, y)),
            this.lerp(u, this.grad(this.perm[A + 1], x, y - 1), this.grad(this.perm[B + 1], x - 1, y - 1))
        );
    }
}

const warnedGenerationVersions = new Set();
const Generation = {
    
    GENERATION_VERSION: 9,

    trySpawnStructure(world, structure, x, surfaceY, z, options = {}) {
        if (!world || !structure || typeof structure.place !== 'function') return false;

        const size = structure.size || { x: 1, y: 1, z: 1 };
        const width = Math.max(1, Math.floor(size.x || 1));
        const depth = Math.max(1, Math.floor(size.z || 1));
        const height = Math.max(1, Math.floor(size.y || 1));

        const chunkX = Math.floor(x / 16);
        const chunkZ = Math.floor(z / 16);
        const centerX = chunkX * 16 + 8;
        const centerZ = chunkZ * 16 + 8;

        if (x !== centerX || z !== centerZ) return false;
        if (width > 16 || depth > 16) return false;

        const anchorX = x - Math.floor(width / 2);
        const anchorZ = z - Math.floor(depth / 2);
        const minFlatLength = Math.max(1, Math.floor(
            structure.minFlatLength || Math.max(width, depth)
        ));
        const tolerance = Number.isFinite(structure.flatTolerance)
            ? Math.max(0, structure.flatTolerance)
            : 0;

        
        let minY = Infinity;
        let maxY = -Infinity;
        let validSurface = true;

        for (let dx = 0; dx < width; dx++) {
            for (let dz = 0; dz < depth; dz++) {
                const px = anchorX + dx;
                const pz = anchorZ + dz;
                const py = world.getTerrainHeight(px, pz);

                if (!Number.isFinite(py) || py <= world.seaLevel + 1) {
                    validSurface = false;
                    break;
                }

                minY = Math.min(minY, py);
                maxY = Math.max(maxY, py);
            }
            if (!validSurface) break;
        }

        if (!validSurface || (maxY - minY) > tolerance) return false;
        if (Math.max(width, depth) < minFlatLength) return false;

        
        if (options.sameBiome && world.biomeRegistry?.getBiomeAt) {
            const biomeId = options.biomeId || null;
            for (let dx = 0; dx < width; dx++) {
                for (let dz = 0; dz < depth; dz++) {
                    const biome = world.biomeRegistry.getBiomeAt(
                        anchorX + dx, anchorZ + dz, world.perlin
                    );
                    if (!biome || (biomeId && biome.id !== biomeId)) return false;
                }
            }
        }

        
        for (let dx = 0; dx < width; dx++) {
            for (let dz = 0; dz < depth; dz++) {
                for (let dy = 0; dy < height; dy++) {
                    if (world.getBlock(anchorX + dx, minY + 1 + dy, anchorZ + dz) !== 0) {
                        return false;
                    }
                }
            }
        }

        const flat = minY === maxY;
        if (!flat || structure.guaranteedOnFlat !== true) {
            const chance = Number.isFinite(structure.chance)
                ? Math.max(0, Math.min(1, structure.chance))
                : 0;
            const random = (hashSeed(
                `${world.seed}|structure|${structure.id || 'unknown'}|${centerX}|${centerZ}`
            ) >>> 0) / 4294967296;
            if (random >= chance) return false;
        }

        structure.place(world, anchorX, minY + 1, anchorZ);
        return true;
    },
    computeHeight(world, biome, x, z) {
        if (!CORE_BIOME_IDS.has(biome?.id)) {
            const elevation = world.perlin.noise(x * 0.03, z * 0.03) * biome.elevationScale;
            const detail = world.perlin.noise(x * 0.1, z * 0.1) * biome.detailScale;
            return Math.max(2, Math.min(world.maxHeight - 12, Math.floor(biome.baseHeight + elevation + detail)));
        }
        const noise = world.perlin.noise;
        const continental = noise.call(world.perlin, x * 0.00026 + 2500, z * 0.00026 - 2500);
        const temperature = noise.call(world.perlin, x * 0.00038 + 1000, z * 0.00038 + 1000);
        const smooth = (a, b, value) => { const t = Math.max(0, Math.min(1, (value - a) / (b - a))); return t * t * (3 - 2 * t); };
        const mountainWeight = smooth(0.40, 0.62, continental) * (1 - smooth(0.32, 0.52, temperature));
        const broad3D = world.simplex3D
            ? world.simplex3D.noise3D(x * 0.0028, 17.31, z * 0.0028) * 2.4
            : noise.call(world.perlin, x * 0.0028, z * 0.0028) * 2.4;
        const hills = (world.simplex3D
            ? world.simplex3D.noise3D(x * 0.009, 53.7, z * 0.009)
            : noise.call(world.perlin, x * 0.009, z * 0.009)) * (3.2 + mountainWeight * 7.5);
        const detail = (world.improvedNoise
            ? world.improvedNoise.noise(x * 0.032 + world.caveNoiseOffset.x, 29.4, z * 0.032 + world.caveNoiseOffset.z)
            : noise.call(world.perlin, x * 0.032, z * 0.032)) * 1.35;
        const landHeight = 18 + broad3D + hills + detail + mountainWeight * 1.2;
        const oceanFloor = world.seaLevel - 6 + noise.call(world.perlin, x * 0.006, z * 0.006) * 1.2;
        const oceanBlend = smooth(-0.22, -0.50, continental);
        const h = Math.floor(landHeight + (oceanFloor - landHeight) * oceanBlend);
        return Math.max(2, Math.min(world.maxHeight - 12, h));
    },

    generateTree(world, x, startY, z) {
        const treeHeight = 4 + Math.floor(Math.abs(world.perlin.noise(x * 0.5, z * 0.5)) * 2);

        for (let y = startY; y < startY + treeHeight; y++) {
            world.setBlock(x, y, z, 4);
        }

        const leafStart = startY + treeHeight - 2;
        const leafEnd = startY + treeHeight + 1;

        for (let ly = leafStart; ly <= leafEnd; ly++) {
            const radius = ly >= leafEnd - 1 ? 1 : 2;
            for (let lx = x - radius; lx <= x + radius; lx++) {
                for (let lz = z - radius; lz <= z + radius; lz++) {
                    if (world.getBlock(lx, ly, lz) === 0) {
                        if (Math.abs(lx - x) === radius && Math.abs(lz - z) === radius && ((lx + ly + lz) & 1) === 0) continue;
                        world.setBlock(lx, ly, lz, 5);
                    }
                }
            }
        }
    },

    generateTerrainData(world, cx, cz, requestedVersion = this.GENERATION_VERSION) {
        const chunk = world.getChunkAt(cx, cz, true);
        if (chunk.generated) return;

        
        
        
        const version = Number(requestedVersion) || this.GENERATION_VERSION;
        if (version !== this.GENERATION_VERSION && !warnedGenerationVersions.has(version)) {
            warnedGenerationVersions.add(version);
            console.warn(`Génération historique V${version} indisponible, utilisation de V${this.GENERATION_VERSION}.`);
        }
        if (!world.biomeRegistry) return;

        world.generating = true;
        const B = chunk.blocks;
        const heights = new Uint8Array(256);
        chunk.heights = heights;
        const startX = cx << 4, startZ = cz << 4;
        const sea = world.seaLevel;
        let maxY = 0;

        for (let lz = 0; lz < 16; lz++) {
            for (let lx = 0; lx < 16; lx++) {
                const x = startX + lx, z = startZ + lz;
                const biome = world.biomeRegistry.getBiomeAt(x, z, world.perlin);
                const h = this.computeHeight(world, biome, x, z);
                heights[(lz << 4) | lx] = h;

                const col = (lz << 4) | lx;
                for (let y = 0; y < h; y++) {
                    B[(y << 8) | col] = y === 0 ? 65 : y <= 20 ? 17 : 1;
                }
                B[(h << 8) | col] = biome.surfaceBlock;

                if (h > maxY) maxY = h;
                if (h < sea) {
                    for (let y = h + 1; y <= sea; y++) B[(y << 8) | col] = 11;
                    if (sea > maxY) maxY = sea;
                }
            }
        }
        chunk.maxY = maxY;

        const ores = [
            { id: 55, deepId: 70, key: 'coal', chance: 0.48, minY: 5, maxY: 70, rx: 2.8, ry: 1.8, rz: 2.8 },
            { id: 52, deepId: 71, key: 'iron', chance: 0.34, minY: 5, maxY: 52, rx: 2.2, ry: 1.8, rz: 2.2 },
            { id: 56, deepId: 72, key: 'copper', chance: 0.28, minY: 5, maxY: 44, rx: 2.6, ry: 1.8, rz: 2.6 },
            { id: 57, deepId: 73, key: 'diamond', chance: 0.10, minY: 4, maxY: 18, rx: 1.5, ry: 1.3, rz: 1.5 },
            { id: 66, key: 'calcite', chance: 0.08, minY: 7, maxY: 38, rx: 2.1, ry: 1.5, rz: 2.1 },
            { id: 67, key: 'gravel', chance: 0.09, minY: 8, maxY: 54, rx: 2.0, ry: 1.4, rz: 2.0 },
            { id: 68, key: 'clay', chance: 0.045, minY: 5, maxY: 22, rx: 2.1, ry: 1.2, rz: 2.1 }
        ];
        const floorDiv = (n, d) => Math.floor(n / d);
        for (const ore of ores) {
            const minGX = floorDiv(startX - 5, 8), maxGX = floorDiv(startX + 20, 8);
            const minGZ = floorDiv(startZ - 5, 8), maxGZ = floorDiv(startZ + 20, 8);
            const minGY = floorDiv(ore.minY - 5, 8), maxGY = floorDiv(ore.maxY + 5, 8);
            for (let gx = minGX; gx <= maxGX; gx++) for (let gy = minGY; gy <= maxGY; gy++) for (let gz = minGZ; gz <= maxGZ; gz++) {
                const r = new SeededRandom(`${world.seed}|vein|${ore.key}|${gx}|${gy}|${gz}`);
                if (r.next() >= ore.chance) continue;
                const vx = gx * 8 + 1 + r.next() * 6;
                const vy = gy * 8 + 1 + r.next() * 6;
                const vz = gz * 8 + 1 + r.next() * 6;
                const wobble = 0.72 + r.next() * 0.55;
                const rx = ore.rx * wobble, rz = ore.rz * wobble;
                const x0 = Math.max(startX, Math.floor(vx - rx)), x1 = Math.min(startX + 15, Math.ceil(vx + rx));
                const z0 = Math.max(startZ, Math.floor(vz - rz)), z1 = Math.min(startZ + 15, Math.ceil(vz + rz));
                const y0 = Math.max(ore.minY, Math.floor(vy - ore.ry)), y1 = Math.min(ore.maxY, Math.ceil(vy + ore.ry));
                for (let x = x0; x <= x1; x++) for (let z = z0; z <= z1; z++) {
                    const col = ((z - startZ) << 4) | (x - startX);
                    const surface = heights[col];
                    for (let y = y0; y <= Math.min(y1, surface - 4); y++) {
                        const dx = (x - vx) / rx, dy = (y - vy) / ore.ry, dz = (z - vz) / rz;
                        if (dx*dx + dy*dy + dz*dz > 1) continue;
                        const index = (y << 8) | col;
                        if (B[index] !== 0 && B[index] !== 11) B[index] = ore.deepId && y <= 20 ? ore.deepId : ore.id;
                    }
                }
            }
        }

        for (let lz = 0; lz < 16; lz++) for (let lx = 0; lx < 16; lx++) {
            const x = startX + lx, z = startZ + lz, col = (lz << 4) | lx;
            const surface = heights[col];
            for (let y = 5; y < Math.min(surface - 3, world.maxHeight - 1); y++) {
                const broad = world.perlin.noise(x * 0.035 + 71, z * 0.035 - 29);
                const detail = world.perlin.noise(x * 0.075 - 13, z * 0.075 + 47);
                const centerY = 13 + Math.floor((world.perlin.noise(x * 0.018, z * 0.018) + 1) * 11);
                const vertical = Math.abs(y - centerY);
                const tunnel = Math.abs(broad) < 0.115 && Math.abs(detail) < 0.52 && vertical < 3.2;
                const chamber = Math.abs(world.perlin.noise(x * 0.055 + 130, z * 0.055 + 90)) < 0.095 && vertical < 5;
                if (tunnel || chamber) B[(y << 8) | col] = 0;
            }
            const ex = floorDiv(x, 48), ez = floorDiv(z, 48);
            for (let gx = ex - 1; gx <= ex + 1; gx++) for (let gz = ez - 1; gz <= ez + 1; gz++) {
                const r = new SeededRandom(`${world.seed}|cave-mouth|${gx}|${gz}`);
                if (r.next() > 0.23) continue;
                const mx = gx * 48 + 8 + Math.floor(r.next() * 32);
                const mz = gz * 48 + 8 + Math.floor(r.next() * 32);
                const radius = 2.2 + r.next() * 1.8;
                const dx = x - mx, dz = z - mz;
                if (dx*dx + dz*dz > radius*radius) continue;
                for (let y = 5; y < surface; y++) {
                    const index = (y << 8) | col;
                    if (y < surface - 1 || Math.abs(dx) + Math.abs(dz) < radius * 0.65) B[index] = 0;
                }
            }
        }

        const structureX = startX + 8;
        const structureZ = startZ + 8;
        const structureSurfaceY = heights[(8 << 4) | 8];
        const structureBiome = world.biomeRegistry.getBiomeAt(
            structureX, structureZ, world.perlin
        );
        if (world.options?.generateStructures !== false && structureSurfaceY > sea && typeof structureBiome?.generateStructures === 'function') {
            structureBiome.generateStructures(
                world, structureX, structureSurfaceY, structureZ, world.perlin
            );
        }

        
        for (let x = startX + 2; x < startX + 14; x++) {
            for (let z = startZ + 2; z < startZ + 14; z++) {
                const surfaceY = heights[((z - startZ) << 4) | (x - startX)];
                if (surfaceY > sea) {
                    world.biomeRegistry.getBiomeAt(x, z, world.perlin).generateDecorations(
                        world, x, surfaceY, z, world.perlin
                    );
                }
            }
        }

        world.generating = false;
        chunk.generated = true;
        chunk.generationVersion = this.GENERATION_VERSION;
        if (typeof world._applyPersistedChangesToChunk === 'function') {
            world._applyPersistedChangesToChunk(cx, cz);
        }
        if (typeof world._recordGeneratedChunk === 'function') {
            world._recordGeneratedChunk(cx, cz, this.GENERATION_VERSION);
        }
    }
};


window.Generation = Generation;
window.GENERATION_VERSION = Generation.GENERATION_VERSION;
window.PerlinNoise = PerlinNoise;
window.getWorldSeed = getWorldSeed;
window.SeededRandom = SeededRandom;
