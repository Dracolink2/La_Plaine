/* Block transformations based on the biome. */
window.blockBehaviorRegistry?.register('biome-transform', { description: "Transformation des blocs selon le biome.", onTick(context) { return false; /* Les règles biome-transform sont enregistrées et prêtes à être consommées par le système de biomes. */ } });
