/* Timed growth behavior for plant blocks. */
window.blockBehaviorRegistry?.register('growth', { description: "Croissance temporisée des blocs végétaux.", onTick(context) { return false; /* Le calendrier de croissance sera activé avec la mécanique de croissance. */ } });
