/* Animated textures, including GIF files. */
window.blockBehaviorRegistry?.register('animated', { description: "Textures animées, dont GIF.", onLoad(context) { return true; /* Les GIF sont actualisés par le gestionnaire de ressources. */ } });
