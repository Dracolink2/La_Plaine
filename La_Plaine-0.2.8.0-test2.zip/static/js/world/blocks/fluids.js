/* Liquid behavior; the existing fluid simulation remains managed by World. */
window.blockBehaviorRegistry?.register('fluid', { description: "Comportement de liquide; la simulation des fluides existante reste gérée par World.", onTick(context) { if (context && context.world && typeof context.world.updateFluids === 'function') return true; } });
