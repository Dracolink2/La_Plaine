# Dépendances de La Plaine

Ces fichiers sont servis localement par Flask pour que le jeu ne dépende pas d'un CDN au démarrage.

- `OrbitControls-r128.js` — addon officiel Three.js, récupéré depuis `mrdoob/three.js`, tag `r128`, `examples/js/controls/OrbitControls.js`. Licence MIT (Three.js).
- `Sky-r128.js` — addon officiel Three.js, récupéré depuis `mrdoob/three.js`, tag `r128`, `examples/js/objects/Sky.js`. Licence MIT (Three.js).
- `ImprovedNoise-r128.js` — addon officiel Three.js, récupéré depuis `mrdoob/three.js`, tag `r128`, `examples/js/math/ImprovedNoise.js`. Licence MIT (Three.js).
- `simplex-noise-2.4.0.js` — Simplex Noise de Jonas Wagner, paquet `simplex-noise` version 2.4.0, distribution navigateur UMD. Licence MIT; l'avis complet est conservé dans le fichier.

Les addons Three.js sont volontairement alignés sur Three.js r128, déjà utilisé par cette version du jeu. En cas de mise à niveau du moteur, il faudra remplacer les addons par ceux de la même version et vérifier les API utilisées par le jeu.
